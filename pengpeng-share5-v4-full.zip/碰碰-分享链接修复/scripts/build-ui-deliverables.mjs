// Creates both modes with the existing builder; source config is restored even on failure.
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const config=path.join(root,'src/config.ts')
const original=fs.readFileSync(config,'utf8')
const npm=process.platform==='win32'?'npm.cmd':'npm'
const run=(exe,args)=>execFileSync(exe,args,{cwd:root,stdio:'inherit',shell:process.platform==='win32'})
try {
 fs.writeFileSync(config,original.replace('export const USE_REAL_API = true','export const USE_REAL_API = false'))
 run(npm,['run','build'])
 run(process.execPath,['scripts/build-standalone.mjs','碰碰-UI阶段三-Mock.html','mock'])
} finally {fs.writeFileSync(config,original)}
run(npm,['run','build'])
run(process.execPath,['scripts/build-standalone.mjs','碰碰-UI阶段三-真实API.html','real'])
