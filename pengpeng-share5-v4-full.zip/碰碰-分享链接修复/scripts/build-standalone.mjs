import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const outputName = process.argv[2]
const mode = process.argv[3] === 'mock' ? 'mock' : 'real'

if (!outputName) {
  throw new Error('用法：node scripts/build-standalone.mjs <输出文件名> <real|mock>')
}

const distHtmlPath = path.join(projectRoot, 'dist', 'index.html')
let html = fs.readFileSync(distHtmlPath, 'utf8')
const scriptTagMatch = html.match(/<script\s+defer(?:=[^\s>]*)?\s+src=([^\s>]+)><\/script>/i)
if (!scriptTagMatch) throw new Error('没有在 dist/index.html 中找到构建脚本')

const scriptSrc = scriptTagMatch[1].replace(/^['"]|['"]$/g, '')
const scriptPath = path.resolve(path.dirname(distHtmlPath), scriptSrc)
const script = fs.readFileSync(scriptPath, 'utf8').replace(/<\/script/gi, '<\\/script')
// 使用函数式 replacer，避免压缩脚本中的 $& / $` / $' 被 String.replace 当作替换标记。
html = html.replace(scriptTagMatch[0], () => `<script>${script}</script>`)

if (mode === 'mock') {
  // Mock 单文件不加载百度 SDK，也不消耗地图 API。
  html = html
    .replace(/<script>window\.__BAIDU_MAP_AK__=.*?<\/script>/i, '')
    .replace(/<script id=baidu-sdk-loader>[\s\S]*?<\/script>/i, '')
  html = html.replace(/<title>.*?<\/title>/i, '<title>碰碰 · 想见，那就轻松碰一面（Mock版）</title>')
} else {
  html = html.replace(/<title>.*?<\/title>/i, '<title>碰碰 · 想见，那就轻松碰一面（真实API版）</title>')
}

fs.writeFileSync(path.resolve(projectRoot, outputName), html)
console.log(`已生成 ${outputName}（${mode}）`)
