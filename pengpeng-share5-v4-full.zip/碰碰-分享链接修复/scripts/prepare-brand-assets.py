"""Crop only empty alpha margins; preserve raw PNGs and every RGBA pixel in the crop."""
from pathlib import Path
from PIL import Image
import json
root=Path(__file__).resolve().parents[1]
base=root/'src/assets/brand'
records=[]
for name,stem in [('碰碰LOGO猫.png','peng-cat'),('碰碰LOGO狗.png','peng-dog'),('碰碰LOGO纯字母.png','peng-wordmark'),('碰碰LOGO字母+线条.png','peng-wordmark-impact'),('谁要碰碰-猫狗.png','people-illustration'),('想干什么-猫狗.png','category-illustration')]:
    src=base/'raw'/name; im=Image.open(src).convert('RGBA');box=im.getchannel('A').getbbox()
    if not box:raise ValueError('Empty alpha image: '+name)
    pad=12
    crop=(max(0,box[0]-pad),max(0,box[1]-pad),min(im.width,box[2]+pad),min(im.height,box[3]+pad))
    display=im.crop(crop);display.save(base/'display'/f'{stem}-cropped.png')
    assert display.tobytes()==im.crop(crop).tobytes()
    records.append(dict(raw=name,display=f'{stem}-cropped.png',original_size=im.size,alpha_bbox=box,crop_box=crop,padding=pad,display_size=display.size,pixels_preserved=True))
(base/'crop-manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
print(json.dumps(records,ensure_ascii=False))
