"""Rebuild the seven-glyph shared subset. Requires: pip install fonttools brotli"""
from pathlib import Path
from fontTools import subset
root=Path(__file__).resolve().parents[1]
options=subset.Options();options.flavor='woff2'
font=subset.load_font(str(root/'src/assets/brand/raw/Dymon-ShouXieTi.otf'),options)
sub=subset.Subsetter(options=options);sub.populate(text='碰谁要想干什么');sub.subset(font)
subset.save_font(font,str(root/'src/assets/brand/fonts/PengBrandCNFlow.woff2'),options)
