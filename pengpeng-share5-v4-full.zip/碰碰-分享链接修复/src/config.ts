// ============================================================
// 全局配置开关
// ============================================================

/**
 * 是否使用真实百度地图 API。
 *
 * - true：调用真实百度地图 API（地点检索 / 路线规划 / 地图渲染 / 定位），会消耗 API 额度
 * - false：使用本地 Mock 数据，不调用任何外部 API，零额度消耗
 *
 * 开发调试交互 / 视觉 / 功能按钮时，建议设为 false，
 * 只有需要验证真实 API 数据流程时才切回 true。
 *
 * 修改后重新构建（npm run build）即可生效。
 */
export const USE_REAL_API = true

/**
 * 店铺筛选链路的集中配置。
 *
 * 这些值同时供真实 API 与 Mock 模式使用，避免两条路径出现不同口径。
 * 当前最长通勤规则沿用原工程真实生效的「严格小于 100 分钟」。
 */
export const SHOP_PIPELINE_CONFIG = {
  /** 百度 POI 候选池目标范围 */
  candidateMin: 50,
  candidateMax: 60,
  /** 地理粗排后进入真实路线计算的数量：只取粗排 Top N，不再分主/备池 */
  routeComputeCount: 30,
  /** 系统硬过滤：任一方时间差（fairness）超过该值直接淘汰，与用户在表单里设的时间差无关 */
  hardFairnessMinutes: 60,
  /** 地图默认展示最终排序前 N 家，列表展示全部 */
  mapDisplayCount: 10,
  /** 最终结果不再固定输出 N 家，剩多少展示多少（保留该字段仅作兼容性参考） */
  maxResults: 20,
  /** 任一方通勤达到该值即不准入（沿用原逻辑：minutes < 100） */
  maxCommuteMinutes: 100,
  /** 多样性软重排偏好：同品牌优先不超过 3 家 */
  preferredBrandLimit: 3,
  /** 「全部分类」时，单一子品类优先不超过剩余结果的 35% */
  preferredSubcategoryShare: 0.35,
  /**
   * 最终排序加权评分权重。
   * score = wAvg × avg + wMax × maxCommute + wFair × fairness，分数越低排越前。
   * - wAvg：平均通勤基准权重，锚定为 1.0
   * - wMax：最远一方通勤权重，与 avg 高度相关，仅作"最惨一方"补充
   * - wFair：时间差（公平性）权重，核心产品价值；时间差每多 1 分钟 ≈ 平均通勤多 wFair 分钟
   */
  rankingWeights: {
    avg: 2.5,
    maxCommute: 0.3,
    fairness: 2.0,
  },
} as const
