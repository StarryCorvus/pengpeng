import { useState, type ReactNode } from 'react'
export type FilterVisualKey = 'averageCommute' | 'timeDiff'
type FilterVisual = { imageSrc?: string; placeholder: ReactNode }
const glyph = (path: string) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={path}/></svg>
/** UI-only replacement point. Set imageSrc to a bundled asset/data URL; no ResultPage changes needed. */
export const filterVisualMap: Record<FilterVisualKey, FilterVisual> = {
  averageCommute: { placeholder: glyph('M5 7a2 2 0 1 0 0 .1 M7 7h8q5 0 5 4t-5 4H9q-5 0-5 4 M18 18a2 2 0 1 0 0 .1') },
  timeDiff: { placeholder: glyph('M12 3.2C6 3 3.2 7 3.4 12c.1 5.4 4 8.7 9 8.5 5-.2 8.6-4 8.2-9C20.3 6.8 17 3.1 12 3.2 M12 6.6l-.3 5.7 4 2.2') },
}
export function FilterVisual({ name }: { name: FilterVisualKey }) {
  const { imageSrc, placeholder } = filterVisualMap[name]
  const [failedSrc, setFailedSrc] = useState<string>()
  return <span className="filter-visual" aria-hidden="true">{imageSrc && failedSrc !== imageSrc
    ? <img src={imageSrc} alt="" onError={() => setFailedSrc(imageSrc)}/>
    : placeholder}</span>
}
