import { BRAND_WORDMARK, BRAND_WORDMARK_IMPACT } from './brandAssets'
/** Direct RGBA artwork, no mask or clipping; impact mode keeps both original strokes. */
export function BrandWordmark({impact=false}:{impact?:boolean}) {
 return <img className="brand-wordmark" src={impact?BRAND_WORDMARK_IMPACT:BRAND_WORDMARK} alt="peng 碰碰"/>
}
