import type { ReactNode } from 'react'
/** UI-only labels and SVG paths. CATEGORY_TREE remains the source of truth. */
export type CategoryVisual = {label:string; path?:string; imageSrc?:string; iconComponent?:ReactNode; alt?:string; accent?:string}
export const categoryVisualMap: Record<string,CategoryVisual> = {
  mall:{label:'逛一逛',path:'M12 22L16 12H46L51 22V50H12Z M10 22H53 M22 50V34H40V50 M22 15V22 M32 15V22 M43 15V22'},
  food:{label:'吃顿饭',path:'M8 34Q31 37 55 33Q51 53 32 53Q14 53 8 34Z M17 26Q12 21 18 16 M30 26Q25 20 32 13 M43 25Q38 19 44 14 M7 57H55'},
  drink:{label:'喝一杯',path:'M13 25L16 49Q31 57 44 48L47 24Z M47 28Q61 25 57 36Q53 42 45 40 M11 57H49 M24 17Q18 12 25 6 M36 17Q31 11 38 6'},
  fun:{label:'玩一会',path:'M12 19L49 16L53 49L16 53Z M23 26L38 43 M38 26L23 43 M44 9L55 6 M57 15L62 17'},
  market:{label:'买点东西',path:'M8 12H15L23 43H49L57 22L18 20 M29 24L31 37 M42 24L40 38 M26 49A3 3 0 1 0 26 55A3 3 0 1 0 26 49 M47 49A3 3 0 1 0 47 55A3 3 0 1 0 47 49'}
}
export function CategoryIcon({category}: {category:string}) {
 const v=categoryVisualMap[category]??categoryVisualMap.mall
 if(v.imageSrc)return <img className="category-asset" src={v.imageSrc} alt={v.alt??v.label}/>
 if(v.iconComponent)return <span className="category-asset" aria-hidden="true">{v.iconComponent}</span>
 return <svg width="56" height="56" viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="2.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={v.path??categoryVisualMap.mall.path}/></svg>
}
