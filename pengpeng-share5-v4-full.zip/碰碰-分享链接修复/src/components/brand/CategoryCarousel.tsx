import { SubcategoryVisualSlot } from './subcategoryVisualMap'
import { useRef, useEffect, useState } from 'react'
import { CATEGORY_TREE } from '../../mock/constants'
import type { CategoryValue } from '../../types'
import { CategoryIcon, categoryVisualMap } from './categoryVisualMap'
import { RoughArrow, RoughBorder } from './RoughBorder'
export function CategoryCarousel({value,onChange}: {value:CategoryValue|null;onChange:(v:CategoryValue)=>void}) {
 const rail=useRef<HTMLDivElement>(null)
 const current=CATEGORY_TREE.find(c=>c.key===value?.primary)
 const [edges,setEdges]=useState({left:false,right:true})
 const gesture=useRef(false)
 const startX=useRef(0)
 const dragged=useRef(false)
 const timer=useRef<ReturnType<typeof setTimeout>>()
 const valueRef=useRef(value);valueRef.current=value
 const changeRef=useRef(onChange);changeRef.current=onChange
 const updateEdges=()=>{const r=rail.current;if(r)setEdges({left:r.scrollLeft>3,right:r.scrollWidth-r.clientWidth-r.scrollLeft>3})}
 const select=(index:number,center=true)=>{
  const c=CATEGORY_TREE[index];if(!c)return
  if(c.key!==valueRef.current?.primary)changeRef.current({primary:c.key,secondary:c.children[0]??''})
  const r=rail.current,el=r?.children[index] as HTMLElement|undefined
  if(center&&r&&el){gesture.current=false;r.scrollTo({left:el.offsetLeft-(r.clientWidth-el.offsetWidth)/2,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'})}
 }
 const nearest=()=>{const r=rail.current;if(!r)return 0;let index=0,distance=Infinity;Array.from(r.children).forEach((c,i)=>{const el=c as HTMLElement;const d=Math.abs(el.offsetLeft+el.offsetWidth/2-r.scrollLeft-r.clientWidth/2);if(d<distance){distance=d;index=i}});return index}
 useEffect(()=>{
  const r=rail.current;if(!r)return
  const index=CATEGORY_TREE.findIndex(c=>c.key===valueRef.current?.primary)
  const el=r.children[Math.max(0,index)] as HTMLElement
  r.scrollLeft=el.offsetLeft-(r.clientWidth-el.offsetWidth)/2
  updateEdges()
  const ro=new ResizeObserver(updateEdges);ro.observe(r)
  return ()=>{ro.disconnect();clearTimeout(timer.current)}
 },[])
 const arrow=(direction:number)=>{clearTimeout(timer.current);gesture.current=false;dragged.current=false;select(Math.max(0,Math.min(CATEGORY_TREE.length-1,nearest()+direction)))}
 return <section className="category-menu" aria-label="想做的事">
  <RoughBorder variant="menu"/>
  <div className="category-rail-wrap">
   <button type="button" className="carousel-arrow carousel-arrow-left" aria-label="上一个场景" disabled={!edges.left} onClick={()=>arrow(-1)}><RoughArrow direction="left"/></button>
   <div className="category-carousel" ref={rail} role="group" aria-label="一级品类"
    onPointerDown={e=>{startX.current=e.clientX;dragged.current=false;gesture.current=true}}
    onPointerMove={e=>{if((e.buttons||e.pointerType==='touch')&&Math.abs(e.clientX-startX.current)>10)dragged.current=true}}
    onTouchStart={()=>{gesture.current=true}}
    onWheel={()=>{gesture.current=true}}
    onScroll={()=>{updateEdges();if(!gesture.current)return;clearTimeout(timer.current);timer.current=setTimeout(()=>{gesture.current=false;select(nearest(),false)},160)}}>
    {CATEGORY_TREE.map((c,i)=><button key={c.key} type="button" aria-label={c.name} aria-pressed={c.key===value?.primary} className={`category-option ${c.key===value?.primary?'selected':''}`} onClick={()=>{if(!dragged.current)select(i)}} onKeyDown={e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();const next=Math.max(0,Math.min(CATEGORY_TREE.length-1,i+(e.key==='ArrowRight'?1:-1)));select(next);(rail.current?.children[next] as HTMLElement)?.focus({preventScroll:true})}}}>
     {c.key===value?.primary&&<RoughBorder variant="circle"/>}<CategoryIcon category={c.key}/><b>{categoryVisualMap[c.key]?.label??c.name}</b><small>{c.name}</small>
    </button>)}
   </div>
   <button type="button" className="carousel-arrow carousel-arrow-right" aria-label="下一个场景" disabled={!edges.right} onClick={()=>arrow(1)}><RoughArrow direction="right"/></button>
  </div>
  {current ? <div className="category-submenu" aria-live="polite">
   <h2>{current.name}</h2>
   <div className="category-subitems">{current.children.map(s=><button type="button" key={s} aria-pressed={s===value?.secondary} className={s===value?.secondary?'selected':''} onClick={()=>onChange({primary:current.key,secondary:s})}>{s}<span aria-hidden="true">{s===value?.secondary?'✓':<SubcategoryVisualSlot name={s}/>}</span></button>)}</div>
  </div> : <p className="category-empty-hint">先选一个想做的</p>}
 </section>
}
