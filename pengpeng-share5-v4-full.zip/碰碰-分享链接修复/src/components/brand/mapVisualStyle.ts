import type { MapVisualMode } from '../../config/brandVisual'
/** Official BMap v3 styleJson format. Colors only: never hide labels, POIs or roads. */
export const WARM_PAPER_MAP_STYLE = [
 {featureType:'land',elementType:'geometry',stylers:{color:'#eee8dcff'}},
 {featureType:'water',elementType:'geometry',stylers:{color:'#c1d1d1ff'}},
 {featureType:'green',elementType:'geometry',stylers:{color:'#cbd3bdff'}},
 {featureType:'manmade',elementType:'geometry',stylers:{color:'#e3dacbff'}},
 {featureType:'road',elementType:'geometry.fill',stylers:{color:'#fffaf0ff'}},
 {featureType:'road',elementType:'geometry.stroke',stylers:{color:'#cbbdA7ff'}},
 {featureType:'highway',elementType:'geometry.fill',stylers:{color:'#e5cba6ff'}},
 {featureType:'highway',elementType:'geometry.stroke',stylers:{color:'#bfa680ff'}},
 {featureType:'road',elementType:'labels.text.fill',stylers:{color:'#665544ff'}},
 {featureType:'road',elementType:'labels.text.stroke',stylers:{color:'#fff9eeff'}},
 {featureType:'poilabel',elementType:'labels.text.fill',stylers:{color:'#5d554aff'}},
 {featureType:'poilabel',elementType:'labels.text.stroke',stylers:{color:'#fff9eeff'}},
 {featureType:'districtlabel',elementType:'labels.text.fill',stylers:{color:'#514b41ff'}},
 {featureType:'districtlabel',elementType:'labels.text.stroke',stylers:{color:'#fff9eeff'}},
]
export function applyMapVisualStyle(map: {setMapStyleV2?:(options:{styleJson:typeof WARM_PAPER_MAP_STYLE})=>void;setMapStyle?:(options:{style:string})=>void}, mode:MapVisualMode):MapVisualMode {
 if(typeof map.setMapStyleV2!=='function')return 'default'
 try {map.setMapStyleV2({styleJson:mode==='warmPaper'?WARM_PAPER_MAP_STYLE:[]});return mode}
 catch {
  try {map.setMapStyleV2({styleJson:[]})} catch {try {map.setMapStyle?.({style:'normal'})} catch {/* Leave native map intact. */}}
  return 'default'
 }
}
