import { useEffect, useRef, useState, type CSSProperties } from 'react'
import { BRAND_SLOGAN } from '../../config/brandVisual'
import { SplashCharacterLeft, SplashCharacterRight } from './BrandIllustration'
import { BrandWordmark } from './BrandWordmark'

type SplashPhase = 'playing' | 'holding' | 'exiting'
/** Presentation lifecycle: actual animation completion → hold → exit → enter. */
export function BrandSplash({ onEnter }: { onEnter: () => void }) {
 const [phase,setPhase]=useState<SplashPhase>('playing')
 const entered=useRef(false)
 const enterRef=useRef(onEnter);enterRef.current=onEnter
 const completed=useRef(new Set<string>())
 useEffect(()=>{
  const media=matchMedia('(prefers-reduced-motion: reduce)')
  const reduced=()=>{if(media.matches)setPhase(p=>p==='playing'?'holding':p)}
  reduced();media.addEventListener('change',reduced)
  return ()=>media.removeEventListener('change',reduced)
 },[])
 useEffect(()=>{
  if(phase!=='holding')return
  const timer=window.setTimeout(()=>setPhase('exiting'),1000)
  return ()=>window.clearTimeout(timer)
 },[phase])
 const enter=()=>{if(!entered.current){entered.current=true;enterRef.current()}}
 return <section className={`brand-splash splash-${phase}`} data-phase={phase} aria-label="碰碰开屏"
  onAnimationEnd={e=>{
   if(e.target===e.currentTarget&&e.animationName==='splash-exit'){enter();return}
   if(phase!=='playing')return
   completed.current.add(e.animationName)
   // word-in ends last on the slogan (1.9s); both characters must also finish.
   if((e.target as HTMLElement).classList.contains('splash-slogan')&&completed.current.has('splash-left')&&completed.current.has('splash-right'))setPhase('holding')
  }}>
  <div className="splash-lockup-stage">
   <div className="splash-animals"><SplashCharacterLeft/><SplashCharacterRight/>
    <div className="splash-confetti" aria-hidden="true">{Array.from({length:8},(_,i)=><i key={i} style={{'--x':`${(i-3.5)*23}px`,'--y':`${-55-Math.sin(i)*30}px`,'--r':`${i*51}deg`} as CSSProperties}/>)}</div>
   </div>
   <div className="splash-wordmark"><BrandWordmark impact/></div>
   <div className="splash-brand-cn">碰 碰</div>
  </div>
  <p className="splash-slogan">{BRAND_SLOGAN}</p>
 </section>
}
