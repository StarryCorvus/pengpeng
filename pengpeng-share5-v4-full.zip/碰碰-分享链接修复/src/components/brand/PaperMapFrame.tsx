/** Four fixed, distinct deckled SVG edges. Map DOM, labels and hit testing are untouched. */
export function PaperMapFrame() {
 return <div className="paper-map-edge" aria-hidden="true">{['top','right','bottom','left'].map(edge=><div className={`paper-edge paper-edge-${edge}`} key={edge}/>)}</div>
}
