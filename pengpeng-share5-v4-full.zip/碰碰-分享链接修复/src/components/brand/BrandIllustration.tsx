import { BRAND_CAT, BRAND_DOG, BRAND_ILLUSTRATIONS } from './brandAssets'
export function CharacterPair({leftSrc=BRAND_CAT,rightSrc=BRAND_DOG}: {leftSrc?:string;rightSrc?:string}) {
 return <div className="character-pair"><img className="character-cat" src={leftSrc} alt=""/><img className="character-dog" src={rightSrc} alt=""/></div>
}
/** Optional src or leftSrc/rightSrc; defaults to transparent, cropped user artwork. */
export function BrandIllustration({className='',variant='people',src,leftSrc,rightSrc}:{className?:string;variant?:'people'|'category';src?:string;leftSrc?:string;rightSrc?:string}) {
 const custom=src||BRAND_ILLUSTRATIONS[variant]
 return <div className={`brand-illustration ${className}`} aria-hidden="true">{custom?<img className="illustration-custom" src={custom} alt=""/>:<CharacterPair leftSrc={leftSrc} rightSrc={rightSrc}/>}</div>
}
export function SplashCharacterLeft(){return <div className="splash-character splash-left"><img src={BRAND_ILLUSTRATIONS.left||BRAND_CAT} alt=""/></div>}
export function SplashCharacterRight(){return <div className="splash-character splash-right"><img src={BRAND_ILLUSTRATIONS.right||BRAND_DOG} alt=""/></div>}
