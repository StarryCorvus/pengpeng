import menuFrame from '../../assets/brand/material/menu-brush-frame.svg'
import { ROUGH_LINE_WIDTH } from '../../config/brandVisual'
/** Fixed paths: no render-time randomness, no filter, no hitbox change. */
export function RoughBorder({variant='box'}:{variant?:'box'|'circle'|'underline'|'menu'}) {
 if(variant==='menu')return <img src={menuFrame} className="rough-border rough-menu" alt="" aria-hidden="true"/>
 const paths=variant==='circle'?[
  'M51 4C78 1 96 14 96 39C101 67 88 95 53 96C23 98 6 88 5 61C0 30 12 7 51 4Z',
  'M47 6C76 0 94 15 97 42C98 72 83 95 52 94C19 96 4 83 6 57C4 26 17 8 47 6Z'
 ]:variant==='underline'?['M3 64Q29 43 54 54T97 43','M5 73Q35 55 62 59T94 52']:[
  'M4 5Q80 2 179 4T356 4L357 51Q267 54 179 52T3 52L4 5Z',
  'M5 3Q98 6 181 2L355 6Q354 29 358 50Q270 51 180 54L4 50Q6 29 5 3Z'
 ]
 return <svg className={`rough-border rough-${variant}`} viewBox={variant==='box'?'0 0 360 56':'0 0 100 100'} preserveAspectRatio="none" aria-hidden="true" focusable="false">{paths.map((d,i)=><path key={d} d={d} fill="none" stroke="currentColor" strokeWidth={i?ROUGH_LINE_WIDTH*.48:ROUGH_LINE_WIDTH} vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" opacity={i?.55:1}/>)}</svg>
}
export function RoughArrow({direction}:{direction:'left'|'right'}) {
 return <svg width="22" height="28" viewBox="0 0 24 32" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{transform:direction==='left'?'scaleX(-1)':undefined}}><path d="M6 5L18 16L7 27" strokeWidth="3"/><path d="M8 4L19 17L8 26" strokeWidth="1.1" opacity=".55"/></svg>
}
