/** Shared fixed ink stroke; decorative and pointer-transparent. */
export function FlowTitleUnderline() {
 return <svg className="flow-title-underline" viewBox="0 0 240 16" aria-hidden="true" focusable="false"><path d="M5 11 Q62 9 112 8 T232 3 L228 6 Q160 9 112 11 T8 14 Z" fill="currentColor"/><path d="M15 13 Q126 10 222 6" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" opacity=".5"/></svg>
}
