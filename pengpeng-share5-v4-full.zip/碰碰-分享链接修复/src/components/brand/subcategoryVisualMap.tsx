import { useState, type ReactNode } from 'react'
export type SubcategoryVisual = { imageSrc?:string; iconComponent?:ReactNode; fallback?:'dot'|'spark'|'mark'; alt?:string }
const glyph=(path:string)=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={path}/></svg>
/** UI-only asset replacement point; do not change CATEGORY_TREE. */
export const subcategoryVisualMap:Record<string,SubcategoryVisual>={
 '火锅':{iconComponent:glyph('M4 11H20L18 20H6Z M3 14H1 M21 14H23 M9 7Q7 4 10 2 M15 7Q13 4 16 2')},
 '烧烤烤肉':{iconComponent:glyph('M5 3L20 21 M2 9L12 2 M7 15L17 8 M12 21L22 14')},
 '地方菜':{iconComponent:glyph('M3 13Q12 9 21 13Q20 20 12 20Q4 20 3 13Z M8 7L13 2 M13 8L18 3')},
 '自助餐':{iconComponent:glyph('M4 17Q4 7 12 7Q20 7 20 17 M2 19H22 M10 4H14')},
 '西餐':{iconComponent:glyph('M4 2V9Q7 13 10 9V2 M7 2V22 M19 2Q14 8 18 13H20 M20 2V22')},
 '咖啡馆':{iconComponent:glyph('M4 8H17V18Q11 23 5 18Z M17 10Q24 9 21 15H17 M8 4L10 1')},
 '全部分类':{fallback:'spark'},
}
export function SubcategoryVisualSlot({name}:{name:string}) {
 const visual=subcategoryVisualMap[name]??{fallback:'mark'}
 const [failed,setFailed]=useState(false)
 return <span className="subcategory-visual" aria-hidden="true">{visual.imageSrc&&!failed?<img src={visual.imageSrc} alt="" onError={()=>setFailed(true)}/>:visual.iconComponent??glyph(visual.fallback==='spark'?'M12 2L14 9L22 12L14 14L12 22L9 14L2 12L9 9Z':visual.fallback==='dot'?'M12 8A4 4 0 1 0 12 16A4 4 0 1 0 12 8':'M6 17Q3 5 14 5Q23 7 18 18Q10 23 6 17') }</span>
}
