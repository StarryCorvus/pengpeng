import { useState } from 'react'
import { ShopImage } from '../result/ShopImage'
/** Image loading failure changes presentation only, never the shop's data. */
export function ShopPhoto({src,alt,primary,sub,className,size='sm'}:{src:string;alt:string;primary:string;sub:string;className?:string;size?:'sm'|'lg'}) {
 const [failedSrc,setFailedSrc]=useState<string|null>(null)
 return failedSrc===src?<ShopImage primary={primary} sub={sub} className={className} size={size}/>:<img src={src} alt={alt} className={className} loading="lazy" onError={()=>setFailedSrc(src)}/>
}
