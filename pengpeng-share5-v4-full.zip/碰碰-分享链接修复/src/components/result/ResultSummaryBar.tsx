// ============================================================
// 结果页顶部固定需求摘要栏：点击任意参数唤起修改弹窗
// ============================================================

import type { FormState } from '../../types'
import { CATEGORY_NAME } from '../../mock/constants'
import { pointNickname } from '../../utils/format'
import { IconBack, IconEdit, ModeIcon } from '../common/Icons'

export type EditScope = 'points' | 'category'

export function ResultSummaryBar({
  form,
  colors,
  onEdit,
  onBack,
}: {
  form: FormState
  colors: string[]
  /** scope 为空 = 完整编辑；scope 有值 = 局部快捷修改（points 带下标） */
  onEdit: (scope?: EditScope, index?: number) => void
  onBack: () => void
}) {
  const catName = form.category
    ? `${CATEGORY_NAME[form.category.primary] ?? ''}${form.category.secondary && form.category.secondary !== '全部分类' ? `·${form.category.secondary}` : ''}`
    : '选个品类'

  return (
    <div className="summary-bar">
      <div className="summary-top">
        <button type="button" className="icon-btn" onClick={onBack} aria-label="返回需求填写页">
          <IconBack size={20} />
        </button>
        <div className="summary-brand">碰碰</div>
        <span aria-hidden="true" />
      </div>
      <div className="summary-params-row"><div className="summary-chips">
        {form.points.map((p, i) => (
          <span
            key={p.id}
            className="sum-chip"
            onClick={(e) => {
              e.stopPropagation()
              onEdit('points', i)
            }}
            title={p.name}
          >
            <i className="sum-dot" style={{ background: colors[i % colors.length] }} />
            <span className="sum-name">{pointNickname(p, i)}</span>
            <ModeIcon mode={p.mode} size={12} />
          </span>
        ))}
        <span
          className="sum-chip sum-cat"
          onClick={(e) => {
            e.stopPropagation()
            onEdit('category')
          }}
        >
          🏷️ {catName}
        </span>
      </div>
        <button type="button" className="summary-edit" onClick={() => onEdit()}>
          <span className="summary-edit-pill"><IconEdit size={14} />修改</span>
        </button>
      </div>
    </div>
  )
}
