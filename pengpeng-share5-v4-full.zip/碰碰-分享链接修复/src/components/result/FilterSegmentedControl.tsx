import { useId, useRef, type ReactNode } from 'react'
import { FilterVisual, type FilterVisualKey } from '../brand/filterVisualMap'

type Value = number | null
type Gesture = { id: number; x: number; y: number; intent: 'pending' | 'horizontal' | 'vertical' }

/** Controlled presentation only: values and custom validation remain in ResultPage. */
export function FilterSegmentedControl({ label, icon, value, options, onChange, onCustom, customOpen, children }: {
  label: string
  icon: FilterVisualKey
  value: Value
  options: readonly Value[]
  onChange: (value: Value) => void
  onCustom: () => void
  customOpen: boolean
  children?: ReactNode
}) {
  const id = useId()
  const buttons = useRef<(HTMLButtonElement | null)[]>([])
  const gesture = useRef<Gesture | null>(null)
  const suppressClick = useRef(false)
  const selectedIndex = options.indexOf(value)
  const customActive = selectedIndex < 0
  const choose = (index: number) => {
    onChange(options[index])
    buttons.current[index]?.focus({ preventScroll: true })
  }
  return <div className="filter-segment-group">
    <span id={id} className="filter-segment-label"><FilterVisual name={icon}/>{label}</span>
    <div className="filter-segment-control">
      <div className="filter-segment-options" role="radiogroup" aria-labelledby={id} aria-orientation="horizontal"
        onPointerDown={(e) => {
          if (!e.isPrimary || e.button !== 0) return
          gesture.current = { id: e.pointerId, x: e.clientX, y: e.clientY, intent: 'pending' }
          suppressClick.current = false
        }}
        onPointerMove={(e) => {
          const g = gesture.current
          if (!g || g.id !== e.pointerId) return
          const dx = Math.abs(e.clientX - g.x), dy = Math.abs(e.clientY - g.y)
          if (g.intent === 'pending') {
            if (Math.max(dx, dy) < 7) return
            g.intent = dx > dy * 1.15 ? 'horizontal' : 'vertical'
            suppressClick.current = true
            if (g.intent === 'horizontal') e.currentTarget.setPointerCapture(e.pointerId)
          }
          if (g.intent !== 'horizontal') return
          const rect = e.currentTarget.getBoundingClientRect()
          const index = Math.max(0, Math.min(options.length - 1, Math.floor((e.clientX - rect.left) / rect.width * options.length)))
          if (options[index] !== value) choose(index)
        }}
        onPointerUp={(e) => {
          if (gesture.current?.id !== e.pointerId) return
          gesture.current = null
          if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId)
        }}
        onPointerCancel={() => { gesture.current = null; suppressClick.current = true }}
        onLostPointerCapture={(e) => { if (e.target === e.currentTarget) gesture.current = null }}
        onClickCapture={(e) => {
          if (suppressClick.current && e.detail > 0) { e.preventDefault(); e.stopPropagation(); suppressClick.current = false }
        }}>
        <span className="filter-active-indicator" aria-hidden="true" style={{ opacity: selectedIndex < 0 ? 0 : 1, transform: `translateX(${Math.max(0, selectedIndex) * 100}%)` }}/>
        {options.map((option, index) => <button key={option ?? 'all'} ref={(el) => { buttons.current[index] = el }}
          type="button" role="radio" aria-checked={selectedIndex === index}
          tabIndex={index === (selectedIndex < 0 ? 0 : selectedIndex) ? 0 : -1}
          className="filter-segment" onClick={() => choose(index)}
          onKeyDown={(e) => {
            let next: number
            if (e.key === 'ArrowRight') next = (index + 1) % options.length
            else if (e.key === 'ArrowLeft') next = (index + options.length - 1) % options.length
            else if (e.key === 'Home') next = 0
            else if (e.key === 'End') next = options.length - 1
            else return
            e.preventDefault(); choose(next)
          }}>{option == null ? '全部' : `≤${option}分`}</button>)}
      </div>
    </div>
    <button type="button" className={`filter-custom-trigger${customActive || customOpen ? ' active' : ''}`}
      aria-label={`${label}自定义${customActive ? `：≤${value}分` : ''}`} aria-expanded={customOpen}
      aria-controls={`${id}-editor`} onClick={onCustom}>
      {customActive ? `≤${value}分` : '自定义'}
    </button>
    {customOpen && <div id={`${id}-editor`}>{children}</div>}
  </div>
}
