// ============================================================
// 店铺预览底部弹窗（移动端地图图钉点击后弹出）：
// 展示店铺基本信息 + 各方通勤信息 + 「查看详情」入口。
// 点「查看详情」→ 关闭本弹窗，打开居中的 ShopDetailModal。
// ============================================================

import type { ShopWithCommute, TravelPoint } from '../../types'
import { MODE_META } from '../../mock/constants'
import { dedupeCommutes, fmtFare, fmtMinutesShort, fmtPrice, fmtRating, pointNickname } from '../../utils/format'
import { IconNav, IconStar, ModeIcon } from '../common/Icons'
import { BottomSheet } from '../common/BottomSheet'
import { ShopImage } from './ShopImage'

export function ShopPreviewSheet({
  shop,
  points,
  colors,
  open,
  onClose,
  onViewDetail,
  onNavigate,
}: {
  shop: ShopWithCommute | null
  points: TravelPoint[]
  colors: string[]
  open: boolean
  onClose: () => void
  /** 点「查看详情」：关闭预览、打开详情弹窗 */
  onViewDetail: (shop: ShopWithCommute) => void
  /** 点「导航」：模拟打开导航 */
  onNavigate: (shop: ShopWithCommute) => void
}) {
  if (!shop) return null

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      footer={
        <div className="preview-sheet-footer">
          <button
            type="button"
            className="ghost"
            onClick={() => onNavigate(shop)}
          >
            <IconNav size={14} />
            导航
          </button>
          <button
            type="button"
            className="btn-primary"
            onClick={() => onViewDetail(shop)}
          >
            查看详情
          </button>
        </div>
      }
    >
      <div className="preview-sheet-head">
        <ShopImage primary={shop.primary} sub={shop.sub} size="sm" className="preview-thumb" />
        <div className="preview-info">
          <b className="preview-name">{shop.name}</b>
          <div className="preview-meta">
            <span className="pm-rating">
              <IconStar size={12} className="star" />
              {fmtRating(shop.rating)}
            </span>
            <span>人均{fmtPrice(shop.perCapita)}</span>
            <span>{shop.category}</span>
          </div>
          <div className="preview-fairness">
            时间差 {shop.fairness} 分钟 · 大家平均约{Math.round(shop.avg)} 分钟
          </div>
        </div>
      </div>

      <div className="preview-commute">
        <p className="preview-commute-title">各方通勤</p>
        {dedupeCommutes(shop.commutes).map((c) => {
          const idx = points.findIndex((p) => p.id === c.pointId)
          const color = colors[Math.max(0, idx) % colors.length]
          const pt = points[idx]
          return (
            <div key={`${c.pointName}_${c.mode}`} className="preview-commute-row">
              <i className="pc-dot" style={{ background: color }} />
              <span className="pc-from">
                {pointNickname(pt, idx)}
                {c.count > 1 && <em className="pc-count">×{c.count}人</em>}
                <em className="pc-place">{c.pointName}</em>
              </span>
              <span className="pc-mode" title={MODE_META[c.mode].label}>
                <ModeIcon mode={c.mode} size={14} />
              </span>
              <b className="pc-time">{fmtMinutesShort(c.minutes)}</b>
              <span className="pc-fare">{fmtFare(c.fare)}</span>
            </div>
          )
        })}
      </div>
    </BottomSheet>
  )
}
