// ============================================================
// 结果页顶部参数快速修改弹窗（BottomSheet）：
// 出发点位 / 出行方式 / 业态品类，修改完成自动重算
// ============================================================

import { useEffect, useState } from 'react'
import type { FormState } from '../../types'
import { POINT_COLORS } from '../../mock/constants'
import { pointNickname } from '../../utils/format'
import { BottomSheet } from '../common/BottomSheet'
import { useToast } from '../common/Toast'
import { StartPointList } from '../form/StartPointList'
import { CategorySelect } from '../form/CategorySelect'

export function ParamEditSheet({
  open,
  onClose,
  form,
  onApply,
}: {
  open: boolean
  onClose: () => void
  form: FormState
  /** 应用修改：父组件收到新表单后自动重算并刷新地图与列表 */
  onApply: (next: FormState) => void
}) {
  const [draft, setDraft] = useState<FormState>(form)
  const { show } = useToast()

  // 每次打开时以当前表单为草稿
  useEffect(() => {
    if (open) setDraft(form)
  }, [open, form])

  const missing: string[] = []
  if (draft.points.length < 2) missing.push('至少 2 人')
  draft.points.forEach((p, i) => {
    if (!p.name) missing.push(`${pointNickname(p, i)}没选位置`)
  })
  if (!draft.category) missing.push('选个想干的事')

  const apply = () => {
    if (missing.length > 0) {
      show(`还差：${missing.join('、')}`, 'warn')
      return
    }
    onApply(draft)
  }

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title="修改需求 · 重新计算"
      footer={
        <>
          <button type="button" className="btn-ghost btn-half" onClick={onClose}>
            取消
          </button>
          <button type="button" className={`btn-primary btn-half ${missing.length ? 'disabled' : ''}`} onClick={apply}>
            重新计算
          </button>
        </>
      }
    >
      <div className="sheet-section">
        <h4>🧑‍🤝‍🧑 谁要碰碰 & 出行方式</h4>
        <StartPointList points={draft.points} onChange={(points) => setDraft({ ...draft, points })} compact />
      </div>
      <div className="sheet-section">
        <h4>🏷️ 想干什么</h4>
        <CategorySelect value={draft.category} onChange={(category) => setDraft({ ...draft, category })} />
        <p className="sheet-legend">
          {draft.points.map((p, i) => (
            <span key={p.id}>
              <i style={{ background: POINT_COLORS[i % POINT_COLORS.length] }} />
              {pointNickname(p, i)}
            </span>
          ))}
        </p>
      </div>
    </BottomSheet>
  )
}
