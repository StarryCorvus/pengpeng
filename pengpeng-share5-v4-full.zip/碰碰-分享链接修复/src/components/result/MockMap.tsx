import type { MapVisualMode } from '../../config/brandVisual'
// ============================================================
// Mock 地图组件：
// 原型阶段不加载真实高德 JS API，用 SVG 模拟地图底图（河流/道路/公园），
// 渲染 出发点 marker + POI 图钉（AI 推荐徽标）+ 店铺详情卡片。
// 已抽象出与真实地图一致的数据结构（经纬度 + 米制半径），后续可平替为高德 AMap 实现。
// ============================================================

import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react'
import type { GeoPoint, ShopWithCommute, TravelPoint } from '../../types'
import { clamp, fromMeters, M_PER_DEG_LAT, M_PER_DEG_LNG, MAP_DECOR, toMeters } from '../../mock/geo'
import { categoryEmoji } from '../../mock/constants'
import { pointNickname } from '../../utils/format'
import { IconLocate, IconZoomIn, IconZoomOut } from '../common/Icons'

const MIN_SCALE = 0.005 // px/米（最远视野）
const MAX_SCALE = 0.12 // px/米（最近视野）

interface View {
  scale: number
  cx: number // 视野中心经度
  cy: number // 视野中心纬度
}

/** 经纬度 -> 屏幕坐标 */
function project(lng: number, lat: number, v: View, w: number, h: number) {
  return {
    x: w / 2 + (lng - v.cx) * M_PER_DEG_LNG * v.scale,
    y: h / 2 - (lat - v.cy) * M_PER_DEG_LAT * v.scale,
  }
}

/** 屏幕坐标 -> 经纬度 */
function screenToGeo(x: number, y: number, v: View, w: number, h: number): GeoPoint {
  return {
    lng: v.cx + (x - w / 2) / (M_PER_DEG_LNG * v.scale),
    lat: v.cy - (y - h / 2) / (M_PER_DEG_LAT * v.scale),
  }
}

/** 根据目标点集计算适配视野 */
function fitView(targets: GeoPoint[], w: number, h: number): View {
  const ms = targets.map((p) => toMeters(p.lng, p.lat))
  const minX = Math.min(...ms.map((m) => m.x))
  const maxX = Math.max(...ms.map((m) => m.x))
  const minY = Math.min(...ms.map((m) => m.y))
  const maxY = Math.max(...ms.map((m) => m.y))
  const bw = Math.max(maxX - minX, 600)
  const bh = Math.max(maxY - minY, 600)
  // 在目标点集外包各放大 50% 作为视野余量，避免最外侧图钉的
  // 徽标（上方）、店名气泡（下方）以及螺旋展开后的图钉被地图容器裁掉
  const effW = bw * 1.5
  const effH = bh * 1.5
  const scale = clamp(Math.min((w - 56) / effW, (h - 72) / effH), MIN_SCALE, MAX_SCALE)
  const c = fromMeters((minX + maxX) / 2, (minY + maxY) / 2)
  return { scale, cx: c.lng, cy: c.lat }
}

/** 自适应网格步长（米） */
function gridStep(scale: number): number {
  for (const s of [200, 500, 1000, 2000, 5000]) {
    if (s * scale >= 56) return s
  }
  return 10000
}

/** 屏幕像素包围盒 */
interface Box {
  x1: number
  y1: number
  x2: number
  y2: number
}

/** 以中心点构建包围盒（halfW/halfH 为半宽/半高，px） */
function boxOf(cx: number, cy: number, halfW: number, halfH: number): Box {
  return { x1: cx - halfW, y1: cy - halfH, x2: cx + halfW, y2: cy + halfH }
}

/** 两个包围盒是否相交（AABB 碰撞） */
function boxCollides(a: Box, b: Box): boolean {
  return a.x1 < b.x2 && a.x2 > b.x1 && a.y1 < b.y2 && a.y2 > b.y1
}

/** 店名气泡估算宽度：中文字符 ≈ 10px/字 + 两侧 padding */
function bubbleW(name: string): number {
  return Math.min(84, Math.max(44, name.length * 10 + 14))
}

export function MockMap({
  points,
  colors,
  shops,
  recommendedId,
  onShopSelect,
  resetKey,
}: {
  points: TravelPoint[]
  colors: string[]
  shops: ShopWithCommute[]
  /** AI 推荐店铺 id（图钉加徽标） */
  recommendedId?: string
  /** 点击图钉：由页面打开底部店铺预览弹窗 */
  onShopSelect: (shop: ShopWithCommute) => void
  /** 每次重算完成后递增，触发自动适配视野 */
  resetKey: number
  visualStyle?: MapVisualMode
  onStyleApplied?: (mode: MapVisualMode) => void
}) {
  const wrapRef = useRef<HTMLDivElement>(null)
  const [size, setSize] = useState({ w: 360, h: 480 })
  const [view, setView] = useState<View>({ scale: 0.02, cx: 116.44, cy: 39.94 })
  const dragRef = useRef<{ sx: number; sy: number; v: View } | null>(null)

  // 供原生事件闭包读取最新状态（避免 stale closure）
  const viewRef = useRef(view)
  viewRef.current = view
  const sizeRef = useRef(size)
  sizeRef.current = size
  const shopsRef = useRef(shops)
  shopsRef.current = shops
  const onShopSelectRef = useRef(onShopSelect)
  onShopSelectRef.current = onShopSelect

  // 容器尺寸测量
  useEffect(() => {
    const el = wrapRef.current
    if (!el) return
    const ro = new ResizeObserver((entries) => {
      const r = entries[0].contentRect
      if (r.width > 0 && r.height > 0) setSize({ w: r.width, h: r.height })
    })
    ro.observe(el)
    setSize({ w: el.clientWidth || 360, h: el.clientHeight || 480 })
    return () => ro.disconnect()
  }, [])

  // 数据变化后自动适配视野：以「出发点 + 全部候选店铺」取景，保证每家店图钉都可见
  const targets = useMemo<GeoPoint[]>(() => {
    const t: GeoPoint[] = points.map((p) => ({ lng: p.lng, lat: p.lat }))
    shops.forEach((s) => t.push({ lng: s.lng, lat: s.lat }))
    return t
  }, [points, shops])
  const targetsRef = useRef(targets)
  targetsRef.current = targets

  useEffect(() => {
    setView(fitView(targets, size.w, size.h))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resetKey, size.w, size.h])

  // 滚轮缩放（非被动监听以便阻止默认滚动）
  useEffect(() => {
    const el = wrapRef.current
    if (!el) return
    const onWheel = (e: WheelEvent) => {
      e.preventDefault()
      const rect = el.getBoundingClientRect()
      const mx = e.clientX - rect.left
      const my = e.clientY - rect.top
      const factor = e.deltaY < 0 ? 1.25 : 0.8
      setView((v) => {
        const ns = clamp(v.scale * factor, MIN_SCALE, MAX_SCALE)
        const g = screenToGeo(mx, my, v, size.w, size.h)
        return {
          scale: ns,
          cx: g.lng - (mx - size.w / 2) / (M_PER_DEG_LNG * ns),
          cy: g.lat + (my - size.h / 2) / (M_PER_DEG_LAT * ns),
        }
      })
    }
    el.addEventListener('wheel', onWheel, { passive: false })
    return () => el.removeEventListener('wheel', onWheel)
  }, [size])

  // 原生指针事件：统一处理 拖拽平移 + 双指捏合缩放 + 图钉轻触（移动端可靠）
  useEffect(() => {
    const el = wrapRef.current
    if (!el) return

    const pointers = new Map<number, { x: number; y: number }>()
    let pinch: { dist: number; scale: number; midX: number; midY: number; view: View } | null = null
    let pinTap: { id: number; x: number; y: number; time: number; shopId: string } | null = null
    let controlTap: { id: number; x: number; y: number; time: number; action: string } | null = null

    const getShopId = (t: EventTarget | null): string | null => {
      const pin = (t as HTMLElement | null)?.closest?.('.poi-pin') as HTMLElement | null
      return pin?.dataset?.shopId ?? null
    }
    const getAction = (t: EventTarget | null): string | null => {
      const btn = (t as HTMLElement | null)?.closest?.('[data-action]') as HTMLElement | null
      return btn?.getAttribute('data-action') ?? null
    }

    const onDown = (e: PointerEvent) => {
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY })

      if (pointers.size === 1) {
        const shopId = getShopId(e.target)
        const action = getAction(e.target)
        // 始终记录拖拽起点——即使按在图钉上，移动超过阈值后也应转为地图平移
        dragRef.current = { sx: e.clientX, sy: e.clientY, v: { ...viewRef.current } }
        if (shopId) {
          // 按在图钉上：记录轻触候选（移动超过 24px 则取消，转为拖拽）
          pinTap = { id: e.pointerId, x: e.clientX, y: e.clientY, time: Date.now(), shopId }
          controlTap = null
        } else if (action) {
          // 按在缩放/复位按钮上
          controlTap = { id: e.pointerId, x: e.clientX, y: e.clientY, time: Date.now(), action }
          pinTap = null
        } else {
          pinTap = null
          controlTap = null
        }
      } else if (pointers.size === 2) {
        // 第二指按下：进入捏合缩放，取消拖拽/轻触
        dragRef.current = null
        pinTap = null
        controlTap = null
        const pts = [...pointers.values()]
        const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y)
        if (dist > 10) {
          const midX = (pts[0].x + pts[1].x) / 2
          const midY = (pts[0].y + pts[1].y) / 2
          pinch = { dist, scale: viewRef.current.scale, midX, midY, view: { ...viewRef.current } }
          for (const id of pointers.keys()) {
            try { el.setPointerCapture(id) } catch { /* noop */ }
          }
        }
      }
    }

    const onMove = (e: PointerEvent) => {
      const p = pointers.get(e.pointerId)
      if (!p) return
      p.x = e.clientX
      p.y = e.clientY

      if (pointers.size === 2 && pinch) {
        // 双指捏合：以两指中点为锚点缩放
        const pts = [...pointers.values()]
        const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y)
        if (dist < 1) return
        const factor = dist / pinch.dist
        const ns = clamp(pinch.scale * factor, MIN_SCALE, MAX_SCALE)
        const rect = el.getBoundingClientRect()
        const mx = pinch.midX - rect.left
        const my = pinch.midY - rect.top
        const g = screenToGeo(mx, my, { ...pinch.view, scale: pinch.scale }, sizeRef.current.w, sizeRef.current.h)
        setView({
          scale: ns,
          cx: g.lng - (mx - sizeRef.current.w / 2) / (M_PER_DEG_LNG * ns),
          cy: g.lat + (my - sizeRef.current.h / 2) / (M_PER_DEG_LAT * ns),
        })
      } else if (pointers.size === 1 && dragRef.current) {
        // 单指拖拽平移：移动超过 5px 才捕获指针（纯点击不捕获，避免页面跳动）
        const d = dragRef.current
        const dx = e.clientX - d.sx
        const dy = e.clientY - d.sy
        if (Math.hypot(dx, dy) > 5) {
          try { el.setPointerCapture(e.pointerId) } catch { /* noop */ }
        }
        setView({
          ...d.v,
          cx: d.v.cx - dx / (M_PER_DEG_LNG * d.v.scale),
          cy: d.v.cy + dy / (M_PER_DEG_LAT * d.v.scale),
        })
      }

      // 移动超过阈值则取消轻触判定（24px，适配移动端手指自然抖动；超过则视为拖拽）
      if (pinTap && pinTap.id === e.pointerId && Math.hypot(e.clientX - pinTap.x, e.clientY - pinTap.y) > 24) {
        pinTap = null
      }
      if (controlTap && controlTap.id === e.pointerId && Math.hypot(e.clientX - controlTap.x, e.clientY - controlTap.y) > 24) {
        controlTap = null
      }
    }

    const onUp = (e: PointerEvent) => {
      // 图钉轻触：移动不超过 24px 即触发（无时间限制，轻点/稍长按都能触发）
      if (pinTap && pinTap.id === e.pointerId) {
        if (Math.hypot(e.clientX - pinTap.x, e.clientY - pinTap.y) <= 24) {
          const shop = shopsRef.current.find((s) => s.id === pinTap!.shopId)
          if (shop) onShopSelectRef.current?.(shop)
        }
        pinTap = null
      }
      // 缩放/复位按钮轻触（原生兜底，避免移动端 React onClick 偶发不触发）
      if (controlTap && controlTap.id === e.pointerId) {
        if (Math.hypot(e.clientX - controlTap.x, e.clientY - controlTap.y) <= 24) {
          if (controlTap.action === 'zoom-in') {
            setView((v) => ({ ...v, scale: clamp(v.scale * 1.4, MIN_SCALE, MAX_SCALE) }))
          } else if (controlTap.action === 'zoom-out') {
            setView((v) => ({ ...v, scale: clamp(v.scale * 0.72, MIN_SCALE, MAX_SCALE) }))
          } else if (controlTap.action === 'refit') {
            setView(fitView(targetsRef.current, sizeRef.current.w, sizeRef.current.h))
          }
        }
        controlTap = null
      }

      pointers.delete(e.pointerId)
      if (pointers.size < 2) pinch = null
      if (pointers.size === 0) dragRef.current = null
    }

    el.addEventListener('pointerdown', onDown)
    el.addEventListener('pointermove', onMove)
    el.addEventListener('pointerup', onUp)
    el.addEventListener('pointercancel', onUp)
    return () => {
      el.removeEventListener('pointerdown', onDown)
      el.removeEventListener('pointermove', onMove)
      el.removeEventListener('pointerup', onUp)
      el.removeEventListener('pointercancel', onUp)
    }
  }, [])

  const zoomBy = (factor: number) => {
    setView((v) => ({ ...v, scale: clamp(v.scale * factor, MIN_SCALE, MAX_SCALE) }))
  }
  const refit = () => setView(fitView(targets, size.w, size.h))

  const { w, h } = size

  // 网格线（跟随视野平移缩放）
  const grid = useMemo(() => {
    const tl = screenToGeo(0, 0, view, w, h)
    const br = screenToGeo(w, h, view, w, h)
    const m1 = toMeters(tl.lng, tl.lat)
    const m2 = toMeters(br.lng, br.lat)
    const minX = Math.min(m1.x, m2.x)
    const maxX = Math.max(m1.x, m2.x)
    const minY = Math.min(m1.y, m2.y)
    const maxY = Math.max(m1.y, m2.y)
    const step = gridStep(view.scale)
    const vLines: { x: number; y1: number; y2: number }[] = []
    const hLines: { x1: number; x2: number; y: number }[] = []
    for (let x = Math.floor(minX / step) * step; x <= maxX; x += step) {
      const p = fromMeters(x, 0)
      const sp = project(p.lng, view.cy, view, w, h)
      vLines.push({ x: sp.x, y1: 0, y2: h })
    }
    for (let y = Math.floor(minY / step) * step; y <= maxY; y += step) {
      const p = fromMeters(0, y)
      const sp = project(view.cx, p.lat, view, w, h)
      hLines.push({ x1: 0, x2: w, y: sp.y })
    }
    return { vLines, hLines }
  }, [view, w, h])

  // 地图装饰物渲染（河流/道路/公园）
  const decor = useMemo(() => {
    const riverPaths = MAP_DECOR.river.map((arr) => {
      const pts: string[] = []
      for (let i = 0; i < arr.length; i += 2) {
        const p = project(arr[i], arr[i + 1], view, w, h)
        pts.push(`${p.x.toFixed(1)},${p.y.toFixed(1)}`)
      }
      return pts.join(' ')
    })
    const roadPaths = MAP_DECOR.roads.map((r) => {
      const pts: string[] = []
      for (let i = 0; i < r.pts.length; i += 2) {
        const p = project(r.pts[i], r.pts[i + 1], view, w, h)
        pts.push(`${p.x.toFixed(1)},${p.y.toFixed(1)}`)
      }
      return { pts: pts.join(' '), w: r.w }
    })
    const parks = MAP_DECOR.parks.map((pk) => {
      const a = project(pk.box[0], pk.box[1], view, w, h)
      const b = project(pk.box[2], pk.box[3], view, w, h)
      return {
        x: Math.min(a.x, b.x),
        y: Math.min(a.y, b.y),
        width: Math.abs(b.x - a.x),
        height: Math.abs(b.y - a.y),
        name: pk.name,
      }
    })
    return { riverPaths, roadPaths, parks }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view, w, h])

  /**
   * 图钉防重叠布局（视图无关，只在数据/尺寸变化时重算一次）：
   * 以「参考视野」（= 初始适配视野）的屏幕像素做包围盒螺旋展开，把求得的
   * 屏幕偏移换算成**地理偏移（经/纬度）**。渲染时用当前视野投影「真实经纬度 + 偏移」，
   * 这样无论放大 / 缩小 / 平移，每个图钉都始终锚定在地图上同一位置，
   * 不会再因缩放导致防重叠布局重算而产生「图标乱跳」。
   */
  const PIN_GAP = 10 // 包围盒外额外间距（px）
  const refView = useMemo(() => fitView(targets, w, h), [targets, w, h])
  const pinLayout = useMemo(() => {
    // 出发点 marker 作为障碍物（上方名称气泡 + 图钉，整体高约 50px）
    const placed: Box[] = points.map((p, i) => {
      const pos = project(p.lng, p.lat, refView, w, h)
      const name = pointNickname(p, i)
      return boxOf(pos.x, pos.y - 25, bubbleW(name) / 2 + PIN_GAP, 27)
    })
    return shops.slice(0, 10).map((s) => {
      const raw = project(s.lng, s.lat, refView, w, h)
      const halfW = Math.max(26, bubbleW(s.name)) / 2 + PIN_GAP
      const halfH = 27 + PIN_GAP
      let x = raw.x
      let y = raw.y
      const freeAt = (tx: number, ty: number) => placed.every((pb) => !boxCollides(boxOf(tx, ty, halfW, halfH), pb))
      let free = freeAt(x, y)
      // 与已放置元素冲突时，沿螺旋方向逐圈寻找可容纳的空位
      for (let ring = 1; !free && ring <= 16; ring++) {
        const r = ring * 18
        const steps = Math.max(14, ring * 10)
        for (let k = 0; k < steps; k++) {
          const ang = (k / steps) * Math.PI * 2 + ring * 0.618
          const tx = raw.x + Math.cos(ang) * r
          const ty = raw.y + Math.sin(ang) * r
          if (tx < 24 || tx > w - 24 || ty < 24 || ty > h - 24) continue
          if (freeAt(tx, ty)) {
            x = tx
            y = ty
            free = true
            break
          }
        }
      }
      placed.push(boxOf(x, y, halfW, halfH))
      // 屏幕偏移 -> 地理偏移（保证缩放/平移时图钉锚定在地图上）
      return {
        shop: s,
        dLng: (x - raw.x) / (M_PER_DEG_LNG * refView.scale),
        dLat: -(y - raw.y) / (M_PER_DEG_LAT * refView.scale),
      }
    })
  }, [shops, points, refView, w, h])

  return (
    <div
      ref={wrapRef}
      className="mock-map"
      style={{ cursor: dragRef.current ? 'grabbing' : 'grab' }}
    >
      {/* 地图底图 */}
      <svg className="map-svg" width={w} height={h} aria-hidden="true">
        {/* 网格 */}
        {grid.vLines.map((l, i) => (
          <line key={`v${i}`} x1={l.x} y1={0} x2={l.x} y2={h} stroke="#E1E8DE" strokeWidth={1} />
        ))}
        {grid.hLines.map((l, i) => (
          <line key={`h${i}`} x1={0} y1={l.y} x2={w} y2={l.y} stroke="#E1E8DE" strokeWidth={1} />
        ))}
        {/* 公园 */}
        {decor.parks.map((p, i) => (
          <g key={`p${i}`}>
            <rect x={p.x} y={p.y} width={p.width} height={p.height} rx={10} fill="#CBE6C2" opacity={0.9} />
            {p.width > 40 && (
              <text x={p.x + p.width / 2} y={p.y + p.height / 2} textAnchor="middle" dominantBaseline="middle" fontSize={11} fill="#7FAE6F">
                {p.name}
              </text>
            )}
          </g>
        ))}
        {/* 河流 */}
        {decor.riverPaths.map((pts, i) => (
          <polyline key={`r${i}`} points={pts} fill="none" stroke="#A6D4EA" strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" opacity={0.85} />
        ))}
        {/* 道路 */}
        {decor.roadPaths.map((r, i) => (
          <polyline key={`d${i}`} points={r.pts} fill="none" stroke="#E3EAE0" strokeWidth={r.w * 2.4} strokeLinecap="round" strokeLinejoin="round" />
        ))}
      </svg>

      {/* 出发点 marker（不同颜色图钉 + 名称标签） */}
      {points.map((p, i) => {
        const pos = project(p.lng, p.lat, view, w, h)
        const color = colors[i % colors.length]
        return (
          <div key={p.id} className="start-marker" style={{ left: pos.x, top: pos.y, '--c': color } as CSSProperties}>
            <span className="start-label">{pointNickname(p, i)}</span>
            <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true">
              <path d="M12 21.5S5 15.6 5 10a7 7 0 1 1 14 0c0 5.6-7 11.5-7 11.5Z" fill={color} />
              <circle cx="12" cy="10" r="2.4" fill="#fff" />
            </svg>
          </div>
        )
      })}

      {/* POI 店铺图钉（最多展示 8 家，按地理偏移布局防重叠；智能推荐店铺加橙色徽标） */}
      {pinLayout.map(({ shop: s, dLng, dLat }) => {
        const isRec = recommendedId != null && s.id === recommendedId
        const pos = project(s.lng + dLng, s.lat + dLat, view, w, h)
        return (
          <button
            type="button"
            key={s.id}
            className={`poi-pin${isRec ? ' poi-rec' : ''}`}
            style={{ left: pos.x, top: pos.y }}
            data-shop-id={s.id}
            aria-label={s.name}
          >
            <span className="poi-emoji">{categoryEmoji(s.primary, s.sub)}</span>
            <span className="poi-name">{s.name}</span>
            {isRec && <span className="poi-badge">智能推荐</span>}
          </button>
        )
      })}

      {shops.length > 8 && <div className="map-more">地图展示前 8 家，其余 {shops.length - 8} 家在「列表」中</div>}

      {/* 缩放 / 复位控件 */}
      <div className="map-controls">
        <button type="button" aria-label="放大" data-action="zoom-in" onClick={() => zoomBy(1.4)}>
          <IconZoomIn size={18} />
        </button>
        <button type="button" aria-label="缩小" data-action="zoom-out" onClick={() => zoomBy(0.72)}>
          <IconZoomOut size={18} />
        </button>
        <button type="button" aria-label="回到全局视野" data-action="refit" onClick={refit}>
          <IconLocate size={17} />
        </button>
      </div>
    </div>
  )
}
