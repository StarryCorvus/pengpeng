import { CategoryIcon } from '../brand/categoryVisualMap'
/** Presentation placeholder only. Real shop photos continue to be displayed by callers. */
export function ShopImage({primary,sub,size='sm',className}: {
 primary:string;sub:string;size?:'sm'|'lg';className?:string
}) {
 return <div className={`shop-image shop-image-${size} ${className??''}`} aria-label={sub||primary}><CategoryIcon category={primary}/></div>
}
