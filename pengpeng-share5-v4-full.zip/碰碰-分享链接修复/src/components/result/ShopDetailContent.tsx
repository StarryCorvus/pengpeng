import { useEffect, useState, type ReactNode } from 'react'
import type { SharedProposal } from '../../utils/sharedProposal'
import { MODE_META, POINT_COLORS } from '../../mock/constants'
import { fmtFare, fmtMinutesShort, fmtPrice, fmtRating } from '../../utils/format'
import { IconClose, IconStar, ModeIcon } from '../common/Icons'
import { ShopPhoto } from '../brand/ShopPhoto'
import { ShopImage } from './ShopImage'

function renderAiMarkdown(text: string): ReactNode {
  return text.split('\n').map((line, i) => <div key={i}>{line.split(/(\*\*[^*]+\*\*)/g).map((seg, j) => {
    const bold = seg.match(/^\*\*([\s\S]+)\*\*$/)
    return bold ? <strong key={j}>{bold[1]}</strong> : <span key={j}>{seg}</span>
  })}</div>)
}

const AI_LOADING_TIPS = [
  '🔍 碰碰正在搜索这家店…',
  '📋 翻翻与它相关的点评…',
  '✨ 正在整理信息要点…',
  '⏳ 这家店信息有点多，再给我几秒…',
]
const AI_LOADING_SCHEDULE = [0, 1500, 4000, 7000]

function AiLoadingBubble() {
  const [step, setStep] = useState(0)
  useEffect(() => {
    const timers = AI_LOADING_SCHEDULE.slice(1).map((at, i) =>
      window.setTimeout(() => setStep(i + 1), at))
    return () => timers.forEach((t) => window.clearTimeout(t))
  }, [])
  return <section className="detail-section ai-section">
    <h3>✨ 碰碰小tip</h3>
    <div className="ai-loading-bubble">
      <span className="ai-loading-text">{AI_LOADING_TIPS[step]}</span>
      <span className="ai-loading-dots"><i/><i/><i/></span>
    </div>
  </section>
}

/** One display body for the regular modal, a received proposal, and the image export. */
export function ShopDetailContent({ proposal, images, loading = false, aiLoading = false, onClose, origins, colors = POINT_COLORS, snapshot = false }: {
  proposal: SharedProposal
  images?: string[]
  loading?: boolean
  aiLoading?: boolean
  onClose?: () => void
  origins?: string[]
  colors?: string[]
  snapshot?: boolean
}) {
  const { shop } = proposal
  return <>
    <div className="detail-hero">
      {images?.length ? <div className="detail-hero-images">
        <div className="detail-hero-scroll">{images.map((img, i) =>
          <ShopPhoto key={i} src={img} alt={`${shop.name} ${i + 1}`} primary={shop.primary} sub={shop.sub} size="lg" className="detail-hero-img" />)}</div>
        {images.length > 1 && <div className="detail-hero-imgcount">{images.length} 张图</div>}
      </div> : <ShopImage primary={shop.primary} sub={shop.sub} size="lg" className="detail-hero-bg" />}
      {loading && <div className="detail-loading"><div className="detail-loading-spinner"/><span>加载店铺详情…</span></div>}
      {onClose && <button type="button" className="detail-close" aria-label="关闭" onClick={onClose}><IconClose size={16}/></button>}
      <div className="detail-hero-info">
        <h2>{shop.name}</h2>
        <div className="detail-tags">
          <span className="dt"><IconStar size={12} className="star"/>{fmtRating(shop.rating)}</span>
          <span className="dt">人均{fmtPrice(shop.perCapita)}</span>
          <span className="dt">{shop.category}</span><span className="dt">{shop.area}</span>
        </div>
        {shop.tags.length > 0 && <div className="detail-shop-tags">{shop.tags.map((tag, i) => <span key={i} className="shop-tag">{tag}</span>)}</div>}
      </div>
    </div>
    <div className="detail-body">
      <section className="detail-section">
        <h3>各方通勤</h3>
        <div className="commute-list">{proposal.commutes.map((c, i) => <div key={`${i}-${c.name}`} className="commute-row">
          <i className="commute-row-dot" style={{ background: colors[i % colors.length] }}/>
          <span className="commute-row-name">{c.name}{c.count > 1 && <em className="commute-row-count">×{c.count}人</em>}
            {origins?.[i] && <em className="commute-row-place">{origins[i]}</em>}</span>
          <div className="commute-row-metrics">
            <span className="commute-row-mode" title={MODE_META[c.mode].label}><ModeIcon mode={c.mode} size={13}/></span>
            <span className="commute-row-duration">{fmtMinutesShort(c.minutes)}</span>
            <span className="commute-row-separator">·</span>
            <span className="commute-row-fare">{fmtFare(c.fare)}</span>
          </div>
        </div>)}</div>
        <div className="fairness-line">时间差 {proposal.timeDiffMinutes} 分钟 · 大家平均约{Math.round(proposal.avgMinutes)} 分钟
          {proposal.timeDiffMinutes <= 10 && <span className="fairness-badge">差不多同时到</span>}</div>
      </section>
      {aiLoading && <AiLoadingBubble/>}
      {!aiLoading && proposal.tip?.trim() && <section className="detail-section ai-section"><h3>✨ 碰碰小tip</h3><div className="ai-intro-text">{renderAiMarkdown(proposal.tip)}</div><div className="ai-disclaimer">以上内容为AI生成，仅供参考</div></section>}
      <section className="detail-section">
        <h3>商户信息</h3>
        {shop.intro && <p className="detail-intro">{shop.intro}</p>}
        <div className="detail-facts">
          {shop.hours && <span>🕐 营业时间：{shop.hours}</span>}
          {(shop.area || shop.city) && <span>📍 所在区域：{shop.area || shop.city}</span>}
          {shop.address && <span>📍 店铺地址：{shop.address}</span>}
          {shop.phone && <span>📞 电话：{shop.phone}</span>}
          {snapshot && <span className="proposal-estimate-note">通勤时间为提案生成时的估算</span>}
        </div>
      </section>
    </div>
  </>
}
