// The normal modal owns detail enrichment and actions; its visible body is shared with proposals.
import { useEffect, useState } from 'react'
import type { ShopWithCommute, TravelPoint } from '../../types'
import { dedupeCommutes } from '../../utils/format'
import { createSharedProposal, type SharedProposal } from '../../utils/sharedProposal'
import { IconHeart, IconNav, IconShare } from '../common/Icons'
import { Modal } from '../common/Modal'
import { USE_REAL_API } from '../../config'
import { getPoiDetail, getAiShopIntro } from '../../services/baiduMap'
import { ShopDetailContent } from './ShopDetailContent'

export function ShopDetailModal({ shop, points, colors, open, onClose, collected, onToggleCollect, onShare, onNavigate }: {
  shop: ShopWithCommute
  points: TravelPoint[]
  colors: string[]
  open: boolean
  onClose: () => void
  collected: boolean
  onToggleCollect: () => void
  onShare: (proposal: SharedProposal) => void
  onNavigate: () => void
}) {
  const [detail, setDetail] = useState<ShopWithCommute>(shop)
  const [loading, setLoading] = useState(false)
  const [aiIntro, setAiIntro] = useState<string | null>(null)
  const [aiLoading, setAiLoading] = useState(false)

  useEffect(() => {
    if (!open) return
    let cancelled = false
    setDetail(shop)
    setAiIntro(null)
    setLoading(USE_REAL_API && !!shop.uid)
    setAiLoading(USE_REAL_API)
    if (USE_REAL_API) {
      ;(async () => {
        let enriched = shop
        if (shop.uid) {
          let timeout: number | undefined
          try {
            // Detail is preferred, but the AI tip must still work when it stalls.
            const poiDetail = await Promise.race([
              getPoiDetail(shop.uid),
              new Promise<null>((resolve) => { timeout = window.setTimeout(() => resolve(null), 12000) }),
            ])
            if (poiDetail) {
              enriched = {
                ...shop,
                city: poiDetail.city || shop.city,
                area: poiDetail.area || shop.area,
                address: poiDetail.address || shop.address,
                rating: Number(poiDetail.rating) || shop.rating,
                perCapita: Number(poiDetail.price) || shop.perCapita,
                hours: poiDetail.hours || shop.hours,
                intro: poiDetail.intro || shop.intro,
                phone: poiDetail.phone || shop.phone,
                tags: poiDetail.tags?.length ? poiDetail.tags : shop.tags,
                images: poiDetail.images?.length ? poiDetail.images : shop.images,
              }
            }
          } catch { /* Continue with the candidate shop. */ }
          finally { if (timeout !== undefined) window.clearTimeout(timeout) }
        }
        if (cancelled) return
        setDetail(enriched)
        setLoading(false)
        try {
          const text = await getAiShopIntro({
            uid: enriched.uid, name: enriched.name, city: enriched.city,
            address: enriched.address, category: enriched.category,
            rating: enriched.rating, perCapita: enriched.perCapita, tags: enriched.tags,
            hours: enriched.hours, intro: enriched.intro, lng: enriched.lng, lat: enriched.lat,
            peopleCount: points.length, avgMinutes: Math.round(enriched.avg),
            maxMinutes: enriched.commutes.length ? Math.max(...enriched.commutes.map((c) => c.minutes)) : 0,
            fairnessMinutes: Math.round(enriched.fairness),
          })
          if (!cancelled && text?.trim()) setAiIntro(text)
        } catch { /* No tip on failed requests. */ }
        finally { if (!cancelled) setAiLoading(false) }
      })()
    }
    return () => { cancelled = true }
  }, [open, shop, points.length])

  const origins = dedupeCommutes(detail.commutes).map((c) => c.pointName)
  const proposal = createSharedProposal(detail, points, aiIntro)

  return <Modal open={open} onClose={onClose} className="detail-modal">
    <ShopDetailContent proposal={proposal} images={detail.images} loading={loading} aiLoading={aiLoading}
      onClose={onClose} origins={origins} colors={colors}/>
    <div className="detail-actions">
      <button type="button" className="btn-ghost" onClick={onNavigate}><IconNav size={15}/>一键导航</button>
      <button type="button" className={`btn-ghost ${collected ? 'collected' : ''}`} onClick={onToggleCollect} aria-pressed={collected}>
        <IconHeart size={15} filled={collected}/>{collected ? '已收藏' : '收藏'}
      </button>
      <button type="button" className="btn-primary btn-flex" onClick={() => onShare(proposal)}>
        <IconShare size={15}/>分享会面提案
      </button>
    </div>
  </Modal>
}
