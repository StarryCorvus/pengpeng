import { useEffect, useRef, useState } from 'react'
import html2canvas from 'html2canvas'
import type { SharedProposal } from '../../utils/sharedProposal'
import { sharedProposalUrl, proposalShareText } from '../../utils/sharedProposal'
import { Modal } from '../common/Modal'
import { useToast } from '../common/Toast'
import { ShopDetailContent } from './ShopDetailContent'

export function ShareCardModal({ open, onClose, proposal }: {
  open: boolean
  onClose: () => void
  proposal: SharedProposal
}) {
  const { show } = useToast()
  const exportRef = useRef<HTMLDivElement>(null)
  const previewUrl = useRef<string | null>(null)
  const [exporting, setExporting] = useState(false)
  const [preview, setPreview] = useState<string | null>(null)
  useEffect(() => () => { if (previewUrl.current) URL.revokeObjectURL(previewUrl.current) }, [])

  const copy = async (url: string) => {
    const message = `${proposalShareText(proposal.shop.name)}\n${url}`
    try {
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(message)
      else {
        const input = document.createElement('textarea')
        input.value = message
        input.style.position = 'fixed'
        input.style.opacity = '0'
        document.body.appendChild(input)
        input.select()
        try { if (!document.execCommand('copy')) throw new Error('copy failed') }
        finally { input.remove() }
      }
      show('会面提案已复制', 'success')
    } catch { show('复制失败，请检查浏览器剪贴板权限', 'warn') }
  }

  const share = async () => {
    const url = sharedProposalUrl(proposal)
    if (!navigator.share) { await copy(url); return }
    try {
      await navigator.share({ title: '碰碰 · 会面提案', text: proposalShareText(proposal.shop.name), url })
    } catch (error) {
      if ((error as DOMException)?.name !== 'AbortError') await copy(url)
    }
  }

  const save = async () => {
    if (exporting) return
    setExporting(true)
    try {
      // Let React mount the temporary natural-height export body, then await assets.
      await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()))
      const node = exportRef.current
      if (!node) throw new Error('export body missing')
      await document.fonts.ready
      await Promise.all([...node.querySelectorAll('img')].map(async (img) => {
        if (!img.complete) await new Promise<void>((resolve) => {
          img.addEventListener('load', () => resolve(), { once: true })
          img.addEventListener('error', () => resolve(), { once: true })
        })
        if (img.complete && img.naturalWidth) await img.decode().catch(() => {})
      }))
      const width = node.scrollWidth, height = node.scrollHeight
      const desired = Math.min(3, Math.max(2, window.devicePixelRatio || 2))
      const scale = Math.min(desired, 8192 / height, Math.sqrt(20000000 / (width * height)))
      if (!Number.isFinite(scale) || scale <= 0) throw new Error('invalid canvas dimensions')
      const canvas = await html2canvas(node, {
        scale, width, height, windowWidth: width, windowHeight: height,
        backgroundColor: '#fffcf5', useCORS: false, logging: false,
      })
      const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob(
        (result) => result ? resolve(result) : reject(new Error('PNG export failed')), 'image/png'))
      if (previewUrl.current) URL.revokeObjectURL(previewUrl.current)
      const url = URL.createObjectURL(blob)
      previewUrl.current = url
      setPreview(url)
      const anchor = document.createElement('a')
      anchor.href = url
      anchor.download = `碰碰-会面提案-${proposal.shop.name.replace(/[\\/:*?"<>|]/g, '').slice(0, 40)}.png`
      anchor.click()
    } catch (error) {
      console.error('提案图片导出失败', error)
      show('图片生成失败，请重试', 'warn')
    } finally { setExporting(false) }
  }

  return <>
    <Modal open={open && !preview} onClose={onClose} className="proposal-share-modal">
      <h2>发给碰友看看</h2>
      <p>把这家店和大家的通勤情况发给朋友。</p>
      <div className="proposal-share-actions">
        <button type="button" className="btn-primary" onClick={() => void share()}>分享链接</button>
        <button type="button" className="btn-ghost" disabled={exporting} onClick={() => void save()}>
          {exporting ? '生成中…' : '保存图片'}
        </button>
      </div>
    </Modal>
    {exporting && <div className="proposal-export-host" aria-hidden="true">
      <div className="proposal-export detail-modal" ref={exportRef}>
        <ShopDetailContent proposal={proposal} snapshot/>
        <footer className="proposal-brand-footer">碰碰 · 想见，那就轻松碰一面</footer>
      </div>
    </div>}
    {preview && <div className="img-preview-overlay" onClick={() => setPreview(null)}>
      <div className="img-preview-content" onClick={(event) => event.stopPropagation()}>
        <img src={preview} alt="完整会面提案长图" className="img-preview-img"/>
        <p className="img-preview-hint">已生成 PNG · 长按图片可保存到相册</p>
        <button type="button" className="btn-ghost" onClick={() => setPreview(null)}>关闭预览</button>
      </div>
    </div>}
  </>
}
