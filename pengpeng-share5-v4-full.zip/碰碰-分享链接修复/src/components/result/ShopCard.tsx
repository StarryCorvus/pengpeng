import { ShopPhoto } from '../brand/ShopPhoto'
// ============================================================
// 店铺卡片组件（公共组件）：列表视图 / 结果页复用
// 展示：名称、评分、人均、业态品类、到每个出发点的通勤时长
// ============================================================

import type { CSSProperties } from 'react'
import type { ShopWithCommute, TravelPoint } from '../../types'
import { dedupeCommutes, fmtMinutesShort, fmtPrice, fmtRating, pointNickname } from '../../utils/format'
import { IconStar } from '../common/Icons'
import { ModeIcon } from '../common/Icons'
import { ShopImage } from './ShopImage'

export function ShopCard({
  shop,
  points,
  colors,
  onClick,
}: {
  shop: ShopWithCommute
  points: TravelPoint[]
  colors: string[]
  onClick: () => void
}) {
  return (
    <div className="shop-card" onClick={onClick} role="button" tabIndex={0} aria-label={shop.name}>
      {shop.images && shop.images.length > 0 ? (
        <ShopPhoto src={shop.images[0]} alt={shop.name} primary={shop.primary} sub={shop.sub} className="shop-card-thumb" />
      ) : (
        <ShopImage primary={shop.primary} sub={shop.sub} size="sm" />
      )}
      <div className="shop-card-main">
        <div className="shop-card-title">
          <span className="shop-name">{shop.name}</span>
          <div className="shop-metrics"><span className="shop-fairness" title="大家到店的时间差">
            时间差 {shop.fairness}分钟
          </span>
          <span className="shop-avg" title="大家平均通勤时长">
            约{Math.round(shop.avg)}分钟
          </span></div>
        </div>
        <div className="shop-card-meta">
          <span className="rating">
            <IconStar size={12} className="star" />
            {fmtRating(shop.rating)}
          </span>
          <span>人均{fmtPrice(shop.perCapita)}</span>
          <span>{shop.category}</span>
          <span className="shop-area">{shop.area}</span>
        </div>
        {/* 到每个出发点的通勤时长（重复出发点+出行方式去重） */}
        <div className="shop-commutes">
          {dedupeCommutes(shop.commutes).map((c) => {
            const idx = points.findIndex((p) => p.id === c.pointId)
            const color = colors[Math.max(0, idx) % colors.length]
            const pt = points[idx]
            return (
              <span key={`${c.pointName}_${c.mode}`} className="commute-chip" style={{ '--dot': color } as CSSProperties}>
                <i className="commute-dot" />
                <span className="commute-name">
                  {pointNickname(pt, idx)}
                  {c.count > 1 && <em className="commute-count">×{c.count}</em>}
                </span>
                <ModeIcon mode={c.mode} size={12} className="commute-mode" />
                <b>{fmtMinutesShort(c.minutes)}</b>
              </span>
            )
          })}
        </div>
      </div>
    </div>
  )
}
