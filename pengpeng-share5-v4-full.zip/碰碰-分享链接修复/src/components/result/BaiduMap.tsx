import type { MapVisualMode } from '../../config/brandVisual'
import { applyMapVisualStyle } from '../brand/mapVisualStyle'
// ============================================================
// 百度地图组件（真实 API 版本）：
// - 使用自定义 HTML 覆盖物，图标和文字是一个整体，永远不会错位
// - 出发点：水滴形状 + 编号 + 名称标签
// - 店铺：圆形 emoji 图标 + 名称标签，推荐店铺橙色高亮
// - 防重合：位置接近的店铺自动偏移
// - 最多显示 5 家店铺，隐藏提示 2.5 秒自动消失
// - 归正视野按钮
// ============================================================

import { useEffect, useRef, useState } from 'react'
import type { ShopWithCommute, TravelPoint } from '../../types'
import { loadBaiduMap } from '../../services/baiduMap'
import { categoryEmoji } from '../../mock/constants'
import { pointNickname } from '../../utils/format'

/** 最多显示的店铺 marker 数量：地图默认展示最终排序前 10 家 */
const MAX_SHOP_MARKERS = 10

/** 处理店铺名称：去括号 + 限制字数 */
function formatShopName(name: string, maxLen = 7): string {
  const cleaned = name.replace(/[（(].*?[）)]/g, '').trim()
  if (cleaned.length <= maxLen) return cleaned
  return cleaned.slice(0, maxLen) + '…'
}

/**
 * 防重合：对位置接近的店铺做偏移
 * 改进版：增大偏移步长和尝试次数，螺旋式向外偏移，确保不重合
 */
function spreadPositions(
  shops: ShopWithCommute[],
): { shop: ShopWithCommute; offsetLng: number; offsetLat: number }[] {
  const result: { shop: ShopWithCommute; offsetLng: number; offsetLat: number }[] = []
  // 阈值：经纬度差小于 0.0025 视为接近（约250米）
  const threshold = 0.0025
  const offsetStep = 0.002 // 每次偏移约200米

  for (let i = 0; i < shops.length; i++) {
    const shop = shops[i]
    let offsetLng = 0
    let offsetLat = 0
    for (let attempt = 0; attempt < 30; attempt++) {
      let tooClose = false
      for (let j = 0; j < result.length; j++) {
        const prev = result[j]
        const dlng = shop.lng + offsetLng - (prev.shop.lng + prev.offsetLng)
        const dlat = shop.lat + offsetLat - (prev.shop.lat + prev.offsetLat)
        if (Math.abs(dlng) < threshold && Math.abs(dlat) < threshold) {
          tooClose = true
          break
        }
      }
      if (!tooClose) break
      // 螺旋式向外偏移，每6次转一圈，半径递增
      const angle = attempt * (Math.PI / 3)
      const radius = offsetStep * (1 + Math.floor(attempt / 6))
      offsetLng = Math.cos(angle) * radius
      offsetLat = Math.sin(angle) * radius
    }
    result.push({ shop, offsetLng, offsetLat })
  }
  return result
}

/**
 * 自定义覆盖物基类
 * 图标和文字放在同一个 DOM 元素里，永远不会错位
 */
function createCustomOverlay(
  BMap: any,
  point: any,
  html: string,
  anchorX: number,
  anchorY: number,
  onClick?: () => void,
  zIndex = 100,
) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  function CustomOverlay(this: any) {
    this._point = point
    this._html = html
    this._anchorX = anchorX
    this._anchorY = anchorY
    this._onClick = onClick
    this._zIndex = zIndex
  }
  CustomOverlay.prototype = new BMap.Overlay()
  CustomOverlay.prototype.initialize = function (this: any, map: any) {
    this._map = map
    const div = document.createElement('div')
    div.style.position = 'absolute'
    div.style.cursor = onClick ? 'pointer' : 'default'
    div.style.zIndex = String(this._zIndex)
    div.style.pointerEvents = onClick ? 'auto' : 'none'
    div.innerHTML = html
    if (onClick) {
      // 用 touchend 触发点击（移动端更灵敏），同时保留 click 兜底
      let touchMoved = false
      div.addEventListener('touchstart', () => {
        touchMoved = false
      }, { passive: true })
      div.addEventListener('touchmove', () => {
        touchMoved = true
      }, { passive: true })
      div.addEventListener('touchend', (e: Event) => {
        if (!touchMoved) {
          e.stopPropagation()
          e.preventDefault()
          onClick()
        }
      })
      div.addEventListener('click', (e: Event) => {
        e.stopPropagation()
        onClick()
      })
    }
    map.getPanes().markerPane.appendChild(div)
    this._div = div
    return div
  }
  CustomOverlay.prototype.draw = function (this: any) {
    const pixel = this._map.pointToOverlayPixel(this._point)
    this._div.style.left = pixel.x - this._anchorX + 'px'
    this._div.style.top = pixel.y - this._anchorY + 'px'
  }
  CustomOverlay.prototype.destroy = function (this: any) {
    if (this._div && this._div.parentNode) {
      this._div.parentNode.removeChild(this._div)
    }
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return new (CustomOverlay as any)()
}

export function BaiduMap({
  points,
  colors,
  shops,
  recommendedId,
  onShopSelect,
  resetKey,
  visualStyle = 'default',
  onStyleApplied,
}: {
  points: TravelPoint[]
  colors: string[]
  shops: ShopWithCommute[]
  recommendedId?: string
  onShopSelect: (shop: ShopWithCommute) => void
  resetKey: number
  visualStyle?: MapVisualMode
  onStyleApplied?: (mode: MapVisualMode) => void
}) {
  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<any>(null)
  const overlaysRef = useRef<any[]>([])
  const onShopSelectRef = useRef(onShopSelect)
  const [mapReady, setMapReady] = useState(false)
  const [showHiddenHint, setShowHiddenHint] = useState(false)
  const hiddenCountRef = useRef(0)
  onShopSelectRef.current = onShopSelect

  // 初始化地图
  useEffect(() => {
    let cancelled = false
    ;(async () => {
      await loadBaiduMap()
      if (cancelled || !containerRef.current) return
      const map = new window.BMap.Map(containerRef.current)
      map.centerAndZoom(new window.BMap.Point(116.404, 39.915), 12)
      map.enableScrollWheelZoom(true)
      map.enableDragging()
      map.enablePinchToZoom()
      mapRef.current = map
      setMapReady(true)
    })()
    return () => {
      cancelled = true
      if (mapRef.current) {
        mapRef.current = null
      }
    }
  }, [])

  // Presentation only; changing palette does not recreate map, markers or requests.
  useEffect(() => {
    if (!mapReady || !mapRef.current) return
    const applied = applyMapVisualStyle(mapRef.current, visualStyle)
    if (applied !== visualStyle) onStyleApplied?.(applied)
  }, [mapReady, visualStyle, onStyleApplied])

  // 渲染覆盖物（points + shops）
  useEffect(() => {
    const map = mapRef.current
    const BMap = window.BMap
    if (!map || !BMap) return

    // 清除旧覆盖物
    overlaysRef.current.forEach((o) => {
      try {
        o.destroy()
        map.removeOverlay(o)
      } catch {
        /* ignore */
      }
    })
    overlaysRef.current = []

    const allPoints: any[] = []

    // 出发点覆盖物（小圆点 + 名称标签，去掉大水滴图标）
    points.forEach((p, i) => {
      const color = colors[i % colors.length]
      const point = new BMap.Point(p.lng, p.lat)
      allPoints.push(point)

      // 小圆点（10x10，带白色边框）
      const dotSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14">
        <circle cx="7" cy="7" r="6" fill="${color}" stroke="#fff" stroke-width="2"/>
      </svg>`

      // 名称标签（在圆点上方）
      const html = `
        <div style="display:flex;flex-direction:column;align-items:center;pointer-events:none;">
          <div style="background:${color};color:#fff;padding:2px 10px;border-radius:999px;font-size:11px;font-weight:700;white-space:nowrap;box-shadow:0 1px 4px rgba(0,0,0,0.2);margin-bottom:2px;border:1.5px solid #fff;">
            ${pointNickname(p, i)}
          </div>
          ${dotSvg}
        </div>
      `

      // 锚点：小圆点中心（14/2=7, 总高度约 标签20+圆点14=34，锚点在圆点中心即 20+7=27）
      // 出发点 zIndex 200（优先级：推荐店铺300 > 出发点200 > 其他店铺100）
      const overlay = createCustomOverlay(BMap, point, html, 7, 27, undefined, 200)
      map.addOverlay(overlay)
      overlaysRef.current.push(overlay)
    })

    // 店铺覆盖物（最多显示前 MAX_SHOP_MARKERS 家，防重合偏移）
    const displayShops = shops.slice(0, MAX_SHOP_MARKERS)
    const hiddenCount = shops.length - MAX_SHOP_MARKERS
    hiddenCountRef.current = hiddenCount

    // 防重合偏移
    const spread = spreadPositions(displayShops)

    spread.forEach(({ shop, offsetLng, offsetLat }) => {
      const point = new BMap.Point(shop.lng + offsetLng, shop.lat + offsetLat)
      allPoints.push(point)

      const isRec = shop.id === recommendedId
      const emoji = categoryEmoji(shop.primary, shop.sub)
      const displayName = formatShopName(shop.name, 6)
      const borderColor = isRec ? '#5E7158' : '#765033'
      const ringColor = isRec ? 'rgba(255,122,47,0.35)' : 'transparent'
      // 气泡背景：推荐店铺用橙色不透明，其他店铺用白色半透明（透明度更浅）
      const labelBg = isRec ? '#5E7158' : '#FFF9EE'
      const labelColor = isRec ? '#fff' : '#4A2C16'
      const labelBorder = isRec ? '#5E7158' : '#D9C8AC'

      // 圆形 emoji 图标 SVG（缩小到 32x32）
      const iconSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
        <circle cx="16" cy="16" r="14" fill="${ringColor}" />
        <circle cx="16" cy="16" r="11" fill="#fff" stroke="${borderColor}" stroke-width="2" />
        <text x="16" y="20" text-anchor="middle" font-size="13">${emoji}</text>
      </svg>`

      // 名称标签（缩小文字到10px，padding缩小，背景更透明）
      const html = `
        <div style="display:flex;flex-direction:column;align-items:center;pointer-events:auto;">
          ${iconSvg}
          <div style="margin-top:2px;background:${labelBg};color:${labelColor};padding:2px 7px;border-radius:6px;font-size:10px;font-weight:${isRec ? '700' : '500'};white-space:nowrap;box-shadow:${isRec ? '0 2px 8px rgba(94,113,88,0.2)' : '0 1px 3px rgba(0,0,0,0.08)'};border:1px solid ${labelBorder};">
            ${displayName}
          </div>
        </div>
      `

      // 锚点：图标中心（32/2=16, 32/2=16）
      // zIndex：推荐店铺300 > 出发点200 > 其他店铺100
      const overlay = createCustomOverlay(
        BMap,
        point,
        html,
        16,
        16,
        () => onShopSelectRef.current(shop),
        isRec ? 300 : 100,
      )
      map.addOverlay(overlay)
      overlaysRef.current.push(overlay)
    })

    // 适配视野
    if (allPoints.length > 0) {
      map.setViewport(allPoints)
    }

    // 显示隐藏提示（2.5 秒后自动消失）
    if (hiddenCount > 0) {
      setShowHiddenHint(true)
      const timer = setTimeout(() => setShowHiddenHint(false), 2500)
      return () => clearTimeout(timer)
    } else {
      setShowHiddenHint(false)
    }
  }, [points, shops, recommendedId, colors, mapReady])

  // resetKey 变化时重新适配视野
  useEffect(() => {
    const map = mapRef.current
    if (!map || resetKey === 0) return
    resetViewport()
  }, [resetKey, mapReady])

  /** 归正视野 */
  const resetViewport = () => {
    const map = mapRef.current
    if (!map) return
    const allPoints: any[] = []
    points.forEach((p) => allPoints.push(new window.BMap.Point(p.lng, p.lat)))
    shops.slice(0, MAX_SHOP_MARKERS).forEach((s) => allPoints.push(new window.BMap.Point(s.lng, s.lat)))
    if (allPoints.length > 0) {
      map.setViewport(allPoints)
    }
  }

  return (
    <div style={{ width: '100%', height: '100%', position: 'relative' }}>
      <div
        ref={containerRef}
        style={{ width: '100%', height: '100%' }}
      />
      {/* 归正视野按钮 */}
      {mapReady && (
        <button
          type="button"
          onClick={resetViewport}
          style={{
            position: 'absolute',
            right: 12,
            bottom: 12,
            zIndex: 100,
            width: 40,
            height: 40,
            borderRadius: '50%',
            background: 'rgba(255,255,255,0.95)',
            border: '1px solid #e5e6eb',
            boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
            display: 'grid',
            placeItems: 'center',
            cursor: 'pointer',
            fontSize: 18,
          }}
          aria-label="归正视野"
          title="归正视野"
        >
          ⌂
        </button>
      )}
      {/* 隐藏店铺提示（地图最下方，2.5秒自动消失） */}
      {showHiddenHint && hiddenCountRef.current > 0 && (
        <div
          style={{
            position: 'absolute',
            left: '50%',
            bottom: 60,
            transform: 'translateX(-50%)',
            zIndex: 99,
            background: 'rgba(35,39,46,0.85)',
            color: '#fff',
            padding: '6px 14px',
            borderRadius: '999px',
            fontSize: '12px',
            fontWeight: '500',
            boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
            pointerEvents: 'none',
            whiteSpace: 'nowrap',
          }}
        >
          还有 {hiddenCountRef.current} 家店铺，切换列表查看全部
        </div>
      )}
    </div>
  )
}
