// ============================================================
// 结果页顶栏「局部快捷修改」弹窗：
// 点击摘要栏的某个参数 chip 时，只弹出该模块的选项（而不是完整需求界面）：
// - points   -> 只针对「被点击的那个出发点」：同一弹窗内可改地点（点地点行
//               直接换，下拉内联展开不裁切）+ 改该出发点的出行方式
// - category -> 业态品类选择器（一级 Tab + 二级单选）
// 选择即生效（form 变化自动触发结果页重算），底部可进入「完整编辑」。
// ============================================================

import { useEffect, useState } from 'react'
import type { FormState, TravelPoint } from '../../types'
import { MODE_META, MODE_ORDER, POINT_COLORS } from '../../mock/constants'
import { type Place } from '../../mock/places'
import { pointNickname } from '../../utils/format'
import { BottomSheet } from '../common/BottomSheet'
import { CategorySelect } from '../form/CategorySelect'
import { AddressSearch, type AddressPickSource } from '../form/AddressSearch'
import { IconEdit, ModeIcon } from '../common/Icons'

export type QuickScope = 'points' | 'category'

export function QuickSheet({
  scope,
  pointIndex,
  form,
  onChange,
  onClose,
  onOpenFull,
}: {
  /** 当前弹出的模块；null 表示不展示 */
  scope: QuickScope | null
  /** points 模块的目标出发点下标（弹窗只编辑这一个出发点） */
  pointIndex: number
  form: FormState
  onChange: (f: FormState) => void
  onClose: () => void
  /** 打开「完整修改需求」弹窗 */
  onOpenFull: () => void
}) {
  /** 当前正在换地点的出发点下标；null = 未在换地点 */
  const [pickingIndex, setPickingIndex] = useState<number | null>(null)
  /** 品类选择的草稿（点完成后才生效，避免点完一级就重新检索） */
  const [draftCategory, setDraftCategory] = useState<FormState['category']>(null)
  /** 是否展示所有出发点（空状态「调整出发点&出行方式」入口） */
  const allPoints = scope === 'points' && pointIndex === -1

  // 弹窗打开 / 切换出发点时，重置「换地点」展开状态（默认不展开搜索下拉）
  useEffect(() => {
    setPickingIndex(null)
  }, [scope, pointIndex])

  // 打开品类弹窗时，用当前 form.category 初始化草稿
  useEffect(() => {
    if (scope === 'category') {
      setDraftCategory(form.category)
    }
  }, [scope, form.category])

  /** 更新某个出发点（换地点 / 换出行方式） */
  const patchPoint = (i: number, patch: Partial<TravelPoint>) => {
    onChange({
      ...form,
      points: form.points.map((p, j) => (j === i ? { ...p, ...patch } : p)),
    })
  }

  const title =
    scope === 'points'
      ? allPoints
        ? '调整碰友 & 出行方式'
        : `调整${pointNickname(form.points[pointIndex], pointIndex)}`
      : '想干什么'

  const point = scope === 'points' && !allPoints ? form.points[pointIndex] : undefined

  return (
    <BottomSheet
      open={scope != null}
      onClose={onClose}
      title={title}
      footer={
        <div className="quick-sheet-footer">
          <button type="button" className="ghost" onClick={onOpenFull}>
            完整编辑所有参数
          </button>
          <button
            type="button"
            className="btn-primary"
            onClick={() => {
              // 品类模式下，点完成才生效（避免点完一级就重新检索）
              if (scope === 'category' && draftCategory) {
                onChange({ ...form, category: draftCategory })
              }
              onClose()
            }}
          >
            完成
          </button>
        </div>
      }
    >
      {scope === 'category' && (
        <div className="quick-block">
          <p className="quick-tip">选一个品类（一级 Tab + 二级单选），点完成后重新计算</p>
          <CategorySelect
            value={draftCategory}
            onChange={(category) => setDraftCategory(category)}
          />
        </div>
      )}

      {scope === 'points' && (
        <div className="quick-block">
          <p className="quick-tip">地点与出行方式都在这里修改，改完自动重新计算</p>

          {/* 所有出发点模式：固定高度滚动容器，每个出发点一张卡片 */}
          {allPoints ? (
            <div className="quick-points-scroll">
              {form.points.map((p, i) => (
                <div key={p.id} className="quick-point-card">
                  <div className="quick-point-head">
                    <span className="quick-point-dot" style={{ background: POINT_COLORS[i % POINT_COLORS.length] }} />
                    <span className="quick-point-title">{pointNickname(p, i)}</span>
                  </div>

                  {pickingIndex === i ? (
                    <>
                      <p className="quick-tip">选择新的地点（搜索 / 模拟定位）</p>
                      <AddressSearch
                        compact
                        autoFocus
                        inline
                        onSelect={(place: Place, source: AddressPickSource) => {
                          patchPoint(i, {
                            name: place.name,
                            address: place.address,
                            lng: place.lng,
                            lat: place.lat,
                            source,
                            isCurrentLocation: source === 'locate',
                          })
                          setPickingIndex(null)
                        }}
                      />
                      <button type="button" className="ghost quick-pick-cancel" onClick={() => setPickingIndex(null)}>
                        取消更换
                      </button>
                    </>
                  ) : (
                    <button type="button" className="quick-loc-row" onClick={() => setPickingIndex(i)}>
                      <span className="quick-loc-text">
                        <b>{p.name}</b>
                        <em>{p.address}</em>
                      </span>
                      <span className="quick-loc-edit">
                        <IconEdit size={12} />
                        更换
                      </span>
                    </button>
                  )}

                  <p className="quick-tip">该出发点的出行方式（各方可各自不同）</p>
                  <div className="quick-mode-grid">
                    {MODE_ORDER.map((m) => (
                      <button
                        type="button"
                        key={m}
                        className={`quick-mode ${p.mode === m ? 'active' : ''}`}
                        onClick={() => patchPoint(i, { mode: m })}
                      >
                        <ModeIcon mode={m} size={16} />
                        <span>{MODE_META[m].label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            /* 单出发点模式 */
            point && (
              <div className="quick-point-card single">
                <div className="quick-point-head">
                  <span className="quick-point-dot" style={{ background: POINT_COLORS[pointIndex % POINT_COLORS.length] }} />
                  <span className="quick-point-title">{pointNickname(point, pointIndex)}</span>
                </div>

                {pickingIndex === pointIndex ? (
                  <>
                    <p className="quick-tip">选择新的地点（搜索 / 模拟定位）</p>
                    <AddressSearch
                      compact
                      autoFocus
                      inline
                      onSelect={(place: Place, source: AddressPickSource) => {
                        patchPoint(pointIndex, {
                          name: place.name,
                          address: place.address,
                          lng: place.lng,
                          lat: place.lat,
                          source,
                          isCurrentLocation: source === 'locate',
                        })
                        setPickingIndex(null)
                      }}
                    />
                    <button type="button" className="ghost quick-pick-cancel" onClick={() => setPickingIndex(null)}>
                      取消更换
                    </button>
                  </>
                ) : (
                  <button type="button" className="quick-loc-row" onClick={() => setPickingIndex(pointIndex)}>
                    <span className="quick-loc-text">
                      <b>{point.name}</b>
                      <em>{point.address}</em>
                    </span>
                    <span className="quick-loc-edit">
                      <IconEdit size={12} />
                      更换
                    </span>
                  </button>
                )}

                <p className="quick-tip">该出发点的出行方式（各方可各自不同）</p>
                <div className="quick-mode-grid">
                  {MODE_ORDER.map((m) => (
                    <button
                      type="button"
                      key={m}
                      className={`quick-mode ${point.mode === m ? 'active' : ''}`}
                      onClick={() => patchPoint(pointIndex, { mode: m })}
                    >
                      <ModeIcon mode={m} size={16} />
                      <span>{MODE_META[m].label}</span>
                    </button>
                  ))}
                </div>
              </div>
            )
          )}
        </div>
      )}
    </BottomSheet>
  )
}
