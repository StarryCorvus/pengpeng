// ============================================================
// 通勤时间差选择器（公共组件）：
// 表单页 / 结果页参数弹窗 / 列表二次筛选 三处复用。
// 档位 = 预设 10/20/30 分钟 + 自定义（输入 1~180 分钟）。
// ============================================================

import { useEffect, useRef, useState } from 'react'
import { TIME_DIFF_MAX, TIME_DIFF_MIN, TIME_DIFF_PRESETS } from '../../mock/constants'

export function TimeDiffPicker({
  value,
  onChange,
  size = 'lg',
}: {
  value: number
  onChange: (v: number) => void
  /** lg：大按钮组（表单/弹窗）；sm：紧凑小按钮（列表筛选条） */
  size?: 'lg' | 'sm'
}) {
  // 自定义输入态：打开后展示数字输入框 + 确定/取消
  const [customOpen, setCustomOpen] = useState(false)
  const [draft, setDraft] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)
  const rowRef = useRef<HTMLDivElement>(null)

  // 展开输入行时：聚焦输入框，并把输入行滚动到可视区中央
  // （表单页底部有固定提交栏，避免输入行被遮挡）
  useEffect(() => {
    if (!customOpen) return
    requestAnimationFrame(() => {
      inputRef.current?.focus()
      rowRef.current?.scrollIntoView({ block: 'center', behavior: 'smooth' })
    })
  }, [customOpen])

  const isCustom = !TIME_DIFF_PRESETS.includes(value)

  const openCustom = () => {
    setDraft(String(value))
    setCustomOpen(true)
  }

  const confirmCustom = () => {
    const n = Math.round(Number(draft))
    if (!Number.isFinite(n) || n < TIME_DIFF_MIN || n > TIME_DIFF_MAX) {
      setDraft(String(value)) // 非法输入回退当前值
      setCustomOpen(false)
      return
    }
    onChange(n)
    setCustomOpen(false)
  }

  return (
    <div className={`time-diff-picker ${size === 'sm' ? 'sm' : ''}`}>
      <div className={size === 'sm' ? 'diff-filter-opts' : 'budget-seg'}>
        {TIME_DIFF_PRESETS.map((v) => (
          <button
            type="button"
            key={v}
            className={`${size === 'sm' ? 'diff-opt' : 'budget-opt'} ${value === v && !customOpen ? 'active' : ''}`}
            onClick={() => {
              setCustomOpen(false)
              if (value !== v) onChange(v)
            }}
          >
            {v}分钟内
          </button>
        ))}
        <button
          type="button"
          className={`${size === 'sm' ? 'diff-opt td-custom-btn' : 'budget-opt td-custom-btn'} ${isCustom || customOpen ? 'active' : ''}`}
          onClick={openCustom}
        >
          自定义{isCustom && !customOpen ? ` ${value}分` : ''}
        </button>
      </div>

      {/* 自定义输入行 */}
      {customOpen && (
        <div ref={rowRef} className={`td-custom-row ${size === 'sm' ? 'sm' : ''}`}>
          <input
            ref={inputRef}
            className="td-input"
            type="number"
            min={TIME_DIFF_MIN}
            max={TIME_DIFF_MAX}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') confirmCustom()
              if (e.key === 'Escape') setCustomOpen(false)
            }}
            placeholder={`${TIME_DIFF_MIN}~${TIME_DIFF_MAX}`}
            aria-label="自定义时间差分钟数"
          />
          <span className="td-unit">分钟</span>
          <button type="button" className="td-ok" onClick={confirmCustom}>
            确定
          </button>
          <button type="button" className="td-cancel" onClick={() => setCustomOpen(false)}>
            取消
          </button>
        </div>
      )}
    </div>
  )
}
