// ============================================================
// 品类选择组件（公共组件，表单页与结果页参数修改共用）：
// 一级 Tab 切换 + 二级标签横向滚动单选
// ============================================================

import { CATEGORY_TREE } from '../../mock/constants'
import type { CategoryValue } from '../../types'

export function CategorySelect({
  value,
  onChange,
}: {
  value: CategoryValue | null
  onChange: (v: CategoryValue) => void
}) {
  const current = CATEGORY_TREE.find((c) => c.key === value?.primary)

  return (
    <div className="category-select">
      {/* 一级品类 Tab */}
      <div className="cat-tabs" role="tablist">
        {CATEGORY_TREE.map((c) => (
          <button
            type="button"
            key={c.key}
            role="tab"
            aria-selected={c.key === value?.primary}
            className={`cat-tab ${c.key === value?.primary ? 'active' : ''}`}
            onClick={() => onChange({ primary: c.key, secondary: c.children[0] ?? '' })}
          >
            {c.name}
          </button>
        ))}
      </div>

      {/* 二级细分标签（单选） */}
      {current && current.children.length > 0 && (
        <div className="cat-tags">
          {current.children.map((s) => (
            <button
              type="button"
              key={s}
              className={`cat-tag ${s === value?.secondary ? 'active' : ''}`}
              onClick={() => onChange({ primary: current.key, secondary: s })}
            >
              {s}
            </button>
          ))}
        </div>
      )}
      {current && current.children.length === 0 && (
        <div className="cat-tags">
          <span className="cat-tag cat-tag-static">全部（无需细分）</span>
        </div>
      )}
    </div>
  )
}
