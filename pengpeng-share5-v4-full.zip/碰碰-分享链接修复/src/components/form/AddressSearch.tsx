// ============================================================
// 地址搜索组件（公共组件）：
// 统一在一个下拉框内提供三种录入方式：
//   1. 使用当前位置（模拟定位）
//   2. 常用地址（一键选择）
//   3. 关键词搜索（本地 mock 地址库）
// 避免多个浮动层 / 气泡重叠，所有候选都在同一个下拉列表里。
// ============================================================

import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { CURRENT_LOCATION, FAVORITE_PLACES, searchPlaces, type Place } from '../../mock/places'
import { searchPlace, getCurrentLocation, isBareAdminRegion } from '../../services/baiduMap'
import { USE_REAL_API } from '../../config'
import { incrementCount, loadRecentPlaces, saveRecentPlace, removeRecentPlace, type RecentPlace } from '../../utils/storage'
import { IconLocate, IconPin, IconSearch } from '../common/Icons'

export type AddressPickSource = 'search' | 'locate' | 'favorite'

export function AddressSearch({
  onSelect,
  onOpenChange,
  placeholder,
  autoFocus,
  compact,
  showFavorites = true,
  inline,
  dropUp,
  hideCurrentLocation = true,
}: {
  onSelect: (place: Place, source: AddressPickSource) => void
  onOpenChange?: (open: boolean) => void
  placeholder?: string
  autoFocus?: boolean
  compact?: boolean
  /** 是否展示「常用地址」分组（默认展示） */
  showFavorites?: boolean
  /** 内联模式：候选列表参与文档流（不浮层、不裁切），适合在底部弹窗等空间有限的容器里使用 */
  inline?: boolean
  /** 向上展开模式：候选列表在输入框上方弹出，避免被移动端键盘遮挡 */
  dropUp?: boolean
  /** 隐藏「使用当前位置」按钮（默认隐藏，所有出发点搜索框都不显示当前位置） */
  hideCurrentLocation?: boolean
}) {
  const [kw, setKw] = useState('')
  const [open, setOpen] = useState(false)
  const [expanded, setExpanded] = useState(false)
  const [panelMaxH, setPanelMaxH] = useState(280)
  const [loading, setLoading] = useState(false)
  const [locating, setLocating] = useState(false)
  const [list, setList] = useState<Place[]>([])
  const [recent, setRecent] = useState<RecentPlace[]>([])
  const [dropUpMaxH, setDropUpMaxH] = useState(280)
  const timer = useRef<number>(0)
  const containerRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // 挂载时读取最近选择的地点（作为「常用位置」展示）
  useEffect(() => {
    setRecent(loadRecentPlaces())
  }, [])

  // 开关与卡片升层只属于展示状态；不进入 FormState。
  const requestOpen = () => {
    window.dispatchEvent(new CustomEvent('peng-address-search-open', { detail: containerRef.current }))
    setOpen(true)
    setRecent(loadRecentPlaces())
  }
  useEffect(() => {
    const otherOpened = (event: Event) => {
      if ((event as CustomEvent).detail !== containerRef.current) setOpen(false)
    }
    const outside = (event: PointerEvent) => {
      if (!containerRef.current?.contains(event.target as Node)) setOpen(false)
    }
    window.addEventListener('peng-address-search-open', otherOpened)
    document.addEventListener('pointerdown', outside)
    return () => {
      window.removeEventListener('peng-address-search-open', otherOpened)
      document.removeEventListener('pointerdown', outside)
    }
  }, [])
  useEffect(() => {
    onOpenChange?.(open)
    return () => onOpenChange?.(false)
  }, [open, onOpenChange])
  useEffect(() => { setExpanded(false) }, [kw, open])

  // 将浮层限制在可视区域与底栏之间；滚动只发生在浮层内部。
  useLayoutEffect(() => {
    if (!open) return
    const measure = () => {
      const field = containerRef.current
      if (!field) return
      const rect = field.getBoundingClientRect()
      const viewport = window.visualViewport
      const height = viewport?.height ?? window.innerHeight
      let top = viewport?.offsetTop ?? 0
      let bottom = top + height
      const nav = document.querySelector('.bottom-nav')?.getBoundingClientRect()
      if (nav && nav.height > 0 && nav.top > top) bottom = Math.min(bottom, nav.top)
      let ancestor = field.parentElement
      while (ancestor) {
        const style = getComputedStyle(ancestor)
        if (['auto', 'scroll', 'hidden'].includes(style.overflowY)) {
          const bounds = ancestor.getBoundingClientRect()
          top = Math.max(top, bounds.top)
          bottom = Math.min(bottom, bounds.bottom)
        }
        ancestor = ancestor.parentElement
      }
      setPanelMaxH(Math.max(0, Math.min(height * 0.55, bottom - rect.bottom - 8)))
      setDropUpMaxH(Math.max(0, Math.min(height * 0.55, rect.top - top - 8)))
    }
    measure()
    const resizeObserver = new ResizeObserver(measure)
    if (containerRef.current) resizeObserver.observe(containerRef.current)
    const content = containerRef.current?.closest('.app-content')
    if (content) resizeObserver.observe(content)
    window.addEventListener('resize', measure)
    window.addEventListener('scroll', measure, true)
    window.visualViewport?.addEventListener('resize', measure)
    window.visualViewport?.addEventListener('scroll', measure)
    return () => {
      resizeObserver.disconnect()
      window.removeEventListener('resize', measure)
      window.removeEventListener('scroll', measure, true)
      window.visualViewport?.removeEventListener('resize', measure)
      window.visualViewport?.removeEventListener('scroll', measure)
    }
  }, [open, expanded, loading, recent.length])

  // 键盘弹起后：将输入框滚动到可视区域（键盘上方）垂直中间位置
  // 注意：使用瞬间滚动（auto），不用平滑动画，避免和浏览器自动滚动叠加产生"先上去再下来"的跳动
  const adjustInputToCenter = () => {
    const input = inputRef.current
    const vp = window.visualViewport
    if (!input || !vp) return

    const rect = input.getBoundingClientRect()
    const inputCenterY = rect.top + rect.height / 2
    const targetCenterY = vp.height / 2

    const delta = inputCenterY - targetCenterY
    if (Math.abs(delta) < 4) return

    // 找到最近的滚动容器
    let scrollContainer: HTMLElement | null = input.parentElement
    while (scrollContainer) {
      const style = window.getComputedStyle(scrollContainer)
      if (style.overflowY === 'auto' || style.overflowY === 'scroll') {
        break
      }
      scrollContainer = scrollContainer.parentElement
    }

    if (scrollContainer) {
      scrollContainer.scrollBy({ top: delta, behavior: 'auto' })
    } else {
      window.scrollBy({ top: delta, behavior: 'auto' })
    }
  }

  // 监听 visualViewport 变化（键盘弹出/收起），输入框聚焦时自动调整到可视区域中间
  useEffect(() => {
    const vp = window.visualViewport
    if (!vp) return

    // 不防抖，立即执行：键盘动画过程中每次高度变化都同步调整，避免和浏览器自动滚动叠加产生跳动
    const handleVpChange = () => {
      if (document.activeElement !== inputRef.current) return
      adjustInputToCenter()
    }

    vp.addEventListener('resize', handleVpChange)
    vp.addEventListener('scroll', handleVpChange)

    return () => {
      vp.removeEventListener('resize', handleVpChange)
      vp.removeEventListener('scroll', handleVpChange)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // 地点检索：防抖 300ms（真实 API 带 24h 缓存；Mock 模式用本地数据，零额度消耗）
  useEffect(() => {
    window.clearTimeout(timer.current)
    if (!kw.trim()) {
      setList([])
      setLoading(false)
      return
    }
    setLoading(true)
    let cancelled = false
    timer.current = window.setTimeout(async () => {
      try {
        let results: Place[]
        if (USE_REAL_API) {
          // 真实百度地图 API 地点检索
          results = (await searchPlace(kw.trim())) as Place[]
        } else {
          // Mock 模式：本地地址库同步搜索，不调用外部 API
          results = searchPlaces(kw.trim())
        }
        if (!cancelled) {
          setList(results)
          setLoading(false)
        }
      } catch {
        if (!cancelled) {
          setList([])
          setLoading(false)
        }
      }
    }, 300)
    return () => {
      window.clearTimeout(timer.current)
      cancelled = true
    }
  }, [kw])

  const pick = (place: Place, source: AddressPickSource) => {
    onSelect(place, source)
    setKw('')
    setOpen(false)
    // 记录搜索地点计数（我的页面统计）
    incrementCount('searches')
    // 搜索选择的地点自动保存为常用位置（最近选择优先展示）
    if (source === 'search') {
      saveRecentPlace({ name: place.name, address: place.address || '', lng: place.lng, lat: place.lat })
      setRecent(loadRecentPlaces())
    }
  }

  const searching = kw.trim().length > 0

  return (
    <div ref={containerRef} className={`address-search ${compact ? 'compact' : ''} ${open ? 'is-open' : ''}`} onBlur={(e) => {
      if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setOpen(false)
    }}>
      <div className="search-input-wrap">
        <IconSearch size={16} className="search-icon" />
        <input
          ref={inputRef}
          value={kw}
          placeholder={placeholder ?? '搜索地点，如：三里屯、国贸、望京'}
          onChange={(e) => {
            setKw(e.target.value)
            requestOpen()
          }}
          onFocus={() => {
            requestOpen()
            // 键盘弹起后，由 visualViewport 监听自动将输入框调整到可视区域中间
            // 这里立即触发一次，不等键盘完全弹出，避免浏览器先把输入框推到顶部再拉回来的跳动
            adjustInputToCenter()
          }}
          onClick={requestOpen}
          aria-expanded={open}
          onKeyDown={(e) => { if (e.key === 'Escape') setOpen(false) }}
          autoFocus={autoFocus}
        />
        {kw && (
          <button
            type="button"
            className="search-clear"
            aria-label="清空"
            onClick={() => {
              setKw('')
              setList([])
            }}
          >
            ×
          </button>
        )}
      </div>

      {open && (recent.length > 0 || searching || !hideCurrentLocation) && (
        <div
          className={`search-dropdown${inline ? ' is-inline' : ''}${dropUp ? ' drop-up' : ''}`}
          style={{ maxHeight: inline ? '55dvh' : dropUp ? dropUpMaxH : panelMaxH }}
        >
          {/* 历史搜索：同一浮层内的一行横向滚动地点 */}
          {recent.length > 0 && (
            <div className="history-search">
              <span className="history-title">历史搜索</span>
              <div className="history-bubbles">
                {recent.map((r) => (
                  <span className="history-bubble history-pill" key={JSON.stringify([r.name, r.lng, r.lat])}>
                    <button type="button" className="history-select-button"
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => pick({ name: r.name, address: r.address, lng: r.lng, lat: r.lat } as Place, 'favorite')}>
                      {r.name}
                    </button>
                    <button type="button" className="history-delete-button" aria-label={`删除历史地点：${r.name}，${r.address || ''}`}
                      onMouseDown={(e) => { e.preventDefault(); e.stopPropagation() }}
                      onClick={(e) => {
                        e.stopPropagation()
                        // 键盘激活后将焦点留在输入框，避免移除按钮时把浮层一起关闭。
                        if (document.activeElement === e.currentTarget) inputRef.current?.focus({ preventScroll: true })
                        setRecent(removeRecentPlace(r))
                      }}>
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* 1. 使用当前位置（真实模式调用百度定位；Mock 模式用模拟定位，零额度消耗）；hideCurrentLocation 时隐藏 */}
          {!hideCurrentLocation && (
            <button
              type="button"
              className="search-item locate"
              disabled={locating}
              onMouseDown={async (e) => {
                e.preventDefault()
                if (locating) return
                if (!USE_REAL_API) {
                  // Mock 模式：直接用模拟定位
                  pick(CURRENT_LOCATION, 'locate')
                  return
                }
                setLocating(true)
                try {
                  const loc = await getCurrentLocation()
                  if (loc) {
                    pick({ name: '当前位置', address: loc.address, lng: loc.lng, lat: loc.lat }, 'locate')
                  } else {
                    pick(CURRENT_LOCATION, 'locate')
                  }
                } catch {
                  pick(CURRENT_LOCATION, 'locate')
                } finally {
                  setLocating(false)
                }
              }}
            >
              <IconLocate size={16} className="item-icon orange" />
              <span>
                <b>{locating ? '定位中…' : '使用当前位置'}</b>
                <em>{CURRENT_LOCATION.address}</em>
              </span>
            </button>
          )}

          {/* 2. 搜索结果：输入关键词时置顶展示，便于直接命中 */}
          {searching && <div className="search-group-title">搜索结果</div>}
          {searching && loading && <div className="search-loading">搜索中…</div>}
          {searching && !loading && list.length === 0 && (
            <div className="search-empty">
              {isBareAdminRegion(kw)
                ? `「${kw}」太宽泛啦，试试搜索更详细的地点吧～`
                : '诶呀呀，没有找到这个地点，换个地点试试吧～'}
            </div>
          )}
          {searching &&
            !loading &&
            (expanded ? list : list.slice(0, 3)).map((p) => (
              <button
                type="button"
                key={p.name}
                className="search-item"
                onMouseDown={(e) => {
                  e.preventDefault()
                  pick(p, 'search')
                }}
              >
                <IconPin size={15} className="item-icon" />
                <span>
                  <b>{p.name}</b>
                  <em>{p.address || p.city || ''}</em>
                </span>
              </button>
            ))}
          {searching && !loading && list.length > 3 && (
            <button type="button" className="search-expand" aria-expanded={expanded}
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => setExpanded((value) => !value)}>
              {expanded ? '收起 ∧' : '查看全部结果 ∨'}
            </button>
          )}
        </div>
      )}
    </div>
  )
}
