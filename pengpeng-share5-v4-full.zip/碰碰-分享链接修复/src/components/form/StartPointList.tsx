// ============================================================
// 出发点位编辑列表（公共组件）：
// 支持 2~6 个点位；每个点位 3 种录入方式（定位/搜索/常用）+ 独立出行方式
// ============================================================

import { useState, useEffect, useRef } from 'react'
import { makePoint, type Place } from '../../mock/places'
import { MODE_META, MODE_ORDER, POINT_COLORS } from '../../mock/constants'
import type { TravelMode, TravelPoint } from '../../types'
import { pointNickname } from '../../utils/format'
import { IconChevronDown, IconEdit, IconPin, IconPlus, IconSearch, IconStar, IconTrash } from '../common/Icons'
import { useToast } from '../common/Toast'
import { AddressSearch, type AddressPickSource } from './AddressSearch'

/** 单个点位录入面板：统一在「地址搜索下拉框」里完成 定位 / 常用 / 搜索 三种录入 */
function PointPanel({
  onSelect,
  autoFocus,
  onOpenChange,
  index,
}: {
  onSelect: (p: Place, source: TravelPoint['source']) => void
  onOpenChange?: (open: boolean) => void
  autoFocus?: boolean
  /** 出发点下标；>0 时隐藏「使用当前位置」（只有出发点1有当前位置） */
  index: number
}) {
  return (
    <div className="point-panel">
      <AddressSearch
        autoFocus={autoFocus}
        onOpenChange={onOpenChange}
        onSelect={(p, s: AddressPickSource) => onSelect(p, s)}
      />
    </div>
  )
}

/** 单个出发点卡片 */
function PointCard({
  point,
  index,
  onChange,
  onRemove,
  onRelocate,
  showNickTip,
}: {
  point: TravelPoint
  index: number
  onChange: (p: TravelPoint) => void
  onRemove: () => void
  /** 仅第一个点（我的位置）有重新定位回调 */
  onRelocate?: () => void
  /** 进入页面时指向名字/笔的提示气泡 */
  showNickTip?: boolean
}) {
  const color = POINT_COLORS[index % POINT_COLORS.length]
  const [editing, setEditing] = useState(!point.name) // 未选择位置时直接展开录入面板
  const [editingNick, setEditingNick] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [modeOpen, setModeOpen] = useState(false)
  const [nickDraft, setNickDraft] = useState(pointNickname(point, index))
  const { show } = useToast()
  const isMyLocation = index === 0

  const pick = (place: Place, source: TravelPoint['source']) => {
    onChange({
      ...point,
      name: place.name,
      address: place.address,
      lng: place.lng,
      lat: place.lat,
      source,
      isCurrentLocation: source === 'locate' ? true : point.isCurrentLocation,
    })
    setEditing(false)
  }

  const saveNick = () => {
    const v = nickDraft.trim()
    if (v) onChange({ ...point, nickname: v.slice(0, 8) })
    else setNickDraft(pointNickname(point, index))
    setEditingNick(false)
  }

  return (
    <div className={`point-card${modeOpen ? ' mode-open' : ''}${searchOpen ? ' search-open' : ''}`}>
      <div className="point-card-head">
        <span className="point-marker-slot"><span className="point-dot" style={{ background: color }} /></span>
        {editingNick ? (
          <input
            className="point-nick-input"
            value={nickDraft}
            maxLength={8}
            autoFocus
            onChange={(e) => setNickDraft(e.target.value)}
            onBlur={saveNick}
            onKeyDown={(e) => {
              if (e.key === 'Enter') saveNick()
              if (e.key === 'Escape') {
                setNickDraft(pointNickname(point, index))
                setEditingNick(false)
              }
            }}
            aria-label="编辑碰友昵称"
          />
        ) : (
          <button
            type="button"
            className="point-title point-title-edit"
            onClick={() => {
              setNickDraft(pointNickname(point, index))
              setEditingNick(true)
            }}
            title="点击编辑昵称"
          >
            {pointNickname(point, index)}
            <IconEdit size={16} className="point-title-pen" />
          </button>
        )}
        {/* 每个点位独立出行方式：自定义胶囊下拉 */}
        <div className="mode-select">
          <button
            type="button"
            className={`mode-pill${modeOpen ? ' open' : ''}`}
            onClick={() => setModeOpen((v) => !v)}
            aria-label={`${pointNickname(point, index)} 出行方式：${MODE_META[point.mode].label}`}
          >
            <span>{MODE_META[point.mode].label}</span>
            <IconChevronDown size={13} className="mode-chevron" />
          </button>
          {modeOpen && (
            <>
              <div className="mode-overlay" onClick={() => setModeOpen(false)} />
              <div className="mode-menu">
                {MODE_ORDER.map((m) => (
                  <button
                    key={m}
                    type="button"
                    className={`mode-menu-item${m === point.mode ? ' active' : ''}`}
                    onClick={() => {
                      onChange({ ...point, mode: m })
                      setModeOpen(false)
                    }}
                  >
                    {MODE_META[m].label}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
          <button
            type="button"
            className="point-remove"
            aria-label={`删除${pointNickname(point, index)}`}
            onClick={() => {
              if (isMyLocation) {
                show('不要把自己删掉哦~', 'warn')
                return
              }
              onRemove()
            }}
          >
            <IconTrash size={16} />
          </button>
        {showNickTip && !editingNick && (
          <span className="nick-tip">点击这里能够修改名字<i /></span>
        )}
      </div>

      {/* 已选位置摘要 */}
      {point.name && (
        <div className="point-value" onClick={() => setEditing((v) => !v)} role="button" tabIndex={0}>
          <span className="point-marker-slot"><IconPin size={15} style={{ color }} /></span>
          <span>
            <b>{point.name}</b>
            <em>{point.address}</em>
          </span>
          {isMyLocation && onRelocate ? (
            <button
              type="button"
              className="point-value-relocate"
              onClick={(e) => {
                e.stopPropagation()
                onRelocate()
              }}
            >
              重新定位
            </button>
          ) : (
            <span className="point-value-edit">重新选择</span>
          )}
        </div>
      )}

      {/* 三种录入方式统一在「地址搜索下拉框」里完成（定位 / 常用 / 搜索） */}
      {editing ? (
        <PointPanel
          autoFocus
          index={index}
          onOpenChange={setSearchOpen}
          onSelect={pick}
        />
      ) : (
        <div className="point-entry-ways">
          <button type="button" onClick={() => setEditing(true)}>
            <IconSearch size={14} /> 换地点
          </button>
        </div>
      )}
    </div>
  )
}

// 仅本次页面运行内有效；owner 避免 StrictMode effect 重放吞掉首次提示。
let nicknameTipOwner: object | null = null
let nicknameTipDeadline = 0

/** 出发点位整体列表 */
export function StartPointList({
  points,
  onChange,
  compact,
  nicknameOnboarding = false,
  onRelocate,
}: {
  points: TravelPoint[]
  onChange: (next: TravelPoint[]) => void
  /** 结果页参数修改抽屉里的紧凑模式（复用同一组件） */
  compact?: boolean
  /** 仅主流程 People 首次挂载允许消费提示。 */
  nicknameOnboarding?: boolean
  /** 我的位置重新定位回调（仅第一个点有效） */
  onRelocate?: () => void
}) {
  const { show } = useToast()
  const [nickTip, setNickTip] = useState(false)
  const tipOwner = useRef({})
  useEffect(() => {
    if (!nicknameOnboarding || compact) return
    if (!nicknameTipOwner) {
      nicknameTipOwner = tipOwner.current
      nicknameTipDeadline = Date.now() + 3400
    }
    if (nicknameTipOwner !== tipOwner.current) return
    const remaining = nicknameTipDeadline - Date.now()
    setNickTip(remaining > 0)
    const timer = window.setTimeout(() => setNickTip(false), Math.max(0, remaining))
    return () => window.clearTimeout(timer)
  }, [nicknameOnboarding, compact])

  const update = (i: number, p: TravelPoint) => {
    const next = points.slice()
    next[i] = p
    onChange(next)
  }

  const add = () => {
    if (points.length >= 6) {
      show('最多支持 6 个碰友', 'warn')
      return
    }
    // 下一个朋友序号 = 现有朋友最大序号 +1（老数据无序号时按位置兜底）
    const friends = points.slice(1)
    const maxSeq = friends.reduce((m, pt, i) => Math.max(m, pt.friendSeq ?? i + 1), 0)
    onChange([...points, makePoint({ name: '', address: '', lng: 116.46, lat: 39.92 }, 'transit', 'search', { friendSeq: maxSeq + 1 })])
  }

  return (
    <div className={`point-list ${compact ? 'compact' : ''}`}>
      {points.map((p, i) => (
        <PointCard
          key={p.id}
          point={p}
          index={i}
          onChange={(np) => update(i, np)}
          onRemove={() => onChange(points.filter((_, j) => j !== i))}
          onRelocate={i === 0 ? onRelocate : undefined}
          showNickTip={nicknameOnboarding && !compact && nickTip && i === 0}
        />
      ))}
      <button
        type="button"
        className={`add-point ${points.length >= 6 ? 'disabled' : ''}`}
        onClick={add}
      >
        <IconPlus size={16} />
        添加碰友（{points.length}/6）
      </button>
    </div>
  )
}
