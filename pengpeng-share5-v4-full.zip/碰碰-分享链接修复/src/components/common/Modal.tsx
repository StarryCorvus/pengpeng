// ============================================================
// 通用居中弹窗（店铺详情 / 分享卡片等）
// ============================================================

import { useEffect, type ReactNode } from 'react'

export function Modal({
  open,
  onClose,
  children,
  className,
}: {
  open: boolean
  onClose: () => void
  children: ReactNode
  className?: string
}) {
  // ESC 关闭 + 禁止背景滚动（保留滚动位置，避免页面跳动）
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    const scrollY = window.scrollY || document.documentElement.scrollTop
    document.body.style.position = 'fixed'
    document.body.style.top = `-${scrollY}px`
    document.body.style.width = '100%'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.position = ''
      document.body.style.top = ''
      document.body.style.width = ''
      window.scrollTo(0, scrollY)
    }
  }, [open, onClose])

  if (!open) return null
  return (
    <div className="modal-mask" onClick={onClose}>
      <div className={`modal-card ${className ?? ''}`} onClick={(e) => e.stopPropagation()} role="dialog">
        {children}
      </div>
    </div>
  )
}
