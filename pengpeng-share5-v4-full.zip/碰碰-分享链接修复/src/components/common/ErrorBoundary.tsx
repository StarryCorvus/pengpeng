// ============================================================
// 错误边界：捕获子组件渲染错误，避免白屏，显示降级 UI
// ============================================================

import { Component, type ErrorInfo, type ReactNode } from 'react'

interface Props {
  children: ReactNode
}
interface State {
  hasError: boolean
  error?: Error
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error }
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // 打印错误便于调试，但不崩溃
    console.error('[ErrorBoundary] 捕获到渲染错误:', error, errorInfo)
  }

  handleReset = () => {
    this.setState({ hasError: false, error: undefined })
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: '100dvh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '32px 24px',
          background: '#f7f8fa',
          textAlign: 'center',
        }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>😅</div>
          <h2 style={{ fontSize: 18, fontWeight: 700, color: '#1f2329', marginBottom: 8 }}>页面出了点小问题</h2>
          <p style={{ fontSize: 13, color: '#8f959e', marginBottom: 20, lineHeight: 1.6 }}>
            {this.state.error?.message || '未知错误'}
          </p>
          <button
            type="button"
            onClick={this.handleReset}
            style={{
              padding: '10px 28px',
              background: '#FF7A2F',
              color: '#fff',
              border: 'none',
              borderRadius: 999,
              fontSize: 14,
              fontWeight: 600,
              cursor: 'pointer',
            }}
          >
            重新加载
          </button>
          <button
            type="button"
            onClick={() => window.location.reload()}
            style={{
              marginTop: 10,
              padding: '8px 24px',
              background: 'none',
              color: '#8f959e',
              border: '1px solid #e5e6eb',
              borderRadius: 999,
              fontSize: 13,
              cursor: 'pointer',
            }}
          >
            刷新页面
          </button>
        </div>
      )
    }
    return this.props.children
  }
}
