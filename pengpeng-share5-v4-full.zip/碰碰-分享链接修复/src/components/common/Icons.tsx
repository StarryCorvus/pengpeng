// ============================================================
// 轻量内联 SVG 图标集（避免引入图标库依赖）
// ============================================================

import type { CSSProperties, ReactNode } from 'react'
import type { TravelMode } from '../../types'

export interface IconProps {
  size?: number
  className?: string
  filled?: boolean
  style?: CSSProperties
}

function Svg({ size = 20, className, filled, style, children }: IconProps & { children: ReactNode }) {
  return (
    <svg
      className={className}
      style={style}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? 'currentColor' : 'none'}
      stroke={filled ? 'none' : 'currentColor'}
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {children}
    </svg>
  )
}

/** 地图图钉（实心） */
export const IconPin = (p: IconProps) => (
  <Svg {...p} filled>
    <path d="M12 21.5S5 15.6 5 10a7 7 0 1 1 14 0c0 5.6-7 11.5-7 11.5Z" />
    <circle cx="12" cy="10" r="2.4" fill="#fff" />
  </Svg>
)

export const IconSearch = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="11" cy="11" r="6.5" />
    <path d="m20 20-4.4-4.4" />
  </Svg>
)

export const IconLocate = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="3.4" />
    <path d="M12 2.6v3M12 18.4v3M2.6 12h3M18.4 12h3" />
  </Svg>
)

export const IconStar = (p: IconProps) => (
  <Svg {...p} filled>
    <path d="m12 3.5 2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8L3.5 9.7l5.9-.9L12 3.5Z" />
  </Svg>
)

export const IconClock = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7v5l3.2 2" />
  </Svg>
)

export const IconBus = (p: IconProps) => (
  <Svg {...p}>
    <rect x="4.5" y="6.5" width="15" height="10" rx="2.5" />
    <path d="M4.5 11.5h15" />
    <circle cx="8.5" cy="18" r="1.6" fill="currentColor" stroke="none" />
    <circle cx="15.5" cy="18" r="1.6" fill="currentColor" stroke="none" />
  </Svg>
)

export const IconCar = (p: IconProps) => (
  <Svg {...p}>
    <path d="M5.5 11.5 7 7.6a2 2 0 0 1 1.9-1.3h6.2a2 2 0 0 1 1.9 1.3l1.5 3.9" />
    <rect x="3.8" y="11.5" width="16.4" height="5.6" rx="1.8" />
    <circle cx="8" cy="16.6" r="1.5" fill="currentColor" stroke="none" />
    <circle cx="16" cy="16.6" r="1.5" fill="currentColor" stroke="none" />
  </Svg>
)

export const IconBike = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="6.2" cy="16.8" r="2.9" />
    <circle cx="17.8" cy="16.8" r="2.9" />
    <path d="M6.2 16.8 9 10h4.6l4.2 6.8M9 10l1.6-2.4M13.6 7.6h2.6" />
  </Svg>
)

export const IconWalk = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="12" cy="4.6" r="1.7" />
    <path d="m10.9 8.2-2.4 3.6 2.8 1.6L11 18l2.6-.5-1-3.9 2.3-1.4-2.4-4Z" />
    <path d="M9.2 16.6 6.8 21M14.6 16.6 17 21" />
  </Svg>
)

export const IconTaxi = (p: IconProps) => (
  <Svg {...p}>
    <path d="M8.6 5.6h6.8" />
    <path d="M7 8.2l1-2.6h8l1 2.6" />
    <rect x="3.8" y="8.2" width="16.4" height="5.6" rx="1.8" />
    <path d="M5.7 11h12.6" />
    <circle cx="8" cy="16.8" r="1.5" fill="currentColor" stroke="none" />
    <circle cx="16" cy="16.8" r="1.5" fill="currentColor" stroke="none" />
  </Svg>
)

export const IconNav = (p: IconProps) => (
  <Svg {...p}>
    <path d="M4 4l16 7.5-7.5 1.5L11 20.5 4 4Z" />
  </Svg>
)

export const IconHeart = (p: IconProps) => (
  <Svg {...p}>
    <path d="M12 20.3 4.7 13a4.7 4.7 0 0 1 6.6-6.7l.7.7.7-.7a4.7 4.7 0 0 1 6.6 6.7L12 20.3Z" />
  </Svg>
)

export const IconBook = (p: IconProps) => (
  <Svg {...p}>
    <path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v15.5H6.5A2.5 2.5 0 0 0 4 20v-15.5Z" />
    <path d="M4 20a2.5 2.5 0 0 1 2.5-2.5H20" />
    <path d="M8 6h8M8 9h6" />
  </Svg>
)

export const IconShare = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="6" cy="12" r="2.6" />
    <circle cx="17.5" cy="5.5" r="2.6" />
    <circle cx="17.5" cy="18.5" r="2.6" />
    <path d="m8.3 10.8 6.9-3.9M8.3 13.2l6.9 3.9" />
  </Svg>
)

export const IconClose = (p: IconProps) => (
  <Svg {...p}>
    <path d="M6 6l12 12M18 6 6 18" />
  </Svg>
)

export const IconPlus = (p: IconProps) => (
  <Svg {...p}>
    <path d="M12 5v14M5 12h14" />
  </Svg>
)

export const IconTrash = (p: IconProps) => (
  <Svg {...p}>
    <path d="M4.5 7h15M9.5 7V4.8h5V7M6.5 7l.8 12.2h9.4L17.5 7M10 11v5.5M14 11v5.5" />
  </Svg>
)

export const IconChevronRight = (p: IconProps) => (
  <Svg {...p}>
    <path d="m9 5.5 6.5 6.5L9 18.5" />
  </Svg>
)

export const IconChevronDown = (p: IconProps) => (
  <Svg {...p}>
    <path d="m5.5 9 6.5 6.5L18.5 9" />
  </Svg>
)

export const IconMapView = (p: IconProps) => (
  <Svg {...p}>
    <rect x="4" y="4" width="16" height="16" rx="2.5" />
    <path d="M4 9h16M4 15h16M9 4v16M15 4v16" />
  </Svg>
)

export const IconListView = (p: IconProps) => (
  <Svg {...p}>
    <path d="M9 6h11M9 12h11M9 18h11" />
    <circle cx="5" cy="6" r="1" fill="currentColor" stroke="none" />
    <circle cx="5" cy="12" r="1" fill="currentColor" stroke="none" />
    <circle cx="5" cy="18" r="1" fill="currentColor" stroke="none" />
  </Svg>
)

export const IconZoomIn = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="11" cy="11" r="6.5" />
    <path d="m20 20-4.4-4.4M11 8.2v5.6M8.2 11h5.6" />
  </Svg>
)

export const IconZoomOut = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="11" cy="11" r="6.5" />
    <path d="m20 20-4.4-4.4M8.2 11h5.6" />
  </Svg>
)

export const IconBack = (p: IconProps) => (
  <Svg {...p}>
    <path d="M14.5 5 8 12l6.5 7" />
  </Svg>
)

/** 闪光/星星（小贴士图标） */
export const IconSparkles = (p: IconProps) => (
  <Svg {...p}>
    <path d="M12 3l1.8 4.8L18.5 9.5l-4.7 1.7L12 16l-1.8-4.8L5.5 9.5l4.7-1.7L12 3Z" />
    <path d="M19 14l.9 2.1L22 17l-2.1.9L19 20l-.9-2.1L16 17l2.1-.9L19 14Z" />
  </Svg>
)

export const IconEdit = (p: IconProps) => (
  <Svg {...p}>
    <path d="M4 20h4.5L20 8.5a2.1 2.1 0 0 0-3-3L5.5 17 4 20Z" />
    <path d="m14.5 7 3 3" />
  </Svg>
)

export const IconUpload = (p: IconProps) => (
  <Svg {...p}>
    <path d="M12 16V4" />
    <path d="m7 9 5-5 5 5" />
    <path d="M4 17v2a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-2" />
  </Svg>
)

export const IconRefresh = (p: IconProps) => (
  <Svg {...p}>
    <path d="M20 12a8 8 0 1 1-2.3-5.6" />
    <path d="M20 3.5V8h-4.5" />
  </Svg>
)

export const IconWarning = (p: IconProps) => (
  <Svg {...p}>
    <path d="M12 4 2.8 19.5h18.4L12 4Z" />
    <path d="M12 10v4.2M12 17.2v.1" />
  </Svg>
)

export const IconCheck = (p: IconProps) => (
  <Svg {...p}>
    <path d="m5 12.5 4.5 4.5L19 7.5" />
  </Svg>
)

/** 指南针（碰碰 Tab 图标） */
export const IconCompass = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="m15.5 8.5-2 5-5 2 2-5 5-2Z" fill="currentColor" stroke="none" />
  </Svg>
)

/** 用户（我的 Tab 图标） */
export const IconUser = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="12" cy="8" r="3.5" />
    <path d="M4.5 20c0-3.6 3.4-6 7.5-6s7.5 2.4 7.5 6" />
  </Svg>
)

/** 出行方式 -> 图标 */
export function ModeIcon({ mode, size, className }: { mode: TravelMode; size?: number; className?: string }) {
  const props = { size, className }
  switch (mode) {
    case 'transit':
      return <IconBus {...props} />
    case 'drive':
      return <IconCar {...props} />
    case 'taxi':
      return <IconTaxi {...props} />
    case 'bike':
      return <IconBike {...props} />
    case 'walk':
      return <IconWalk {...props} />
  }
}
