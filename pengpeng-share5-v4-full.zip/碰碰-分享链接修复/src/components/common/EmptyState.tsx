// ============================================================
// 空状态组件：无交集 / 无匹配店铺的友好兜底
// ============================================================

import type { ReactNode } from 'react'

export interface EmptyAction {
  label: string
  hint?: string
  icon?: ReactNode
  primary?: boolean
  onClick: () => void
}

export function EmptyState({
  icon,
  title,
  desc,
  actions,
}: {
  icon?: ReactNode
  title: string
  desc?: string
  actions?: EmptyAction[]
}) {
  return (
    <div className="empty-state">
      <div className="empty-icon">{icon ?? '🕳️'}</div>
      <div className="empty-title">{title}</div>
      {desc && <div className="empty-desc">{desc}</div>}
      {actions && actions.length > 0 && (
        <div className="empty-actions">
          {actions.map((a, i) => (
            <button key={i} className={`empty-action ${a.primary ? 'primary' : ''}`} onClick={a.onClick}>
              {a.icon}
              <span className="empty-action-main">
                <b>{a.label}</b>
                {a.hint && <em>{a.hint}</em>}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
