// ============================================================
// 底部 Tab 导航：碰碰（主功能） / 我的（个人中心）
// 普通页面流布局，位于内容之后，用户下拉到底部才能看到
// ============================================================

import { IconCompass, IconUser } from './Icons'

export type TabKey = 'app' | 'profile'

export function BottomNav({
  active,
  onChange,
}: {
  active: TabKey
  onChange: (tab: TabKey) => void
}) {
  const tabs: { key: TabKey; label: string; icon: React.ReactNode }[] = [
    { key: 'app', label: '碰碰', icon: <IconCompass size={20} /> },
    { key: 'profile', label: '我的', icon: <IconUser size={20} /> },
  ]

  return (
    <nav className="bottom-nav">
      {tabs.map((t) => (
        <button
          type="button"
          key={t.key}
          className={`bottom-nav-item ${active === t.key ? 'active' : ''}`}
          aria-current={active === t.key ? 'page' : undefined}
          onClick={() => onChange(t.key)}
        >
          <span className="bottom-nav-icon">{t.icon}</span>
          <span className="bottom-nav-label">{t.label}</span>
        </button>
      ))}
    </nav>
  )
}
