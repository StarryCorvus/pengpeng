// ============================================================
// 全屏 Loading：跳转结果页 / 参数修改后的模拟计算
// 改为「进度条 + 阶段性文案」，不再展示「X / 20 家」这类候选数量反馈。
// ============================================================

export function LoadingOverlay({
  text,
  sub,
  progress,
}: {
  text?: string
  sub?: string
  /** 0~1 的完成度；不传时只显示转圈，传了则显示进度条 */
  progress?: number
}) {
  const shown = typeof progress === 'number' ? Math.max(0, Math.min(1, progress)) : undefined
  const percent = shown != null ? Math.round(shown * 100) : null

  return (
    <div className="loading-overlay">
      <div className="loading-card">
        <div className="loading-ring" aria-hidden="true" />
        <div className="loading-text">
          {text}
          <span className="loading-dots">
            <i />
            <i />
            <i />
          </span>
        </div>
        {sub && <div className="loading-sub">{sub}</div>}
        {shown != null && (
          <div className="loading-progress" role="progressbar" aria-valuenow={percent ?? 0} aria-valuemin={0} aria-valuemax={100}>
            <div className="loading-progress-bar" style={{ width: `${percent}%` }} />
          </div>
        )}
      </div>
    </div>
  )
}
