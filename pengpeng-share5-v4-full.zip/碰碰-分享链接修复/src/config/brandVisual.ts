/** Presentation only: no FormState, storage, pipeline or service settings. */
export const SPLASH_DECORATIVE_COPY = '～～～～～～～～'
export const SPLASH_FOOT_DECORATIVE_COPY = '～～～～～～'
export const CATEGORY_HINT_COPY = '～'
export const FLOW_DECORATIVE_COPY = '～'
export const CATEGORY_NEXT_CTA = '看看去哪碰'
export const SPLASH_ENTER_COPY = '碰个面吧'
export const BRAND_SLOGAN = '想见，那就轻松碰一面' // Existing confirmed slogan.
export type MapVisualMode = 'default' | 'warmPaper'
export const MAP_VISUAL_STYLE: MapVisualMode = 'warmPaper'
// Paper texture strength is authored in src/assets/brand/material/paper-grain.svg.
export const ROUGH_LINE_WIDTH = 2.2

export const PEOPLE_NEXT_CTA = '挑个想做的'
