// ============================================================
// 全局类型定义 —— 碰碰 v1.0
// ============================================================

/** 出行方式 */
export type TravelMode = 'transit' | 'drive' | 'taxi' | 'bike' | 'walk'

/** 出发点位（支持 2~6 个，每个独立绑定出行方式） */
export interface TravelPoint {
  id: string
  /** 点位名称（展示用） */
  name: string
  /** 详细地址 */
  address: string
  /** 经纬度（mock 坐标系，北京附近） */
  lng: number
  lat: number
  /** 该点位独立的出行方式 */
  mode: TravelMode
  /** 录入方式：定位获取 / 关键词搜索 / 常用地址 */
  source: 'locate' | 'search' | 'favorite'
  /** 是否为模拟当前定位 */
  isCurrentLocation?: boolean
  /**
   * 碰友昵称（用户可编辑）：
   * - 第 1 个点（自己）默认「我」
   * - 其余点默认「碰友1」「碰友2」…
   * 结果页 / 地图 / 详情卡片均优先展示此昵称。
   */
  nickname?: string
  /** 朋友创建序号：用于「碰友N」默认名，删除后不重排 */
  friendSeq?: number
}

/** 业态品类：一级 key + 二级名称 */
export interface CategoryValue {
  primary: string
  secondary: string
}

/** 需求表单整体状态（本地持久化记忆） */
export interface FormState {
  points: TravelPoint[]
  category: CategoryValue | null
  /**
   * 通勤时间差筛选阈值（分钟）：
   * 只保留「各方通勤时长差 ≤ 该值」的店铺，越小越公平。
   * 可选预设 10/20/30，或自定义 1~180；默认 20。
   */
  timeDiff: number
}

/** 商户 POI */
export interface Shop {
  id: string
  name: string
  /** 一级品类 key（与 CATEGORY_TREE 对齐） */
  primary: string
  /** 二级品类名（与 CATEGORY_TREE children 对齐，购物中心为空串） */
  sub: string
  /** 二级品类展示名 */
  category: string
  /** 城市，例如北京市 */
  city: string
  /** 行政区或商圈，数据源缺失时为空 */
  area: string
  /** 具体门店的详细地址 */
  address: string
  lng: number
  lat: number
  rating: number
  perCapita: number
  hours: string
  /** 店铺介绍，不以地址充当介绍 */
  intro: string
  /** 店铺图片 URL 列表（真实 API 从百度 POI 详情获取，Mock 为占位图） */
  images: string[]
  /** 百度 POI uid（真实 API 用，Mock 为空） */
  uid?: string
  /** 店铺电话 */
  phone?: string
  /** 店铺标签 */
  tags?: string[]
  /** Internal recall provenance; excluded from sharing and persistent favorites. */
  matchedSubcategoryKeys?: string[]
  /** Verified logical type for leisure-all; empty means unclassified supplementary recall. */
  logicalSubcategoryKey?: string
}

/** 带通勤计算结果的店铺 */
export interface ShopWithCommute extends Shop {
  /** 到每一个出发点的通勤信息（含出行方式、时长、mock 路费） */
  commutes: { pointId: string; pointName: string; mode: TravelMode; minutes: number; fare: number }[]
  /** 各方通勤时间差值（公平度，越小越公平） */
  fairness: number
  /** 各方平均通勤分钟数 */
  avg: number
}

/** 经纬度点 */
export interface GeoPoint {
  lng: number
  lat: number
}

/** AI 筛选推荐（原型阶段为 Mock：按公平度+评分加权挑出首选） */
export interface ShopRecommendation {
  shop: ShopWithCommute
  /** 推荐理由（模型生成文案的 Mock） */
  reason: string
}

/** mock 计算整体结果 */
export interface MockResult {
  shops: ShopWithCommute[]
  /** AI 筛选推荐（可空） */
  recommendation: ShopRecommendation | null
  reason: 'ok' | 'no_shops'
}

/** 视图切换 */
export type ResultView = 'map' | 'list'
