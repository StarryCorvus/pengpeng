// ============================================================
// 坐标与几何工具（mock 用）：
// 原型阶段不接真实地图投影，使用北京附近等距近似米制平面，
// 后续接入真实高德地图时仅需替换投影层。
// ============================================================

import type { GeoPoint } from '../types'

/** 近似投影原点（北京市区附近） */
const LNG0 = 116.4
const LAT0 = 39.9
/** 纬度 39.9° 处：1° 经度 ≈ 85.4km，1° 纬度 ≈ 111.3km */
export const M_PER_DEG_LNG = 85393
export const M_PER_DEG_LAT = 111320

export interface MPoint {
  x: number
  y: number
}

/** 经纬度 -> 米制平面 */
export function toMeters(lng: number, lat: number): MPoint {
  return { x: (lng - LNG0) * M_PER_DEG_LNG, y: (lat - LAT0) * M_PER_DEG_LAT }
}

/** 米制平面 -> 经纬度 */
export function fromMeters(x: number, y: number): GeoPoint {
  return { lng: LNG0 + x / M_PER_DEG_LNG, lat: LAT0 + y / M_PER_DEG_LAT }
}

/** 两点直线距离（米，mock 通勤距离用） */
export function distMeters(a: GeoPoint, b: GeoPoint): number {
  const p = toMeters(a.lng, a.lat)
  const q = toMeters(b.lng, b.lat)
  return Math.hypot(p.x - q.x, p.y - q.y)
}

/** 数值裁剪 */
export function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v))
}

/** 点在多边形内（射线法） */
export function pointInPolygon(px: number, py: number, poly: MPoint[]): boolean {
  let inside = false
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i].x
    const yi = poly[i].y
    const xj = poly[j].x
    const yj = poly[j].y
    if (yi > py !== yj > py && px < ((xj - xi) * (py - yi)) / (yj - yi) + xi) {
      inside = !inside
    }
  }
  return inside
}

/** 多边形质心（简单多边形） */
export function polygonCentroid(poly: MPoint[]): MPoint {
  let a = 0
  let cx = 0
  let cy = 0
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const f = poly[j].x * poly[i].y - poly[i].x * poly[j].y
    a += f
    cx += (poly[j].x + poly[i].x) * f
    cy += (poly[j].y + poly[i].y) * f
  }
  a *= 0.5
  if (Math.abs(a) < 1e-9) return { x: poly[0].x, y: poly[0].y }
  return { x: cx / (6 * a), y: cy / (6 * a) }
}

/** 一组点的均值中心（米制） */
export function meanCentroid(points: GeoPoint[]): MPoint {
  const ps = points.map((p) => toMeters(p.lng, p.lat))
  const n = ps.length || 1
  return {
    x: ps.reduce((s, p) => s + p.x, 0) / n,
    y: ps.reduce((s, p) => s + p.y, 0) / n,
  }
}

/** 地图装饰物（mock 底图：河流 / 道路 / 公园，经纬度坐标） */
export const MAP_DECOR = {
  river: [
    [116.438, 39.968, 116.462, 39.958, 116.484, 39.942, 116.502, 39.918] as number[],
    [116.438, 39.968, 116.455, 39.972] as number[],
  ],
  roads: [
    { w: 2.4, pts: [116.30, 39.985, 116.36, 39.988, 116.44, 39.986, 116.53, 39.982] },
    { w: 2.4, pts: [116.31, 39.908, 116.40, 39.912, 116.50, 39.908] },
    { w: 2, pts: [116.355, 39.86, 116.357, 39.92, 116.362, 39.99, 116.366, 40.03] },
    { w: 2, pts: [116.435, 39.865, 116.44, 39.92, 116.445, 39.98, 116.45, 40.025] },
    { w: 1.5, pts: [116.40, 39.87, 116.403, 39.94, 116.407, 40.01] },
    { w: 1.5, pts: [116.50, 39.88, 116.50, 39.94, 116.496, 40.0] },
    { w: 1.2, pts: [116.375, 39.925, 116.42, 39.928, 116.46, 39.93] },
    { w: 1.2, pts: [116.32, 39.935, 116.35, 39.938, 116.38, 39.941] },
    { w: 1.2, pts: [116.46, 39.96, 116.47, 39.99] },
  ],
  parks: [
    { box: [116.464, 39.922, 116.498, 39.946], name: '朝阳公园' },
    { box: [116.388, 39.985, 116.418, 40.008], name: '奥体中心' },
    { box: [116.332, 39.986, 116.352, 40.002], name: '清华园' },
  ],
}
