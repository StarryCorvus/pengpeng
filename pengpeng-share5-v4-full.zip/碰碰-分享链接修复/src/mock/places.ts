// ============================================================
// Mock 地址数据：当前定位 / 地址库 / 常用地址
// ============================================================

import type { TravelPoint } from '../types'

/** 模拟当前定位（第一个出发点默认填充） */
export const CURRENT_LOCATION: { name: string; address: string; lng: number; lat: number } = {
  name: '当前位置',
  address: '北京市朝阳区·望京SOHO附近（模拟定位）',
  lng: 116.4814,
  lat: 39.9961,
}

export interface Place {
  name: string
  address: string
  lng: number
  lat: number
  /** 百度检索返回的城市名，用于下拉副标题兜底展示 */
  city?: string
}

/** Mock 地址库（关键词搜索数据源，覆盖北京主要区域） */
export const ADDRESS_DB: Place[] = [
  { name: '望京SOHO', address: '朝阳区望京街10号', lng: 116.4814, lat: 39.9961 },
  { name: '国贸地铁站', address: '朝阳区建国门外大街', lng: 116.4606, lat: 39.9087 },
  { name: '国贸大厦', address: '朝阳区建国门外大街1号', lng: 116.459, lat: 39.9095 },
  { name: '三里屯太古里', address: '朝阳区三里屯路19号', lng: 116.4551, lat: 39.937 },
  { name: '朝阳大悦城', address: '朝阳区朝阳北路101号', lng: 116.5143, lat: 39.9243 },
  { name: '蓝色港湾', address: '朝阳区朝阳公园路6号', lng: 116.476, lat: 39.9455 },
  { name: '中关村地铁站', address: '海淀区中关村大街', lng: 116.3158, lat: 39.9842 },
  { name: '中关村软件园', address: '海淀区东北旺西路8号', lng: 116.288, lat: 40.04 },
  { name: '五道口购物中心', address: '海淀区成府路28号', lng: 116.337, lat: 39.992 },
  { name: '西单大悦城', address: '西城区西单北大街131号', lng: 116.374, lat: 39.9139 },
  { name: '王府井大街', address: '东城区王府井大街', lng: 116.4109, lat: 39.9145 },
  { name: '奥体中心', address: '朝阳区国家体育场南路1号', lng: 116.397, lat: 39.982 },
  { name: '颐堤港', address: '朝阳区酒仙桥路18号', lng: 116.494, lat: 39.9745 },
  { name: '合生汇', address: '朝阳区西大望路21号', lng: 116.477, lat: 39.892 },
  { name: '东直门枢纽', address: '东城区东直门外大街', lng: 116.437, lat: 39.941 },
  { name: '西直门枢纽', address: '西城区西直门外大街', lng: 116.354, lat: 39.94 },
  { name: '北京南站', address: '丰台区永外大街车站路12号', lng: 116.3786, lat: 39.8652 },
  { name: '北京西站', address: '丰台区莲花池东路118号', lng: 116.322, lat: 39.894 },
  { name: '双井地铁站', address: '朝阳区广渠门外大街', lng: 116.459, lat: 39.894 },
  { name: '亮马桥地铁站', address: '朝阳区东三环北路', lng: 116.464, lat: 39.948 },
  { name: '天通苑北站', address: '昌平区太平庄中街', lng: 116.417, lat: 40.065 },
  { name: '回龙观地铁站', address: '昌平区回龙观西大街', lng: 116.337, lat: 40.074 },
  { name: '亦庄文化园', address: '大兴区文化园西路', lng: 116.506, lat: 39.795 },
  { name: '金融街购物中心', address: '西城区金城坊街2号', lng: 116.363, lat: 39.914 },
  { name: '朝阳公园', address: '朝阳区朝阳公园南路1号', lng: 116.477, lat: 39.933 },
  { name: '团结湖公园', address: '朝阳区团结湖南里16号', lng: 116.461, lat: 39.932 },
  { name: '青年路地铁站', address: '朝阳区朝阳北路', lng: 116.493, lat: 39.922 },
  { name: '公主坟地铁站', address: '海淀区复兴路', lng: 116.308, lat: 39.907 },
  { name: '六里桥东站', address: '丰台区广安路', lng: 116.304, lat: 39.88 },
  { name: '魏公村地铁站', address: '海淀区中关村南大街', lng: 116.318, lat: 39.958 },
  { name: '上地地铁站', address: '海淀区信息路', lng: 116.31, lat: 40.032 },
  { name: '亚运村', address: '朝阳区北辰东路', lng: 116.407, lat: 39.995 },
  { name: '四惠地铁站', address: '朝阳区京通快速路', lng: 116.496, lat: 39.907 },
  { name: '劲松地铁站', address: '朝阳区东三环南路', lng: 116.456, lat: 39.884 },
  { name: '崇文门地铁站', address: '东城区崇文门外大街', lng: 116.421, lat: 39.899 },
  { name: '前门大街', address: '东城区前门大街', lng: 116.398, lat: 39.899 },
  { name: '簋街', address: '东城区东直门内大街', lng: 116.416, lat: 39.937 },
  { name: '798艺术区', address: '朝阳区酒仙桥路4号', lng: 116.496, lat: 39.984 },
  { name: '宋家庄地铁站', address: '丰台区石榴庄路', lng: 116.428, lat: 39.857 },
  { name: '西红门荟聚', address: '大兴区欣宁街15号', lng: 116.321, lat: 39.785 },
  { name: '石景山万达', address: '石景山区石景山路乙18号', lng: 116.223, lat: 39.906 },
  { name: '常营天街', address: '朝阳区朝阳北路', lng: 116.585, lat: 39.923 },
]

/** 常用地址（一键选择） */
export const FAVORITE_PLACES: { label: string; place: Place }[] = [
  { label: '🏠 家', place: { name: '望京SOHO', address: '朝阳区望京街10号', lng: 116.4814, lat: 39.9961 } },
  { label: '💼 公司', place: { name: '国贸大厦', address: '朝阳区建国门外大街1号', lng: 116.459, lat: 39.9095 } },
  { label: '🎓 学校', place: { name: '五道口购物中心', address: '海淀区成府路28号', lng: 116.337, lat: 39.992 } },
  { label: '🛍️ 三里屯', place: { name: '三里屯太古里', address: '朝阳区三里屯路19号', lng: 116.4551, lat: 39.937 } },
  { label: '🛒 大悦城', place: { name: '朝阳大悦城', address: '朝阳区朝阳北路101号', lng: 116.5143, lat: 39.9243 } },
  { label: '🚉 北京南站', place: { name: '北京南站', address: '丰台区永外大街车站路12号', lng: 116.3786, lat: 39.8652 } },
  { label: '🔬 中关村', place: { name: '中关村地铁站', address: '海淀区中关村大街', lng: 116.3158, lat: 39.9842 } },
]

/** 关键词搜索（mock）：按名称 / 地址包含匹配 */
export function searchPlaces(keyword: string, limit = 6): Place[] {
  const kw = keyword.trim().toLowerCase()
  if (!kw) return []
  const hit = ADDRESS_DB.filter(
    (p) => p.name.toLowerCase().includes(kw) || p.address.toLowerCase().includes(kw),
  )
  return hit.slice(0, limit)
}

/** 构造一个新出发点 */
export function makePoint(place: Place, mode: TravelPoint['mode'], source: TravelPoint['source'], extra?: Partial<TravelPoint>): TravelPoint {
  return {
    id: Math.random().toString(36).slice(2, 10),
    name: place.name,
    address: place.address,
    lng: place.lng,
    lat: place.lat,
    mode,
    source,
    ...extra,
  }
}
