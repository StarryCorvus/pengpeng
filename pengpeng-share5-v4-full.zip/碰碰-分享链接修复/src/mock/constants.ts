import type { TravelMode } from '../types'

// ============================================================
// 常量与元信息
// ============================================================

/** 出行方式元信息（文案 + 图标 key） */
export const MODE_META: Record<TravelMode, { label: string; short: string; icon: 'bus' | 'car' | 'taxi' | 'bike' | 'walk' }> = {
  transit: { label: '公共交通', short: '地铁公交', icon: 'bus' },
  drive: { label: '驾车', short: '驾车', icon: 'car' },
  taxi: { label: '打车', short: '打车', icon: 'taxi' },
  bike: { label: '骑行', short: '骑行', icon: 'bike' },
  walk: { label: '步行', short: '步行', icon: 'walk' },
}

/** 出行方式选项顺序 */
export const MODE_ORDER: TravelMode[] = ['transit', 'drive', 'taxi', 'bike', 'walk']

/** 出发点位 marker 颜色（最多 6 个点） */
export const POINT_COLORS = ['#FF5D5D', '#4D8DFF', '#00B578', '#FF9F1C', '#9B5DE5', '#F15BB5']

/** 一级品类节点 */
export interface CategoryNode {
  key: string
  name: string
  children: string[]
}

/** 一级品类与二级细分清单（v1.0 二级单选） */
export const CATEGORY_TREE: CategoryNode[] = [
  { key: 'mall', name: '综合型购物中心', children: ['全部分类'] },
  {
    key: 'food',
    name: '美食餐厅',
    children: ['全部分类', '地方菜', '火锅', '烧烤烤肉', '自助餐', '东南亚菜', '日韩料理', '西餐', '海鲜河鲜', '快餐小吃'],
  },
  {
    key: 'drink',
    name: '奶茶咖啡',
    children: ['全部分类', '咖啡馆', '奶茶店', '冰激凌店', '茶馆', '烘焙面包店'],
  },
  {
    key: 'fun',
    name: '休闲娱乐',
    children: ['全部分类', '推理/桌游', '酒吧清吧', 'DIY手工坊', '健身房', '电影', '球类运动', '洗浴按摩', '武术搏击', 'KTV'],
  },
  {
    key: 'market',
    name: '超市购物',
    children: ['全部分类', '零食店', '生鲜店', '便利店', '大型超市'],
  },
]

/** 一级品类 key -> 展示名 */
export const CATEGORY_NAME: Record<string, string> = Object.fromEntries(
  CATEGORY_TREE.map((c) => [c.key, c.name]),
)

/** 通勤时间差筛选预设档位（分钟）。 */
export const TIME_DIFF_PRESETS = [10, 20, 30]
/** 默认时间差阈值（分钟） */
export const DEFAULT_TIME_DIFF = 20
/** 时间差自定义最小值（分钟） */
export const TIME_DIFF_MIN = 1
/** 时间差自定义最大值（分钟） */
export const TIME_DIFF_MAX = 180
/** 时间差档位展示文案 */
export function timeDiffLabel(v: number): string {
  return `${v} 分钟`
}

/** 店铺展示图配色（按一级品类） */
export const PRIMARY_STYLE: Record<string, { bg: [string, string]; emoji: string }> = {
  mall: { bg: ['#FF9A5A', '#FF6B35'], emoji: '🏬' },
  food: { bg: ['#FFA26B', '#FF7A2F'], emoji: '🍜' },
  drink: { bg: ['#8FD3C7', '#2BAE85'], emoji: '🥤' },
  fun: { bg: ['#9B8AFB', '#6C5CE7'], emoji: '🎮' },
  market: { bg: ['#F5B97B', '#E8933A'], emoji: '🛒' },
}

/** 二级品类 -> emoji（覆盖默认） */
export const SUB_EMOJI: Record<string, string> = {
  火锅: '🍲',
  烧烤烤肉: '🍢',
  自助餐: '🍽️',
  地方菜: '🥘',
  东南亚菜: '🍛',
  日韩料理: '🍣',
  西餐: '🥩',
  海鲜河鲜: '🦞',
  快餐小吃: '🍱',
  咖啡馆: '☕',
  奶茶店: '🧋',
  冰激凌店: '🍦',
  茶馆: '🍵',
  烘焙面包店: '🥐',
  '推理/桌游': '🧩',
  '酒吧清吧': '🍸',
  'DIY手工坊': '🎨',
  健身房: '💪',
  电影: '🎬',
  球类运动: '🏸',
  洗浴按摩: '🛁',
  武术搏击: '🥊',
  KTV: '🎤',
  零食店: '🍿',
  生鲜店: '🥬',
  便利店: '🏪',
  大型超市: '🏬',
}

/** 获取品类 emoji（二级优先，回退一级） */
export function categoryEmoji(primary: string, sub: string): string {
  return SUB_EMOJI[sub] || PRIMARY_STYLE[primary]?.emoji || '📍'
}
