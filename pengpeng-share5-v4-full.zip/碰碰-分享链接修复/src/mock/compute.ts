// ============================================================
// Mock 计算引擎：复用真实 API 路径的召回、地理粗排、Top N 全量通勤、
// 系统硬过滤、加权精排与多样性软重排，
// 仅把「百度 POI 检索」替换为 SHOP_DB，把「路线规划」替换为确定性本地估算。
// ============================================================

import type { FormState, GeoPoint, MockResult, Shop, ShopRecommendation, ShopWithCommute, TravelMode } from '../types'
import { distMeters } from './geo'
import { SHOP_DB } from './shops'
import {
  computeAllRoutes,
  diversityRerank,
  getRecallBranches,
  maxCommuteOf,
  mergeRecallGroups,
  passesHardFairness,
  rankByGeographicFit,
  rankEligibleShops,
  type PipelineProgress,
} from '../utils/resultPipeline'
import { SHOP_PIPELINE_CONFIG } from '../config'
import { isLeisureAll, mergeLeisureRecall, leisureShortlist, leisureTopTen,
  withinLeisureCommuteLimit, debugLeisureRecall, debugLeisureStage } from '../utils/leisureDiversity'

/** 各出行方式的 Mock 平均速度（km/h） */
const MODE_SPEED_KMH: Record<TravelMode, number> = { walk: 4.5, bike: 14, transit: 22, drive: 30, taxi: 32 }
/** 各出行方式的固定接驳耗时（分钟） */
const MODE_ACCESS_MIN: Record<TravelMode, number> = { walk: 0, bike: 0, transit: 8, drive: 6, taxi: 4 }

/** Mock 通勤时长：距离/速度 + 接驳 + 确定性抖动，同一组输入可稳定复现。 */
export function calcCommuteMinutes(from: GeoPoint, fromMode: TravelMode, shop: Shop, seed: number): number {
  const km = distMeters(from, shop) / 1000
  const base = (km / MODE_SPEED_KMH[fromMode]) * 60 + MODE_ACCESS_MIN[fromMode]
  const noise = ((seed * 7 + shop.name.length * 13 + shop.id.length) % 9) - 4
  return Math.max(6, Math.round(base + noise))
}

/** Mock 路费规则沿用原工程。 */
export function mockFare(mode: TravelMode, km: number): number {
  if (mode === 'transit') return Math.max(3, Math.round(3 + Math.max(0, km - 6) / 2))
  if (mode === 'taxi') return Math.round(13 + Math.max(0, km - 3) * 2.3)
  return 0
}

/** 现有 Mock 数据中的细分地方菜，统一归入 UI 的「地方菜」召回分支。 */
const LOCAL_CUISINE_SUBCATEGORIES = new Set(['地方菜', '川菜', '北京菜', '江浙菜', '云南菜'])

function matchesRecallBranch(shop: Shop, primary: string, subcategory: string): boolean {
  if (shop.primary !== primary) return false
  if (primary === 'mall') return true
  if (subcategory === '地方菜') return LOCAL_CUISINE_SUBCATEGORIES.has(shop.sub)
  return shop.sub === subcategory
}

/** 店铺是否命中当前 UI 选择（保留为可复用的基础判断）。 */
export function matchCategory(shop: Shop, category: FormState['category']): boolean {
  if (!category) return false
  if (category.primary === 'mall') return shop.primary === 'mall'
  if (!category.secondary || category.secondary === '全部分类') return shop.primary === category.primary
  return matchesRecallBranch(shop, category.primary, category.secondary)
}

/** 用本地数据模拟「子品类拆分检索 + 品类配额 + 不足补位」。 */
function recallMockCandidates(form: FormState): Shop[] {
  if (!form.category) return []
  const branches = getRecallBranches(form.category)
  const groups = branches.map((branch) => ({
    subcategory: branch.subcategory,
    items: SHOP_DB.filter((shop) =>
      matchesRecallBranch(shop, form.category!.primary, branch.subcategory),
    ),
  }))

  if (isLeisureAll(form.category)) {
    const recalled = mergeLeisureRecall(groups, shop => shop.uid || shop.id)
    debugLeisureRecall(groups, recalled, shop => shop.uid || shop.id)
    return recalled.map(({ item, subcategory, matchedSubcategoryKeys }) => ({ ...item, sub: subcategory, matchedSubcategoryKeys, logicalSubcategoryKey: subcategory }))
  }
  return mergeRecallGroups(groups, (shop) => shop.id).map(({ item, subcategory }) => ({
    ...item,
    // 与真实召回一致，sub 记录 UI 召回分支；category 仍保留 Mock 原始展示名。
    sub: subcategory,
  }))
}

async function calculateMockCommute(shop: Shop, form: FormState, shopIndex: number): Promise<ShopWithCommute> {
  const commutes = form.points.map((point, pointIndex) => ({
    pointId: point.id,
    pointName: point.name,
    mode: point.mode,
    minutes: calcCommuteMinutes(point, point.mode, shop, pointIndex + shopIndex * 3),
    fare: mockFare(point.mode, distMeters(point, shop) / 1000),
  }))
  const minutes = commutes.map((commute) => commute.minutes)
  const fairness = Math.max(...minutes) - Math.min(...minutes)
  const avg = minutes.reduce((sum, value) => sum + value, 0) / minutes.length
  return { ...shop, commutes, fairness, avg }
}

/** 推荐卡片沿用现有形态，但首选与最终列表的整体通勤排序保持一致。 */
export function pickRecommendation(shops: ShopWithCommute[]): ShopRecommendation | null {
  const best = shops[0]
  if (!best) return null
  return {
    shop: best,
    reason: `${best.name}平均通勤约 ${Math.round(best.avg)} 分钟，最远一方 ${maxCommuteOf(best)} 分钟，各方时间差 ${best.fairness} 分钟。`,
  }
}

/**
 * Mock 主入口。与真实模式共用同一套：地理粗排 -> Top N 全量通勤 ->
 * 系统硬过滤（时间差 > 60 淘汰）-> 加权精排 -> 多样性软重排；不固定输出数量。
 */
export async function computeMockResult(
  form: FormState,
  onProgress?: (p: PipelineProgress) => void,
  // Mock 不依赖搜索半径，仅为与真实接口保持一致而保留该参数。
  _radiusBonusKm = 0,
): Promise<MockResult> {
  if (!form.category || form.points.length < 2) {
    return { shops: [], recommendation: null, reason: 'no_shops' }
  }

  onProgress?.({ stage: 'recall', routed: 0, total: 0 })

  const candidates = recallMockCandidates(form)
  if (candidates.length === 0) {
    return { shops: [], recommendation: null, reason: 'no_shops' }
  }

  // 对全部召回候选做地理粗排，只取 Top N 进入通勤计算，且全部计算完，不提前停。
  const geographicallyRanked = rankByGeographicFit(candidates, form.points)
  const balanced = isLeisureAll(form.category)
  const routeCandidates = balanced ? leisureShortlist(geographicallyRanked)
    : geographicallyRanked.slice(0, SHOP_PIPELINE_CONFIG.routeComputeCount)
  if (balanced) debugLeisureStage('shortlist', routeCandidates)

  const computed = await computeAllRoutes(
    routeCandidates,
    (shop, index) => calculateMockCommute(shop, form, index),
    (done, total) => onProgress?.({ stage: 'routing', routed: done, total }),
  )

  // 系统硬过滤：时间差 > 60 分钟淘汰。
  const hardFiltered = computed.filter(s => passesHardFairness(s) && (!balanced || withinLeisureCommuteLimit(s)))
  if (balanced) debugLeisureStage('qualified', hardFiltered)
  if (hardFiltered.length === 0) {
    return { shops: [], recommendation: null, reason: 'no_shops' }
  }

  const qualityRanked = rankEligibleShops(hardFiltered)
  onProgress?.({ stage: 'finishing', routed: routeCandidates.length, total: routeCandidates.length })

  const isAllCategory =
    form.category.primary !== 'mall' &&
    (!form.category.secondary || form.category.secondary === '全部分类')
  const diversified = diversityRerank(qualityRanked, isAllCategory)
  const finalShops = balanced ? leisureTopTen(diversified) : diversified
  if (balanced) debugLeisureStage('final Top10', finalShops.slice(0, 10))

  return {
    shops: finalShops,
    recommendation: pickRecommendation(finalShops),
    reason: 'ok',
  }
}
