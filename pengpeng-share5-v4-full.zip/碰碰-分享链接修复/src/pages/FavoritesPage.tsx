// ============================================================
// 收藏店铺列表页：
// - 顶部：返回按钮 + 标题
// - 搜索框：按店铺名称搜索
// - 品类筛选栏：按一级品类筛选（复用 CATEGORY_TREE）
// - 店铺列表：展示收藏的店铺，可取消收藏
// ============================================================

import { useEffect, useMemo, useState } from 'react'
import type { FavShop } from '../utils/storage'
import { loadFavShops, toggleFavShop } from '../utils/storage'
import { CATEGORY_TREE } from '../mock/constants'
import { fmtPrice, fmtRating } from '../utils/format'
import { IconBack, IconHeart, IconSearch, IconStar, IconTrash } from '../components/common/Icons'
import { ShopImage } from '../components/result/ShopImage'
import { useToast } from '../components/common/Toast'

export function FavoritesPage({
  onBack,
}: {
  onBack: () => void
}) {
  const { show } = useToast()
  const [favs, setFavs] = useState<FavShop[]>([])
  const [keyword, setKeyword] = useState('')
  const [activeCategory, setActiveCategory] = useState<string>('all') // 'all' | primary key

  useEffect(() => {
    setFavs(loadFavShops())
  }, [])

  // 筛选：关键词 + 品类
  const filtered = useMemo(() => {
    return favs.filter((s) => {
      const matchKw = !keyword.trim() || s.name.toLowerCase().includes(keyword.trim().toLowerCase())
      const matchCat = activeCategory === 'all' || s.primary === activeCategory
      return matchKw && matchCat
    })
  }, [favs, keyword, activeCategory])

  const removeFav = (shop: FavShop) => {
    toggleFavShop(shop)
    setFavs(loadFavShops())
    show(`已取消收藏「${shop.name}」`, 'info')
  }

  return (
    <div className="page favorites-page">
      {/* 顶部导航栏 */}
      <div className="favorites-header">
        <button type="button" className="favorites-back" onClick={onBack} aria-label="返回">
          <IconBack size={18} />
        </button>
        <h1 className="favorites-title">我的收藏</h1>
        <span className="favorites-count">{favs.length} 家</span>
      </div>

      {/* 搜索框 */}
      <div className="favorites-search-wrap">
        <div className="favorites-search-input">
          <IconSearch size={16} className="favorites-search-icon" />
          <input
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            placeholder="搜索收藏的店铺"
            className="favorites-search-field"
          />
          {keyword && (
            <button type="button" className="favorites-search-clear" onClick={() => setKeyword('')} aria-label="清空">
              ×
            </button>
          )}
        </div>
      </div>

      {/* 品类筛选栏 */}
      <div className="favorites-category-bar">
        <button
          type="button"
          className={`favorites-cat-chip ${activeCategory === 'all' ? 'active' : ''}`}
          onClick={() => setActiveCategory('all')}
        >
          全部
        </button>
        {CATEGORY_TREE.map((cat) => (
          <button
            type="button"
            key={cat.key}
            className={`favorites-cat-chip ${activeCategory === cat.key ? 'active' : ''}`}
            onClick={() => setActiveCategory(cat.key)}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* 店铺列表 */}
      <div className="favorites-list">
        {filtered.length === 0 ? (
          <div className="favorites-empty">
            <div className="favorites-empty-icon">
              <IconHeart size={40} />
            </div>
            <p>{favs.length === 0 ? '还没有收藏的店铺' : '没有符合条件的店铺'}</p>
            <span>{favs.length === 0 ? '在店铺详情页点击 ❤️ 即可收藏' : '换个关键词或品类试试'}</span>
          </div>
        ) : (
          filtered.map((shop) => (
            <div key={shop.id} className="favorites-card">
              <ShopImage primary={shop.primary} sub={shop.sub} size="sm" />
              <div className="favorites-card-info">
                <b className="favorites-card-name">{shop.name}</b>
                <div className="favorites-card-meta">
                  <span className="rating">
                    <IconStar size={12} className="star" />
                    {fmtRating(shop.rating)}
                  </span>
                  <span>人均{fmtPrice(shop.perCapita)}</span>
                  <span>{shop.category}</span>
                </div>
                <span className="favorites-card-area">{shop.area}</span>
              </div>
              <button
                type="button"
                className="favorites-card-remove"
                aria-label="取消收藏"
                onClick={() => removeFav(shop)}
              >
                <IconTrash size={16} />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
