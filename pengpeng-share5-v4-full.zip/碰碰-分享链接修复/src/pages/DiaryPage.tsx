// ============================================================
// 碰碰日记页面：
// - 日记簿风格 UI，画布可拖拽平移，便签可自由拖拽
// - 可新增/编辑/删除日记：碰友、时间（日历选择）、地点、札记
// - 数据持久化到 localStorage，便签位置也持久化
// - 拖拽用 document 级事件监听，确保移动端可用
// ============================================================

import { useEffect, useRef, useState } from 'react'
import type { DiaryEntry } from '../utils/storage'
import { addDiaryEntry, deleteDiaryEntry, loadDiaryEntries, updateDiaryEntry } from '../utils/storage'
import { IconBack, IconPlus, IconTrash, IconEdit } from '../components/common/Icons'
import { useToast } from '../components/common/Toast'
import { Modal } from '../components/common/Modal'

/** 格式化时间戳为可读日期 */
function formatDate(ts: number): string {
  const d = new Date(ts)
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}.${m}.${day}`
}

/** 空日记表单 */
const emptyForm = { who: '', time: '', place: '', what: '' }

/** 便签颜色池（循环使用） */
const NOTE_COLORS = [
  { bg: '#fff9ee', border: '#d9c8ac', tape: '#c7ad86' },
  { bg: '#eef0e5', border: '#bbc3aa', tape: '#a3ad90' },
  { bg: '#eaf0ed', border: '#b5c4bd', tape: '#91a79c' },
  { bg: '#f4e9dc', border: '#cbb59d', tape: '#b79a7c' },
  { bg: '#eee9e1', border: '#c4b9aa', tape: '#ae9e88' },
  { bg: '#f3edda', border: '#cdc098', tape: '#bcaa7a' },
]

/** 根据标签 id 获取固定颜色 */
function getNoteColorById(id: string) {
  let hash = 0
  for (let i = 0; i < id.length; i++) {
    hash = ((hash << 5) - hash + id.charCodeAt(i)) | 0
  }
  return NOTE_COLORS[Math.abs(hash) % NOTE_COLORS.length]
}

export function DiaryPage({ onBack }: { onBack: () => void }) {
  const { show } = useToast()
  const [entries, setEntries] = useState<DiaryEntry[]>([])
  const [editing, setEditing] = useState<DiaryEntry | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [pendingDelete, setPendingDelete] = useState<string | null>(null)

  // 画布平移状态
  const [canvasOffset, setCanvasOffset] = useState({ x: 0, y: 0 })
  const canvasRef = useRef<HTMLDivElement>(null)

  // 拖拽状态（用 ref 避免 re-render）
  const dragState = useRef<{
    type: 'note' | 'canvas' | null
    noteId: string | null
    startX: number
    startY: number
    offsetX: number
    offsetY: number
    canvasStartX: number
    canvasStartY: number
  }>({
    type: null,
    noteId: null,
    startX: 0,
    startY: 0,
    offsetX: 0,
    offsetY: 0,
    canvasStartX: 0,
    canvasStartY: 0,
  })

  const [draggingNoteId, setDraggingNoteId] = useState<string | null>(null)
  const [isPanning, setIsPanning] = useState(false)

  useEffect(() => {
    setEntries(loadDiaryEntries())
  }, [])

  // document 级别的 pointermove 和 pointerup 监听（确保移动端拖拽可用）
  useEffect(() => {
    const handlePointerMove = (e: PointerEvent) => {
      const ds = dragState.current
      if (!ds.type) return

      if (ds.type === 'note' && ds.noteId) {
        // 便签拖拽
        const canvasRect = canvasRef.current?.getBoundingClientRect()
        if (!canvasRect) return
        const x = e.clientX - canvasRect.left - ds.offsetX - canvasOffset.x
        const y = e.clientY - canvasRect.top - ds.offsetY - canvasOffset.y
        setEntries((prev) =>
          prev.map((en) => (en.id === ds.noteId ? { ...en, x, y } : en)),
        )
      } else if (ds.type === 'canvas') {
        // 画布平移
        const dx = e.clientX - ds.startX
        const dy = e.clientY - ds.startY
        setCanvasOffset({
          x: ds.canvasStartX + dx,
          y: ds.canvasStartY + dy,
        })
      }
    }

    const handlePointerUp = () => {
      const ds = dragState.current
      if (!ds.type) return

      if (ds.type === 'note' && ds.noteId) {
        // 保存便签位置
        const noteId = ds.noteId
        setEntries((prev) => {
          const updated = prev.find((en) => en.id === noteId)
          if (updated && updated.x != null && updated.y != null) {
            updateDiaryEntry(noteId, { x: updated.x, y: updated.y })
          }
          return prev
        })
      }

      // 重置拖拽状态
      dragState.current = {
        type: null,
        noteId: null,
        startX: 0,
        startY: 0,
        offsetX: 0,
        offsetY: 0,
        canvasStartX: 0,
        canvasStartY: 0,
      }
      setDraggingNoteId(null)
      setIsPanning(false)
    }

    document.addEventListener('pointermove', handlePointerMove)
    document.addEventListener('pointerup', handlePointerUp)
    document.addEventListener('pointercancel', handlePointerUp)

    return () => {
      document.removeEventListener('pointermove', handlePointerMove)
      document.removeEventListener('pointerup', handlePointerUp)
      document.removeEventListener('pointercancel', handlePointerUp)
    }
  }, [canvasOffset])

  /** 打开新增表单 */
  const openNew = () => {
    setForm(emptyForm)
    setEditing(null)
    setShowForm(true)
  }

  /** 打开编辑表单 */
  const openEdit = (entry: DiaryEntry) => {
    setForm({ who: entry.who, time: entry.time, place: entry.place, what: entry.what })
    setEditing(entry)
    setShowForm(true)
  }

  /** 保存日记 */
  const handleSave = () => {
    if (!form.who.trim() && !form.place.trim() && !form.what.trim()) {
      show('至少填写一项内容', 'warn')
      return
    }
    const data = {
      who: form.who.trim(),
      time: form.time.trim(),
      place: form.place.trim(),
      what: form.what.trim(),
    }
    if (editing) {
      updateDiaryEntry(editing.id, data)
      show('日记已更新', 'success')
    } else {
      addDiaryEntry(data)
      show('日记已保存', 'success')
    }
    setEntries(loadDiaryEntries())
    setShowForm(false)
    setEditing(null)
  }

  /** 删除日记：先弹确认，确认后才真正删除 */
  const handleDelete = (id: string) => {
    if (!id) return
    setPendingDelete(id)
  }
  const confirmDelete = () => {
    if (!pendingDelete) return
    deleteDiaryEntry(pendingDelete)
    setEntries(loadDiaryEntries())
    show('日记已删除', 'info')
    setShowForm(false)
    setEditing(null)
    setPendingDelete(null)
  }

  /** 便签 pointerdown */
  const handleNotePointerDown = (e: React.PointerEvent, entry: DiaryEntry) => {
    e.stopPropagation()
    e.preventDefault()
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect()
    dragState.current = {
      type: 'note',
      noteId: entry.id,
      startX: e.clientX,
      startY: e.clientY,
      offsetX: e.clientX - rect.left,
      offsetY: e.clientY - rect.top,
      canvasStartX: 0,
      canvasStartY: 0,
    }
    setDraggingNoteId(entry.id)
  }

  /** 画布 pointerdown（平移） */
  const handleCanvasPointerDown = (e: React.PointerEvent) => {
    // 只有点在画布空白处才触发平移
    const target = e.target as HTMLElement
    if (!target.classList.contains('diary-canvas') && !target.classList.contains('diary-notes-wrapper')) {
      return
    }
    e.preventDefault()
    dragState.current = {
      type: 'canvas',
      noteId: null,
      startX: e.clientX,
      startY: e.clientY,
      offsetX: 0,
      offsetY: 0,
      canvasStartX: canvasOffset.x,
      canvasStartY: canvasOffset.y,
    }
    setIsPanning(true)
  }

  /** 重置画布位置 */
  const resetCanvas = () => {
    setCanvasOffset({ x: 0, y: 0 })
  }

  return (
    <div className="page diary-page">
      {/* 顶部导航 */}
      <header className="diary-header">
        <button type="button" className="diary-back-btn" onClick={onBack} aria-label="返回">
          <IconBack size={20} />
        </button>
        <h1 className="diary-title">碰碰日记</h1>
        <button type="button" className="diary-add-btn" onClick={openNew} aria-label="新增日记">
          <IconPlus size={20} />
        </button>
      </header>

      {/* 画布平移提示 */}
      {(canvasOffset.x !== 0 || canvasOffset.y !== 0) && (
        <button
          type="button"
          className="diary-reset-btn"
          onClick={resetCanvas}
          aria-label="重置视图"
        >
          ⌂ 重置视图
        </button>
      )}

      {/* 日记画布（可拖拽平移，便签可拖拽） */}
      <div
        className={`diary-canvas ${isPanning ? 'panning' : ''}`}
        ref={canvasRef}
        onPointerDown={handleCanvasPointerDown}
      >
        {/* 便签容器，应用画布平移偏移 */}
        <div
          className="diary-notes-wrapper"
          style={{
            transform: `translate(${canvasOffset.x}px, ${canvasOffset.y}px)`,
          }}
        >
          {entries.length === 0 ? (
            <div className="diary-empty">
              <div className="diary-empty-icon">📖</div>
              <p className="diary-empty-text">还没有日记记录</p>
              <p className="diary-empty-hint">点击右上角 + 记录第一次碰碰吧</p>
              <p className="diary-empty-hint">便签可以自由拖拽，画布可以平移哦 ✨</p>
            </div>
          ) : (
            entries.map((entry, idx) => {
              const color = getNoteColorById(entry.id)
              const isDragging = draggingNoteId === entry.id
              // 默认位置：瀑布流排列
              const defaultX = (idx % 2) * 155 + 10
              const defaultY = Math.floor(idx / 2) * 210 + 16
              const x = entry.x ?? defaultX
              const y = entry.y ?? defaultY
              // 最新添加的标签图层更高
              const noteZIndex = isDragging ? 1000 : 10 + Math.floor(entry.createdAt / 1000) % 10000
              return (
                <div
                  key={entry.id}
                  className={`diary-note ${isDragging ? 'dragging' : ''}`}
                  style={{
                    left: x,
                    top: y,
                    '--note-paper': color.bg,
                    '--note-edge': color.border,
                    '--tape-color': color.tape,
                    zIndex: noteZIndex,
                  } as React.CSSProperties}
                  onPointerDown={(e) => handleNotePointerDown(e, entry)}
                >
                  <div className="note-tape" />
                  <div className="note-date">{formatDate(entry.createdAt)}</div>
                  <div className="note-content">
                    {entry.who && (
                      <div className="note-field">
                        <span className="note-field-label">👥 碰友</span>
                        <span className="note-field-value">{entry.who}</span>
                      </div>
                    )}
                    {entry.time && (
                      <div className="note-field">
                        <span className="note-field-label">⏰ 时间</span>
                        <span className="note-field-value">{entry.time}</span>
                      </div>
                    )}
                    {entry.place && (
                      <div className="note-field">
                        <span className="note-field-label">📍 地点</span>
                        <span className="note-field-value">{entry.place}</span>
                      </div>
                    )}
                    {entry.what && (
                      <div className="note-field">
                        <span className="note-field-label">✏️ 札记</span>
                        <span className="note-field-value note-what">{entry.what}</span>
                      </div>
                    )}
                  </div>
                  <div className="note-actions">
                    <button
                      type="button"
                      className="note-action-btn"
                      onPointerDown={(e) => e.stopPropagation()}
                      onClick={(e) => { e.stopPropagation(); openEdit(entry); }}
                      aria-label="编辑"
                    >
                      <IconEdit size={13} />
                    </button>
                    <button
                      type="button"
                      className="note-action-btn delete"
                      onPointerDown={(e) => e.stopPropagation()}
                      onClick={(e) => { e.stopPropagation(); handleDelete(entry.id); }}
                      aria-label="删除"
                    >
                      <IconTrash size={13} />
                    </button>
                  </div>
                </div>
              )
            })
          )}
        </div>
      </div>

      {/* 编辑/新增弹窗 */}
      {showForm && (
        <div className="diary-form-overlay" onClick={() => setShowForm(false)}>
          <div className="diary-form-sheet" onClick={(e) => e.stopPropagation()}>
            <div className="diary-form-header">
              <h2>{editing ? '编辑日记' : '新增日记'}</h2>
              <button type="button" className="diary-form-close" onClick={() => setShowForm(false)}>
                ✕
              </button>
            </div>
            <div className="diary-form-body">
              <div className="diary-form-field">
                <label>👥 碰友</label>
                <input
                  type="text"
                  placeholder="比如：小明、小红"
                  value={form.who}
                  onChange={(e) => setForm({ ...form, who: e.target.value })}
                  maxLength={50}
                />
              </div>
              <div className="diary-form-field">
                <label>⏰ 时间</label>
                <div className="diary-time-inputs">
                  <input
                    type="date"
                    value={form.time.match(/^\d{4}-\d{2}-\d{2}/)?.[0] || ''}
                    onChange={(e) => {
                      const dateStr = e.target.value
                      const timePart = form.time.match(/\d{4}-\d{2}-\d{2}(.*)/)?.[1] || ''
                      setForm({ ...form, time: dateStr + timePart })
                    }}
                  />
                  <input
                    type="text"
                    placeholder="补充：晚上7点"
                    value={form.time.replace(/^\d{4}-\d{2}-\d{2}/, '')}
                    onChange={(e) => {
                      const datePart = form.time.match(/^\d{4}-\d{2}-\d{2}/)?.[0] || ''
                      setForm({ ...form, time: datePart + e.target.value })
                    }}
                    maxLength={30}
                  />
                </div>
              </div>
              <div className="diary-form-field">
                <label>📍 地点</label>
                <input
                  type="text"
                  placeholder="比如：国贸·胡大饭馆"
                  value={form.place}
                  onChange={(e) => setForm({ ...form, place: e.target.value })}
                  maxLength={80}
                />
              </div>
              <div className="diary-form-field">
                <label>✏️ 札记</label>
                <textarea
                  placeholder="记录这次碰碰的精彩瞬间..."
                  value={form.what}
                  onChange={(e) => setForm({ ...form, what: e.target.value })}
                  rows={4}
                  maxLength={500}
                />
              </div>
            </div>
            <div className="diary-form-footer">
              {editing && (
                <button type="button" className="diary-form-btn delete" onClick={() => handleDelete(editing.id)}>
                  删除
                </button>
              )}
              <button type="button" className="diary-form-btn primary" onClick={handleSave}>
                保存
              </button>
            </div>
          </div>
        </div>
      )}
      <Modal open={!!pendingDelete} onClose={() => setPendingDelete(null)} className="diary-delete-modal">
        <div className="diary-confirm">
          <h2>要删掉这张碰碰日记吗？</h2>
          <p>删除后就找不回来了</p>
          <div className="diary-confirm-actions">
            <button type="button" className="diary-form-btn" onClick={() => setPendingDelete(null)}>取消</button>
            <button type="button" className="diary-form-btn delete" onClick={confirmDelete}>删除</button>
          </div>
        </div>
      </Modal>
    </div>
  )
}
