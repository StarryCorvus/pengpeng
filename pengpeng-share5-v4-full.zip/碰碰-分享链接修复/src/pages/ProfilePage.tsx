// ============================================================
// 「我的」页面（精简版）：
// - 用户信息（头像/昵称可编辑，会员徽章与昵称同行）
// - 功能入口：收藏店铺（图标）、碰碰日记（图标）
// - 更多入口
// - 用户资料持久化到 localStorage（切 tab 不丢失）
// ============================================================

import { useEffect, useRef, useState } from 'react'
import type { UserProfile } from '../utils/storage'
import { loadUserProfile, saveUserProfile } from '../utils/storage'
import { IconChevronRight, IconEdit, IconUpload, IconHeart, IconBook } from '../components/common/Icons'
import { useToast } from '../components/common/Toast'
import { BottomSheet } from '../components/common/BottomSheet'

/** 预设头像选项（颜色 + 文字） */
const AVATAR_OPTIONS = [
  { bg: '#765033', text: '碰' },
  { bg: 'linear-gradient(135deg, #4D8DFF, #2B6FE0)', text: '😊' },
  { bg: 'linear-gradient(135deg, #00B578, #009966)', text: '🌟' },
  { bg: 'linear-gradient(135deg, #9B5DE5, #7B3FD1)', text: '🎯' },
  { bg: 'linear-gradient(135deg, #F15BB5, #D13B95)', text: '🍜' },
  { bg: 'linear-gradient(135deg, #FF9F1C, #E07F00)', text: '☕' },
]

/** 模拟账号 ID（首次生成后固定） */
const ACCOUNT_ID = 'PP_' + Math.random().toString(36).slice(2, 10).toUpperCase()

export function ProfilePage({
  onOpenFavorites,
  onOpenDiary,
}: {
  /** 点击收藏店铺 → 跳转收藏列表页 */
  onOpenFavorites: () => void
  /** 点击碰碰日记 → 跳转日记页面 */
  onOpenDiary: () => void
}) {
  const { show } = useToast()
  // 用户资料从 localStorage 读取，修改后立即保存
  const [profile, setProfile] = useState<UserProfile>(() => loadUserProfile())
  const [editingName, setEditingName] = useState(false)
  const [showAvatarSheet, setShowAvatarSheet] = useState(false)
  const nameInputRef = useRef<HTMLInputElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // 进入编辑昵称模式时自动聚焦
  useEffect(() => {
    if (editingName && nameInputRef.current) {
      nameInputRef.current.focus()
      nameInputRef.current.select()
    }
  }, [editingName])

  /** 更新用户资料并持久化 */
  const updateProfile = (patch: Partial<UserProfile>) => {
    setProfile((prev) => {
      const next = { ...prev, ...patch }
      saveUserProfile(next)
      return next
    })
  }

  const saveNickname = () => {
    const trimmed = profile.nickname.trim()
    if (trimmed) {
      updateProfile({ nickname: trimmed })
      show('昵称已更新', 'success')
    } else {
      updateProfile({ nickname: '碰碰用户' })
    }
    setEditingName(false)
  }

  /** 选择预设头像 */
  const selectPresetAvatar = (idx: number) => {
    updateProfile({ avatarIndex: idx, customAvatar: null })
    setShowAvatarSheet(false)
    show('头像已更换', 'success')
  }

  /** 处理上传图片：读取为 base64，压缩后保存 */
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) {
      show('请选择图片文件', 'warn')
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      const dataUrl = reader.result as string
      // 用 canvas 压缩到 200x200，避免 localStorage 超限
      const img = new Image()
      img.onload = () => {
        const canvas = document.createElement('canvas')
        const size = 200
        canvas.width = size
        canvas.height = size
        const ctx = canvas.getContext('2d')
        if (!ctx) {
          updateProfile({ avatarIndex: -1, customAvatar: dataUrl })
          setShowAvatarSheet(false)
          show('头像已上传', 'success')
          return
        }
        // 居中裁剪
        const minDim = Math.min(img.width, img.height)
        const sx = (img.width - minDim) / 2
        const sy = (img.height - minDim) / 2
        ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, size, size)
        const compressed = canvas.toDataURL('image/jpeg', 0.85)
        updateProfile({ avatarIndex: -1, customAvatar: compressed })
        setShowAvatarSheet(false)
        show('头像已上传', 'success')
      }
      img.onerror = () => show('图片读取失败', 'warn')
      img.src = dataUrl
    }
    reader.onerror = () => show('文件读取失败', 'warn')
    reader.readAsDataURL(file)
    // 重置 input，允许重复选择同一文件
    e.target.value = ''
  }

  // 渲染头像（自定义上传 or 预设）
  const renderAvatar = (size: 'lg' | 'sm' = 'lg') => {
    const sizeClass = size === 'lg' ? 'profile-avatar-v2' : 'avatar-picker-preview'
    if (profile.avatarIndex === -1 && profile.customAvatar) {
      return <div className={`${sizeClass} profile-avatar-custom`} style={{ backgroundImage: `url(${profile.customAvatar})` }} />
    }
    const opt = AVATAR_OPTIONS[profile.avatarIndex % AVATAR_OPTIONS.length]
    return (
      <div className={sizeClass} style={{ background: opt.bg }}>
        {opt.text}
      </div>
    )
  }

  return (
    <div className="page profile-page">
      {/* 用户信息头部（头像/昵称可编辑，会员徽章与昵称同行） */}
      <div className="profile-header-v2">
        {/* 可点击头像 → 弹出头像选择弹窗 */}
        <button
          type="button"
          className="profile-avatar-btn"
          onClick={() => setShowAvatarSheet(true)}
          aria-label="更换头像"
        >
          {renderAvatar('lg')}
          <span className="profile-avatar-edit-badge">
            <IconEdit size={10} />
          </span>
        </button>

        <div className="profile-user-info-v2">
          {/* 昵称 + 会员徽章同行 */}
          <div className="profile-name-row">
            {editingName ? (
              <input
                ref={nameInputRef}
                className="profile-nickname-input"
                value={profile.nickname}
                onChange={(e) => setProfile((p) => ({ ...p, nickname: e.target.value }))}
                onBlur={saveNickname}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') saveNickname()
                  if (e.key === 'Escape') {
                    setProfile((p) => ({ ...p, nickname: loadUserProfile().nickname }))
                    setEditingName(false)
                  }
                }}
                maxLength={12}
              />
            ) : (
              <button
                type="button"
                className="profile-nickname-edit-btn"
                onClick={() => setEditingName(true)}
              >
                <b className="profile-nickname-v2">{profile.nickname}</b>
                <IconEdit size={12} className="profile-nickname-edit-icon" />
              </button>
            )}
            <span className="profile-badge-inline">碰碰会员</span>
          </div>
          <span className="profile-account-id-v2">ID：{ACCOUNT_ID}</span>
        </div>
      </div>

      {/* 功能入口（图标 + 文字，无数字统计） */}
      <div className="profile-stats-v2">
        <button type="button" className="profile-stat-item-v2 clickable" onClick={onOpenFavorites}>
          <span className="profile-stat-icon"><IconHeart size={22} /></span>
          <span className="profile-stat-label">收藏店铺<IconChevronRight size={12} className="stat-arrow" /></span>
        </button>
        <div className="profile-stat-divider-v2" />
        <button type="button" className="profile-stat-item-v2 clickable" onClick={onOpenDiary}>
          <span className="profile-stat-icon"><IconBook size={22} /></span>
          <span className="profile-stat-label">碰碰日记<IconChevronRight size={12} className="stat-arrow" /></span>
        </button>
      </div>

      {/* 其他功能入口 */}
      <section className="profile-section">
        <div className="profile-section-head">
          <h3>更多</h3>
        </div>
        <div className="profile-menu-list">
          {[
            { label: '关于碰碰', desc: '版本 v1.0 · 轻松碰面助手', icon: '💡' },
            { label: '使用帮助', desc: '常见问题与使用指南', icon: '❓' },
            { label: '意见反馈', desc: '告诉我们你的想法', icon: '✉️' },
            { label: '隐私政策', desc: '我们如何保护你的数据', icon: '🔒' },
          ].map((item) => (
            <button
              type="button"
              key={item.label}
              className="profile-menu-item"
              onClick={() => show(`「${item.label}」原型阶段暂未开放`, 'info')}
            >
              <span className="profile-menu-icon">{item.icon}</span>
              <span className="profile-menu-text">
                <b>{item.label}</b>
                <em>{item.desc}</em>
              </span>
              <IconChevronRight size={16} className="profile-menu-arrow" />
            </button>
          ))}
        </div>
      </section>

      <div className="profile-footer">碰碰 · 想见，那就轻松碰一面</div>

      {/* 头像选择弹窗（上传 + 推荐头像） */}
      <BottomSheet
        open={showAvatarSheet}
        onClose={() => setShowAvatarSheet(false)}
        title="更换头像"
      >
        <div className="avatar-sheet-content">
          {/* 当前头像预览 */}
          <div className="avatar-sheet-current">
            {renderAvatar('sm')}
            <span className="avatar-sheet-current-label">当前头像</span>
          </div>

          {/* 上传图片 */}
          <button
            type="button"
            className="avatar-upload-btn"
            onClick={() => fileInputRef.current?.click()}
          >
            <IconUpload size={18} />
            <span>从相册上传</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleFileUpload}
          />

          {/* 推荐头像 */}
          <p className="avatar-sheet-section-title">推荐头像</p>
          <div className="avatar-picker-grid">
            {AVATAR_OPTIONS.map((opt, idx) => (
              <button
                type="button"
                key={idx}
                className={`avatar-picker-item ${profile.avatarIndex === idx ? 'active' : ''}`}
                style={{ background: opt.bg }}
                onClick={() => selectPresetAvatar(idx)}
              >
                {opt.text}
              </button>
            ))}
          </div>
        </div>
      </BottomSheet>
    </div>
  )
}
