import { decodeSharedProposal } from '../utils/sharedProposal'
import { ShopDetailContent } from '../components/result/ShopDetailContent'

/** Public read-only snapshot; never mounts Result, searches, or geolocation. */
export function ShareProposalPage() {
  const payload = window.location.hash.slice('#/share/'.length)
  const proposal = decodeSharedProposal(payload)
  if (!proposal) return <main className="proposal-page proposal-invalid">
    <p>这份会面提案链接无效或不完整。</p>
  </main>

  return <main className="proposal-page">
    <article className="proposal-detail detail-modal">
      <ShopDetailContent proposal={proposal} snapshot/>
    </article>
  </main>
}
