import { MAP_VISUAL_STYLE, type MapVisualMode } from '../config/brandVisual'
import { PaperMapFrame } from '../components/brand/PaperMapFrame'
// ============================================================
// 页面 2：地图结果页（P0）
// - 顶部固定需求摘要栏，点击任意参数唤起修改弹窗，改完自动重算
// - 地图 / 列表双视图切换：地图默认展示最终排序前 10 家，列表展示全部
// - 列表提供两个纯前端筛选：平均通勤时长、通勤时间差（不触发召回/路线重算，保留原精排相对顺序）
// - 搜索加载：进度条 + 阶段性文案，不再展示「X / 20 家」
// ============================================================

import { useEffect, useState } from 'react'
import type { FormState, MockResult, ResultView, ShopWithCommute } from '../types'
import { POINT_COLORS, TIME_DIFF_PRESETS } from '../mock/constants'
import { computeMockResult } from '../mock/compute'
import { computeRealResult } from '../services/compute'
import { USE_REAL_API } from '../config'
import type { PipelineProgress } from '../utils/resultPipeline'
import { loadFavShops, toggleFavShop } from '../utils/storage'
import { navigateToShop } from '../utils/navigate'
import { LoadingOverlay } from '../components/common/LoadingOverlay'
import { EmptyState } from '../components/common/EmptyState'
import { useToast } from '../components/common/Toast'
import { FilterSegmentedControl } from '../components/result/FilterSegmentedControl'
import { ResultSummaryBar } from '../components/result/ResultSummaryBar'
import { ParamEditSheet } from '../components/result/ParamEditSheet'
import { QuickSheet, type QuickScope } from '../components/result/QuickSheet'
import { BaiduMap } from '../components/result/BaiduMap'
import { MockMap } from '../components/result/MockMap'
import { ShopCard } from '../components/result/ShopCard'
import { ShopDetailModal } from '../components/result/ShopDetailModal'
import { ShopPreviewSheet } from '../components/result/ShopPreviewSheet'
import { ShareCardModal } from '../components/result/ShareCardModal'
import type { SharedProposal } from '../utils/sharedProposal'
import { IconListView, IconLocate, IconMapView, IconRefresh } from '../components/common/Icons'

/** 根据配置选择地图组件 */
const MapComponent = USE_REAL_API ? BaiduMap : MockMap

/** 加载阶段文案：前端统一展示这句话 */
function stageText(_p: PipelineProgress | null): string {
  return '正在努力为你寻找合适的碰碰地点'
}

/** 加载进度条完成度（0~1），阶段之间平滑推进 */
function stageProgress(p: PipelineProgress | null): number {
  if (!p) return 0.08
  switch (p.stage) {
    case 'recall':
      return 0.14
    case 'routing':
      return p.total > 0 ? 0.2 + 0.74 * Math.min(1, p.routed / p.total) : 0.2
    case 'finishing':
      return 0.96
    default:
      return 0.5
  }
}

export function ResultPage({
  form,
  onChange,
  onBack,
}: {
  form: FormState
  onChange: (f: FormState) => void
  onBack: () => void
}) {
  const { show } = useToast()
  // 结果页视图：每次检索默认地图视图（不持久化）
  const [view, setView] = useState<ResultView>('map')
  const [mapVisualMode, setMapVisualMode] = useState<MapVisualMode>(MAP_VISUAL_STYLE)
  const [computing, setComputing] = useState(true)
  const [result, setResult] = useState<MockResult | null>(null)
  /** 管线阶段 + 路线计算完成进度（用于进度条 + 阶段文案） */
  const [progress, setProgress] = useState<PipelineProgress | null>(null)
  const [resetKey, setResetKey] = useState(0)
  const [sheetOpen, setSheetOpen] = useState(false)
  /** 顶栏参数 chip 的局部快捷修改弹窗（只展示该模块选项） */
  const [quick, setQuick] = useState<{ scope: QuickScope; index: number } | null>(null)
  const [detailShop, setDetailShop] = useState<ShopWithCommute | null>(null)
  /** 地图图钉点击后底部弹出的店铺预览卡片 */
  const [previewShop, setPreviewShop] = useState<ShopWithCommute | null>(null)
  const [shareOpen, setShareOpen] = useState(false)
  const [shareProposal, setShareProposal] = useState<SharedProposal | null>(null)
  /** 收藏状态（从 localStorage 初始化，持久化存储） */
  const [collected, setCollected] = useState<Record<string, boolean>>(() => {
    const favs = loadFavShops()
    return Object.fromEntries(favs.map((s) => [s.id, true]))
  })
  /** 纯前端筛选：平均通勤时长（null = 不筛选，数字 = 平均通勤 <= 该值） */
  const [avgFilter, setAvgFilter] = useState<number | null>(null)
  /** 纯前端筛选：通勤时间差（null = 不筛选；默认带入表单里的时间差） */
  const [fairnessFilter, setFairnessFilter] = useState<number | null>(null)
  /** 空结果时用户主动扩大的搜索半径（km），每次点「搜索更广范围」+2 */
  const [radiusBonus, setRadiusBonus] = useState(0)
  /** 平均通勤自定义输入 */
  const [avgCustomOpen, setAvgCustomOpen] = useState(false)
  const [avgCustomDraft, setAvgCustomDraft] = useState('')
  /** 时间差自定义输入 */
  const [fairnessCustomOpen, setFairnessCustomOpen] = useState(false)
  const [fairnessCustomDraft, setFairnessCustomDraft] = useState('')

  // 进入页面 / 参数修改后，计算结果（真实 API 或 Mock，由 USE_REAL_API 决定）
  useEffect(() => {
    let cancelled = false
    setComputing(true)
    setProgress(null)
    setAvgFilter(null)
    // 两个筛选默认都是「全部」：结果直接全部展出，不按时间差预筛。
    setFairnessFilter(null)

    if (USE_REAL_API) {
      // 真实百度地图 API：POI 检索 + 路线规划（带 24h 缓存 + 并发控制）
      ;(async () => {
        try {
          const res = await computeRealResult(form, (p) => {
            if (!cancelled) setProgress(p)
          }, radiusBonus)
          if (!cancelled) {
            setResult(res)
            setComputing(false)
            setResetKey((k) => k + 1)
          }
        } catch (err) {
          if (!cancelled) {
            console.error('计算失败', err)
            setResult({ shops: [], recommendation: null, reason: 'no_shops' })
            setComputing(false)
          }
        }
      })()
    } else {
      // Mock 模式：本地模拟同一套管线，不调用任何外部 API，零额度消耗
      const timer = setTimeout(() => {
        ;(async () => {
          try {
            const res = await computeMockResult(form, (p) => {
              if (!cancelled) setProgress(p)
            }, radiusBonus)
            if (!cancelled) {
              setResult(res)
              setComputing(false)
              setResetKey((k) => k + 1)
            }
          } catch (err) {
            if (!cancelled) {
              console.error('Mock 计算失败', err)
              setResult({ shops: [], recommendation: null, reason: 'no_shops' })
              setComputing(false)
            }
          }
        })()
      }, 300)
      return () => {
        cancelled = true
        clearTimeout(timer)
      }
    }

    return () => {
      cancelled = true
    }
  }, [form, radiusBonus])


  // 参数修改完成 -> 应用并关闭弹窗（form 变化自动触发重算）
  const applyForm = (next: FormState) => {
    onChange(next)
    setSheetOpen(false)
  }

  const toggleCollect = (shop: ShopWithCommute) => {
    // 持久化到 localStorage（我的页面可查看收藏）
    const isFav = toggleFavShop({
      id: shop.id,
      name: shop.name,
      primary: shop.primary,
      sub: shop.sub,
      category: shop.category,
      area: shop.area,
      rating: shop.rating,
      perCapita: shop.perCapita,
      lng: shop.lng,
      lat: shop.lat,
    })
    setCollected((c) => ({ ...c, [shop.id]: isFav }))
    show(isFav ? `已收藏「${shop.name}」` : `已取消收藏「${shop.name}」`, 'success')
  }

  /** 统一导航处理：用「我的位置」（points[0]）的坐标和交通方式 */
  const handleNavigate = (shop: ShopWithCommute) => {
    const myPoint = form.points[0]
    const origin = myPoint && myPoint.lng && myPoint.lat
      ? { name: myPoint.name || '我的位置', lng: myPoint.lng, lat: myPoint.lat }
      : null
    const mode = myPoint?.mode || 'drive'
    // 百度地图不支持直接打车，提示用户切换
    if (mode === 'taxi') {
      show('百度地图暂不支持直接打车，已为您打开驾车导航，请在页面内切换到「打车」模式', 'warn')
    }
    navigateToShop(shop, origin, mode)
  }

  const ok = result && result.reason === 'ok'

  /** 纯前端筛选后的列表：保留原精排相对顺序，不触发任何重算 */
  const visibleShops = ok
    ? result!.shops.filter(
        (s) =>
          (avgFilter == null || s.avg <= avgFilter) &&
          (fairnessFilter == null || s.fairness <= fairnessFilter),
      )
    : []

  /** 推荐卡片是否在当前筛选下可见 */
  const recShop = result?.recommendation?.shop
  const recVisible =
    !!ok &&
    !!recShop &&
    (avgFilter == null || recShop.avg <= avgFilter) &&
    (fairnessFilter == null || recShop.fairness <= fairnessFilter)

  return (
    <div className="page result-page">
      {/* 顶部固定需求摘要栏：点某个参数 chip -> 局部快捷弹窗；点「修改」-> 完整编辑 */}
      <ResultSummaryBar
        form={form}
        colors={POINT_COLORS}
        onEdit={(scope, index) => {
          if (scope) setQuick({ scope, index: index ?? 0 })
          else setSheetOpen(true)
        }}
        onBack={onBack}
      />

      {/* 双视图切换 */}
      <div className="segmented">
        <button type="button" className={view === 'map' ? 'active' : ''} onClick={() => setView('map')}>
          <IconMapView size={15} />
          地图视图
        </button>
        <button type="button" className={view === 'list' ? 'active' : ''} onClick={() => setView('list')}>
          <IconListView size={15} />
          列表视图{ok ? `(${visibleShops.length})` : ''}
        </button>
      </div>

      <div className="result-content">
        {/* While recommendations are computed, load the real map and tiles behind the loading veil.
            Keep the instance mounted when switching to the list so returning to the map is immediate. */}
        {(computing || ok) && (USE_REAL_API || !computing) && (
          <div className={`result-map-container${view === 'list' ? ' result-map-container--inactive' : ''}`} data-map-style={mapVisualMode}>
            <MapComponent
              points={form.points}
              colors={POINT_COLORS}
              shops={ok ? result!.shops : []}
              recommendedId={ok ? result!.recommendation?.shop.id : undefined}
              onShopSelect={(shop) => {
                setQuick(null)
                setPreviewShop(shop)
              }}
              visualStyle={mapVisualMode}
              onStyleApplied={setMapVisualMode}
              resetKey={resetKey}
            />
            <PaperMapFrame />
          </div>
        )}
        {computing || !result ? (
          <LoadingOverlay
            text={stageText(progress)}
            progress={stageProgress(progress)}
          />
        ) : !ok ? (
          // ---------- 降级兜底：无匹配店铺 ----------
          <EmptyState
            icon="🍽️"
            title="暂时没找到合适的店哦"
            desc="附近转了一圈，没找到大家都方便的地方。换个更常见的品类，或把出发点挪近一点再试试吧。"
            actions={[
              {
                label: '试试搜索更广范围',
                hint: radiusBonus > 0 ? `已扩大 ${radiusBonus} 公里，再 +2 公里重找` : '把搜索圆半径扩大 2 公里重找',
                icon: <IconRefresh size={18} />,
                onClick: () => {
                  setRadiusBonus((b) => b + 2)
                  show('已把搜索范围扩大 2 公里，重新检索中…', 'success')
                },
              },
              {
                label: '换个品类',
                hint: '换一个更常见的品类',
                icon: <IconLocate size={18} />,
                onClick: () => setQuick({ scope: 'category', index: 0 }),
              },
              {
                label: '调整碰友 & 出行方式',
                hint: '换更近的位置或加人',
                icon: <IconLocate size={18} />,
                onClick: () => setQuick({ scope: 'points', index: -1 }),
              },
            ]}
          />
        ) : (
          <>
            {/* 地图默认展示最终排序前 10 家（由地图组件内部截断）。 */}
            {view === 'list' && (
              /* 列表视图：展示全部最终结果 */
              <div className="list-view">
                <div className="list-head">
                  共 <b>{visibleShops.length}</b> 家合适地点 · 优先挑了「大家都快到、用时也差不多」的
                </div>

                {/* 筛选栏：平均通勤时长 + 通勤时间差（纯前端，不触发重算） */}
                <div className="filter-bar">
                  <FilterSegmentedControl label="平均通勤" icon="averageCommute"
                    value={avgFilter} options={[null, 20, 40, 60]}
                    onChange={(value) => { setAvgFilter(value); setAvgCustomOpen(false) }}
                    customOpen={avgCustomOpen} onCustom={() => {
                      setAvgCustomOpen(!avgCustomOpen)
                      setAvgCustomDraft(avgFilter != null ? String(avgFilter) : '')
                    }}>
                    {avgCustomOpen && (
                      <div className="filter-custom-row">
                        <input
                          type="number"
                          placeholder="分钟"
                          aria-label="平均通勤自定义分钟"
                          value={avgCustomDraft}
                          onChange={(e) => setAvgCustomDraft(e.target.value)}
                          min={1}
                          max={300}
                        />
                        <button
                          type="button"
                          className="filter-btn primary"
                          onClick={() => {
                            const v = parseInt(avgCustomDraft, 10)
                            if (v > 0 && v <= 300) {
                              setAvgFilter(v)
                              setAvgCustomOpen(false)
                              show(`平均通勤筛选：≤ ${v}分钟`, 'info')
                            } else {
                              show('请输入 1-300 之间的数字', 'warn')
                            }
                          }}
                        >
                          确定
                        </button>
                        <button
                          type="button"
                          className="filter-btn"
                          onClick={() => setAvgCustomOpen(false)}
                        >
                          取消
                        </button>
                      </div>
                    )}
                  </FilterSegmentedControl>

                  <FilterSegmentedControl label="时间差" icon="timeDiff"
                    value={fairnessFilter} options={[null, ...TIME_DIFF_PRESETS]}
                    onChange={(value) => { setFairnessFilter(value); setFairnessCustomOpen(false) }}
                    customOpen={fairnessCustomOpen} onCustom={() => {
                      setFairnessCustomOpen(!fairnessCustomOpen)
                      setFairnessCustomDraft(fairnessFilter != null ? String(fairnessFilter) : '')
                    }}>
                    {fairnessCustomOpen && (
                      <div className="filter-custom-row">
                        <input
                          type="number"
                          placeholder="分钟"
                          aria-label="时间差自定义分钟"
                          value={fairnessCustomDraft}
                          onChange={(e) => setFairnessCustomDraft(e.target.value)}
                          min={1}
                          max={180}
                        />
                        <button
                          type="button"
                          className="filter-btn primary"
                          onClick={() => {
                            const v = parseInt(fairnessCustomDraft, 10)
                            if (v > 0 && v <= 180) {
                              setFairnessFilter(v)
                              setFairnessCustomOpen(false)
                              show(`时间差筛选：≤ ${v}分钟`, 'info')
                            } else {
                              show('请输入 1-180 之间的数字', 'warn')
                            }
                          }}
                        >
                          确定
                        </button>
                        <button
                          type="button"
                          className="filter-btn"
                          onClick={() => setFairnessCustomOpen(false)}
                        >
                          取消
                        </button>
                      </div>
                    )}
                  </FilterSegmentedControl>
                </div>

                {/* 智能推荐：整个卡片可点击查看详情（推荐店铺也必须同时满足两个筛选条件） */}
                {recVisible && recShop && (
                  <div
                    className="ai-rec-card clickable"
                    role="button"
                    tabIndex={0}
                    onClick={() => setDetailShop(recShop)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault()
                        setDetailShop(recShop)
                      }
                    }}
                  >
                    <div className="ai-rec-row">
                      <span className="ai-rec-tag">碰碰首选</span>
                      <b className="ai-rec-name">{result!.recommendation!.shop.name}</b>
                    </div>
                    <p className="ai-rec-desc">{result!.recommendation!.reason}</p>
                    <div className="ai-rec-footer">
                      <button
                        type="button"
                        className="ai-rec-action"
                        onClick={(e) => {
                          e.stopPropagation()
                          setDetailShop(recShop)
                        }}
                      >
                        查看详情 ›
                      </button>
                    </div>
                  </div>
                )}

                {visibleShops
                  .filter((s) => !recVisible || s.id !== recShop?.id)
                  .map((s) => (
                    <ShopCard key={s.id} shop={s} points={form.points} colors={POINT_COLORS} onClick={() => setDetailShop(s)} />
                  ))}
                {visibleShops.length === 0 ? (
                  <div className="list-tail">当前筛选下没有符合的地点，试试把「平均通勤」或「时间差」放宽一点</div>
                ) : (
                  <div className="list-tail">已经到底啦，换个品类再看看？</div>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {/* 参数完整修改弹窗 */}
      <ParamEditSheet open={sheetOpen} onClose={() => setSheetOpen(false)} form={form} onApply={applyForm} />

      {/* 顶栏参数 chip 的局部快捷修改弹窗 */}
      <QuickSheet
        scope={quick?.scope ?? null}
        pointIndex={quick?.index ?? 0}
        form={form}
        onChange={(f) => onChange(f)}
        onClose={() => setQuick(null)}
        onOpenFull={() => {
          setQuick(null)
          setSheetOpen(true)
        }}
      />

      {/* 地图图钉点击 → 底部店铺预览卡片 */}
      <ShopPreviewSheet
        shop={previewShop}
        points={form.points}
        colors={POINT_COLORS}
        open={!!previewShop}
        onClose={() => setPreviewShop(null)}
        onViewDetail={(shop) => {
          setPreviewShop(null)
          setDetailShop(shop)
        }}
        onNavigate={(shop) => {
          // 用「我的位置」的坐标和交通方式导航
          handleNavigate(shop)
        }}
      />

      {/* 店铺详情 */}
      {detailShop && (
        <ShopDetailModal
          shop={detailShop}
          points={form.points}
          colors={POINT_COLORS}
          open={!!detailShop}
          onClose={() => setDetailShop(null)}
          collected={!!collected[detailShop.id]}
          onToggleCollect={() => toggleCollect(detailShop)}
          onShare={(proposal) => { setShareProposal(proposal); setShareOpen(true) }}
          onNavigate={() => {
            // 用「我的位置」的坐标和交通方式导航
            handleNavigate(detailShop)
          }}
        />
      )}

      {/* 分享会面提案卡片（仅 UI） */}
      {shareProposal && (
        <ShareCardModal
          open={shareOpen}
          onClose={() => { setShareOpen(false); setShareProposal(null) }}
          proposal={shareProposal}
        />
      )}
    </div>
  )
}
