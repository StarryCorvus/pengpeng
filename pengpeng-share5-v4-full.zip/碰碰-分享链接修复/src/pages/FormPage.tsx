import { FlowTitleUnderline } from '../components/brand/FlowTitleUnderline'
import { RoughBorder } from '../components/brand/RoughBorder'
import { PEOPLE_NEXT_CTA } from '../config/brandVisual'
import { useState, useEffect, useRef } from 'react'
import type { FormState } from '../types'
import { pointNickname } from '../utils/format'
import { StartPointList } from '../components/form/StartPointList'
import { BrandSplash } from '../components/brand/BrandSplash'
import { BrandIllustration } from '../components/brand/BrandIllustration'
import { CategoryCarousel } from '../components/brand/CategoryCarousel'
import { CATEGORY_NEXT_CTA } from '../components/brand/brandAssets'
import { useToast } from '../components/common/Toast'
import { reverseGeocode } from '../services/baiduMap'
/** 校验缺失项，返回可读文案列表 */
export function validateForm(form: FormState): string[] {
  const missing: string[] = []
  if (form.points.length < 2) missing.push('至少拉 2 个碰友')
  form.points.forEach((p, i) => {
    if (!p.name) missing.push(`${pointNickname(p, i)}还没选位置`)
  })
  if (!form.category) missing.push('选个想干的事')
  return missing
}

// In-memory presentation state survives Tab/route changes, resets on cold load.
let flowStep: 'intro'|'people'|'category' = window.location.hash === '#/result' ? 'people' : 'intro'
export function FormPage({form,onChange,onStart,onRelocate,onPeopleEntered}: {
 form:FormState;onChange:(f:FormState)=>void;onStart:()=>void;onRelocate?:()=>void;onPeopleEntered?:()=>void
}) {
 const [step,setStep]=useState(flowStep)
 useEffect(()=>{if(step==='people')onPeopleEntered?.()},[step,onPeopleEntered])
 const {show}=useToast()
 const title=useRef<HTMLHeadingElement>(null)
 const go=(next:typeof step)=>{flowStep=next;setStep(next)}
 useEffect(()=>{
  document.querySelector('.app-shell')?.classList.toggle('is-splash',step==='intro')
  document.querySelector('.app-content')?.scrollTo({top:0})
  if(step!=='intro') title.current?.focus({preventScroll:true})
  return ()=>document.querySelector('.app-shell')?.classList.remove('is-splash')
 },[step])
 const [crossCityWarn,setCrossCityWarn]=useState(false)
 const [checking,setChecking]=useState(false)
 const peopleReady=form.points.length>=2&&form.points.length<=6&&form.points.every(p=>p.name.trim()&&Number.isFinite(p.lng)&&Number.isFinite(p.lat)&&Math.abs(p.lng)<=180&&Math.abs(p.lat)<=90)
 const missing=validateForm(form)
 // 按城市检测是否跨城：任两点城市不同返回 true（识别失败的点不参与，不误拦）
 const detectCrossCity=async():Promise<boolean>=>{
  const cities:string[]=[]
  for(const p of form.points){
   const geo=await reverseGeocode(p.lng,p.lat)
   const c=(geo?.city||'').replace(/(省|市)$/g,'').trim()
   if(c)cities.push(c)
  }
  return cities.length>=2&&cities.some(c=>c!==cities[0])
 }
 // 首页「下一步」：点按钮时才检测跨城，跨城弹卡留在首页；否则去选品类
 const handlePeopleNext=async()=>{
  if(!peopleReady)return
  setChecking(true)
  try{
   if(await detectCrossCity()){setCrossCityWarn(true);return}
   go('category')
  } finally{setChecking(false)}
 }
 // 选完品类点「查找推荐地点」：再兜底检测一次跨城
 const handleStart=async()=>{
  if(missing.length||!peopleReady){show('请先完善碰友地点和品类','warn');return}
  setChecking(true)
  try{
   if(await detectCrossCity()){setCrossCityWarn(true);return}
   flowStep='category';onStart()
  } finally{setChecking(false)}
 }
 if(step==='intro')return <BrandSplash onEnter={()=>go('people')}/>
 return <div className={`page form-page brand-flow flow-${step}`}>
  <div className="flow-topline"><button type="button" disabled={step==='people'} onClick={()=>go('people')} aria-label={step==='category'?'返回碰友':'已在第一步'}>←</button><span className="flow-brand-line">碰碰 · 想见，那就轻松碰一面</span><span>{step==='people'?'01':'02'} / 02</span></div>
  <header className="flow-heading" key={step}>
   <BrandIllustration variant={step}/>
   <h1 ref={title} tabIndex={-1}>{step==='people'?'谁要碰碰':'想干什么'}</h1>
   <FlowTitleUnderline/>
  </header>
  <div className="form-body" key={`${step}-body`}>
   {step==='people'?<><div className="flow-section-label"><span>碰友名单</span><span>{form.points.length} / 6 位</span></div><StartPointList nicknameOnboarding points={form.points} onChange={points=>onChange({...form,points})} onRelocate={onRelocate}/></>:<CategoryCarousel value={form.category} onChange={category=>onChange({...form,category})}/>}
  </div>
  <div className="form-footer">
   <p className="flow-cta-note">{step==='people'?'碰友集结完毕':'想做的敲定啦'}</p>
   <button type="button" className="btn-primary btn-block" aria-label={step==='people'?PEOPLE_NEXT_CTA:CATEGORY_NEXT_CTA} disabled={(step==='people'?!peopleReady:missing.length>0||!peopleReady)||checking} onClick={()=>{ if(step==='people'){void handlePeopleNext();return} void handleStart() }}><RoughBorder/>{checking?'正在确认位置…':(step==='people'?PEOPLE_NEXT_CTA:CATEGORY_NEXT_CTA)}</button>
  </div>
  {crossCityWarn&&(
   <div className="cross-city-mask" onClick={()=>setCrossCityWarn(false)}>
    <div className="cross-city-card" onClick={e=>e.stopPropagation()}>
     <div className="cross-city-icon">🌏</div>
     <h3>你们好像不在同一座城市</h3>
     <p>碰碰主打大家通勤都不太远的小聚，把其中一个出发点换到同一座城市再试试吧。</p>
     <button type="button" className="btn-primary btn-block" onClick={()=>setCrossCityWarn(false)}>我知道了</button>
    </div>
   </div>
  )}
 </div>
}
