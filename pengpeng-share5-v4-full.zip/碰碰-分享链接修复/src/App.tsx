// ============================================================
// App 根组件：
// - Hash 路由（#/form <-> #/result <-> #/profile <-> #/favorites）
// - 表单全局状态 + localStorage 自动记忆回填
// - 底部 Tab 导航（碰碰 / 我的），Tab 切换保持上次页面
// - 全局 Toast
// ============================================================

import { useEffect, useRef, useState } from 'react'
import type { FormState } from './types'
import { CURRENT_LOCATION, makePoint } from './mock/places'
import { DEFAULT_TIME_DIFF } from './mock/constants'
import { incrementCount, loadFormState, saveFormState } from './utils/storage'
import { getCurrentLocation } from './services/baiduMap'
import { USE_REAL_API } from './config'
import { ToastProvider } from './components/common/Toast'
import { BottomNav, type TabKey } from './components/common/BottomNav'
import { FormPage } from './pages/FormPage'
import { ResultPage } from './pages/ResultPage'
import { ProfilePage } from './pages/ProfilePage'
import { FavoritesPage } from './pages/FavoritesPage'
import { DiaryPage } from './pages/DiaryPage'
import { ShareProposalPage } from './pages/ShareProposalPage'

/** 默认表单：第一个出发点默认填充模拟当前定位 */
function defaultForm(): FormState {
  const current = makePoint(
    { name: CURRENT_LOCATION.name, address: CURRENT_LOCATION.address, lng: CURRENT_LOCATION.lng, lat: CURRENT_LOCATION.lat },
    'transit',
    'locate',
    { isCurrentLocation: true },
  )
  return { points: [current], category: null, timeDiff: DEFAULT_TIME_DIFF }
}

type Route = 'form' | 'result' | 'profile' | 'favorites' | 'diary' | 'share'

function routeFromHash(): Route {
  const h = window.location.hash
  if (h.startsWith('#/share/')) return 'share'
  if (h === '#/profile') return 'profile'
  if (h === '#/favorites') return 'favorites'
  if (h === '#/diary') return 'diary'
  return h === '#/result' ? 'result' : 'form'
}

export default function App() {
  const [route, setRoute] = useState<Route>(routeFromHash)
  const [shareHash, setShareHash] = useState(() => window.location.hash)
  const [peopleEntered, setPeopleEntered] = useState(false)
  // 记录离开「碰碰」Tab 时的最后一个 app 内路由（form/result），返回时恢复
  const lastAppRouteRef = useRef<'form' | 'result'>('form')
  // 记录离开「我的」Tab 时的最后一个 profile 内路由（profile/favorites/diary），返回时恢复
  const lastProfileRouteRef = useRef<'profile' | 'favorites' | 'diary'>('profile')
  // 自动记忆：首次进入回填上次填写内容，但只保留「我的位置」，TA 位置每次进入首页为空
  const [form, setForm] = useState<FormState>(() => {
    const saved = loadFormState()
    if (saved && saved.points.length > 0 && saved.points[0].isCurrentLocation) {
      // 只保留第一个出发点（我的位置），清空 TA 位置卡片
      return { ...saved, points: [saved.points[0]] }
    }
    return defaultForm()
  })

  useEffect(() => {
    const onHash = () => { setShareHash(window.location.hash); setRoute(routeFromHash()) }
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])

  // 全局错误兜底：捕获未处理的 Promise rejection，避免页面崩溃
  useEffect(() => {
    const onUnhandledRejection = (e: PromiseRejectionEvent) => {
      console.warn('[App] 捕获未处理的 Promise rejection:', e.reason)
      // 阻止默认行为（某些浏览器会在控制台显示错误）
      e.preventDefault()
    }
    const onError = (e: ErrorEvent) => {
      console.error('[App] 捕获全局错误:', e.error || e.message)
    }
    window.addEventListener('unhandledrejection', onUnhandledRejection)
    window.addEventListener('error', onError)
    return () => {
      window.removeEventListener('unhandledrejection', onUnhandledRejection)
      window.removeEventListener('error', onError)
    }
  }, [])

  // 任何变更自动保存（表单记忆 + 结果页参数修改同步记忆）
  useEffect(() => {
    if (route === 'share') return
    saveFormState(form)
  }, [form, route])

  // 首次 People 已呈现后才启动自动定位；该单向状态在本次 App 生命周期保持 true。
  // 加强降级：定位超时/失败都静默处理，绝不影响页面渲染
  useEffect(() => {
    if (!USE_REAL_API || !peopleEntered) return
    let cancelled = false
    ;(async () => {
      try {
        // 加 8 秒超时，避免定位挂起导致页面无响应
        const locPromise = getCurrentLocation()
        const timeoutPromise = new Promise<null>((resolve) =>
          setTimeout(() => resolve(null), 8000),
        )
        const loc = await Promise.race([locPromise, timeoutPromise])
        if (cancelled || !loc) return
        // 校验坐标有效性
        if (!Number.isFinite(loc.lng) || !Number.isFinite(loc.lat) ||
            loc.lng < -180 || loc.lng > 180 || loc.lat < -90 || loc.lat > 90) {
          return
        }
        setForm((prev) => {
          if (prev.points.length === 0 || !prev.points[0].isCurrentLocation) return prev
          const realPoint = makePoint(
            { name: loc.address || '当前位置', address: loc.address || '当前位置', lng: loc.lng, lat: loc.lat },
            prev.points[0].mode,
            'locate',
            { isCurrentLocation: true },
          )
          return { ...prev, points: [realPoint, ...prev.points.slice(1)] }
        })
      } catch (err) {
        // 定位失败静默降级，保留 mock 当前位置，绝不抛出
        console.warn('[App] 定位失败，使用模拟位置:', err)
      }
    })()
    return () => {
      cancelled = true
    }
  }, [peopleEntered])

  // 我的位置「重新定位」：手动触发真实定位，成功后更新第一个出发点
  const relocateMyLocation = () => {
    if (!USE_REAL_API) {
      // Mock 模式：重置为模拟当前位置
      setForm((prev) => {
        if (prev.points.length === 0) return prev
        const mockPoint = makePoint(
          { name: CURRENT_LOCATION.name, address: CURRENT_LOCATION.address, lng: CURRENT_LOCATION.lng, lat: CURRENT_LOCATION.lat },
          prev.points[0].mode,
          'locate',
          { isCurrentLocation: true },
        )
        return { ...prev, points: [mockPoint, ...prev.points.slice(1)] }
      })
      return
    }
    // 真实 API 模式：调用定位
    ;(async () => {
      try {
        const loc = await getCurrentLocation()
        if (!loc) return
        setForm((prev) => {
          if (prev.points.length === 0) return prev
          const realPoint = makePoint(
            { name: loc.address || '当前位置', address: loc.address, lng: loc.lng, lat: loc.lat },
            prev.points[0].mode,
            'locate',
            { isCurrentLocation: true },
          )
          return { ...prev, points: [realPoint, ...prev.points.slice(1)] }
        })
      } catch {
        // 定位失败静默
      }
    })()
  }

  // 底部 Tab 切换（双向缓存：碰碰tab记住form/result，我的tab记住profile/favorites/diary）
  const activeTab: TabKey = route === 'profile' || route === 'favorites' || route === 'diary' ? 'profile' : 'app'
  const switchTab = (tab: TabKey) => {
    // People / Category / Result 已经属于「碰碰」Tab：重复点击必须是完整 no-op。
    // 提前返回，避免重复写 hash 触发滚动复位、组件重挂载或请求链路。
    if (tab === 'app' && activeTab === 'app') return
    if (tab === 'profile') {
      // 离开碰碰前记录当前 app 路由
      if (route === 'form' || route === 'result') {
        lastAppRouteRef.current = route
      }
      // 回到我的：恢复离开时的 profile 路由（我的主页/收藏列表/日记）
      const last = lastProfileRouteRef.current
      window.location.hash = last === 'favorites' ? '#/favorites' : last === 'diary' ? '#/diary' : '#/profile'
    } else {
      // 离开我的前记录当前 profile 路由
      if (route === 'profile' || route === 'favorites' || route === 'diary') {
        lastProfileRouteRef.current = route
      }
      // 回到碰碰：恢复离开时的 app 路由（结果页/表单页）
      window.location.hash = lastAppRouteRef.current === 'result' ? '#/result' : '#/form'
    }
  }

  // 点击「开始寻找」：记录发起会面计数 + 跳转结果页
  const handleStart = () => {
    incrementCount('meetingsStarted')
    lastAppRouteRef.current = 'result'
    window.location.hash = '#/result'
  }

  if (route === 'share') return <ShareProposalPage key={shareHash} />

  return (
    <ToastProvider>
      <div className={`app-shell app-shell--viewport ${route === 'diary' ? 'app-shell--diary' : ''} ${route === 'result' || route === 'form' ? 'app-shell--fixed' : ''}`}>
        <div className="app-content">
          {route === 'form' ? (
            <FormPage
              form={form}
              onChange={setForm}
              onStart={handleStart}
              onRelocate={relocateMyLocation}
              onPeopleEntered={() => setPeopleEntered(true)}
            />
          ) : route === 'result' ? (
            <ResultPage form={form} onChange={setForm} onBack={() => (window.location.hash = '#/form')} />
          ) : route === 'favorites' ? (
            <FavoritesPage onBack={() => (window.location.hash = '#/profile')} />
          ) : route === 'diary' ? (
            <DiaryPage onBack={() => (window.location.hash = '#/profile')} />
          ) : (
            <ProfilePage
              onOpenFavorites={() => (window.location.hash = '#/favorites')}
              onOpenDiary={() => (window.location.hash = '#/diary')}
            />
          )}
        </div>
        <BottomNav active={activeTab} onChange={switchTab} />
      </div>
    </ToastProvider>
  )
}
