// ============================================================
// 真实计算引擎（百度地图 API 版本）：
//  1) 按 UI 子品类拆分检索（召回方式不变）
//  2) 对全部召回 POI 做直线距离地理粗排
//  3) 只取粗排 Top 30 进入真实通勤计算（不设 reserve/challenger，不按合格数提前停）
//  4) Top 30 全部完成真实通勤（复用 baiduMap 的 24h 缓存与最大 3 路并发）
//  5) 加权精排排序
//  6) 系统硬过滤：时间差 > 60 分钟淘汰
//  7) 品牌/品类多样性软重排；不固定输出数量，剩多少展示多少
// ============================================================

import type { FormState, MockResult, Shop, ShopWithCommute, TravelMode, TravelPoint } from '../types'
import { searchNearby, planRoute, reverseGeocode } from './baiduMap'
import type { BaiduPoi } from './baiduMap'
import {
  computeAllRoutes,
  diversityRerank,
  getRecallBranches,
  getRecallFetchLimit,
  haversineKm,
  isExcludedBySubcategory,
  maxCommuteOf,
  mergeRecallGroups,
  passesHardFairness,
  rankByGeographicFit,
  rankEligibleShops,
  type PipelineProgress,
} from '../utils/resultPipeline'
import { SHOP_PIPELINE_CONFIG } from '../config'
import { isLeisureAll, leisureSubcategories, mergeLeisureRecall, leisureShortlist, leisureTopTen,
  withinLeisureCommuteLimit, debugLeisureRecall, debugLeisureStage, leisureRecallBranches, classifyLeisurePoi } from '../utils/leisureDiversity'

/**
 * 找最远两个出发点，返回它们连线的中点和距离。
 * 比算术平均更"居中"——不会被人多的一侧拉偏，搜索圆更小更集中。
 */
function findCenterAndRadius(
  points: TravelPoint[],
  radiusBonusKm = 0,
): { centerLng: number; centerLat: number; radiusMeters: number } {
  let maxDist = 0
  let a = points[0]
  let b = points[1]
  for (let i = 0; i < points.length; i++) {
    for (let j = i + 1; j < points.length; j++) {
      const d = haversineKm(points[i], points[j])
      if (d > maxDist) {
        maxDist = d
        a = points[i]
        b = points[j]
      }
    }
  }
  const centerLng = (a.lng + b.lng) / 2
  const centerLat = (a.lat + b.lat) / 2
  // 半径 = 最远两人距离的一半 + 3km 缓冲；下限 4km，同城里不再设上限。
  // 跨城由首页 FormPage 在进结果前按城市拦截，这里只负责同城半径。
  // 用户在空结果页点「搜索更广范围」时，在基础半径上叠加 radiusBonusKm。
  const baseRadiusKm = Math.max(4, maxDist / 2 + 3)
  const radiusKm = baseRadiusKm + radiusBonusKm
  return { centerLng, centerLat, radiusMeters: Math.round(radiusKm * 1000) }
}

/** 百度 POI -> 内部 Shop 类型；全部分类时记录本次实际召回的子品类。 */
function poiToShop(
  poi: BaiduPoi,
  primary: string,
  subcategory: string,
): Shop {
  return {
    id: poi.uid,
    uid: poi.uid,
    name: poi.name,
    primary,
    sub: subcategory,
    category: primary === 'mall' ? '综合型购物中心' : subcategory,
    city: poi.city || '',
    area: poi.area || '',
    address: poi.address || '',
    lng: poi.lng,
    lat: poi.lat,
    // 优先用 LocalSearch 直接返回的评分/人均，没有则为 0（详情页按需补充）
    rating: poi.rating != null ? Number(poi.rating) || 0 : 0,
    perCapita: poi.price != null ? Number(poi.price) || 0 : 0,
    hours: poi.shopHours || '',
    intro: poi.intro || '',
    images: [],
    phone: poi.phone,
    tags: poi.tag ? String(poi.tag).split(',').filter(Boolean) : [],
  }
}

/** 沿用原工程的「同名 + 四位坐标」POI 去重口径。 */
function poiDedupKey(poi: BaiduPoi): string {
  return `${poi.name}_${poi.lng.toFixed(4)}_${poi.lat.toFixed(4)}`
}

/** 超市购物下的二级品类：只期望召回零食/生鲜/便利店/大型超市，不要珠宝百货等其它「购物」POI。 */
const MARKET_SUBCATEGORIES = new Set(['零食店', '生鲜店', '便利店', '大型超市'])

/**
 * 超市购物 / 综合购物中心 召回时的「无关业态」分类 tag 黑名单。
 * 百度 place 检索用宽 tag「购物」做半径召回时，会把同属「购物/生活服务」大类、
 * 但与"约在超市/商场见面"无关的 POI 一并返回（如商场里的眼镜店、银行网点、移动营业厅）。
 */
const SHOPPING_TAG_EXCLUDE = /珠宝|首饰|钻石|金店|银楼|钟表|手表|眼镜|化妆品|美容|美发|美甲|SPA|足浴|按摩|服装|服饰|鞋|箱包|数码|手机|家电|家具|家居|运动|图书|书店|药店|药房|母婴|玩具|礼品|银行|金融|保险|证券|ATM|电信|联通|移动营业厅|旅行社|旅游|医院|医疗|诊所|口腔|牙科|体检|驾校|培训|教育|学校|4S|汽车|加油|充电|房产|中介|派出所|政务|邮政|宠物|影城|电影|KTV|健身|台球|棋牌|网吧|彩票/

/**
 * 超市购物 / 综合购物中心 召回时的「无关业态」名称黑名单（不依赖百度 tag，tag 经常缺失）。
 *
 * 背景：用宽词（超市/购物中心/购物）做半径召回时，百度会把开在商场里、
 * 但与"约在超市/商场见面"无关的店铺一并返回，例如：
 *   宝岛眼镜(朝阳大悦城店)、中国工商银行XX支行、中国移动XX营业厅、XX旅行社。
 * 这些店名称里常带"购物中心/大悦城/XX商场"等地名，容易误命中关键词被召回来。
 * 这里按 POI 名称直接子串匹配过滤。
 *
 * 注意：词表只收「绝不会出现在超市/便利店/生鲜/零食店/购物中心本身名称里」的业态，
 * 避免误杀目标 POI（如盒马、山姆、万象城、大悦城、万达广场等均不含下列词）。
 */
const SHOPPING_NAME_EXCLUDE = new RegExp(
  [
    // 金融银行 / 保险证券
    '银行', '支行', '储蓄所', '信用社', '农商行', '农业银行', '工商银行',
    '建设银行', '中国银行', '交通银行', '招商银行', '浦发银行', '民生银行',
    '光大银行', '兴业银行', '中信银行', '邮政储蓄', '证券', '保险', 'ATM',
    // 运营商营业厅 / 数码通讯
    '中国移动', '中国联通', '中国电信', '电信营业厅', '联通营业厅', '移动营业厅',
    '沟通100', '手机维修', '手机店', '数码广场', '苹果专卖', '华为体验店', '小米之家',
    // 旅游 / 旅行社
    '旅行社', '旅游公司', '国旅', '中青旅', '康辉', '携程', '去哪儿', '景区门票',
    // 眼镜 / 视力
    '眼镜', '视光', '视力', '宝岛眼镜', '大光明眼镜', '博士眼镜', '精工眼镜', '蔡司',
    // 医疗 / 药店
    '医院', '诊所', '口腔', '牙科', '体检中心', '门诊部', '卫生院', '大药房',
    '药房', '药店', '卫生室', '社区卫生服务',
    // 教育 / 培训 / 驾校
    '驾校', '培训中心', '教育培训', '辅导班', '自习室', '幼儿园', '学校', '学院',
    '大学', '小学', '中学',
    // 汽车 / 加油充电
    '4S店', '汽车销售', '洗车', '汽修', '汽车维修', '加油站', '充电站', '充电桩',
    '二手车', '汽车美容',
    // 房产中介 / 售楼
    '房产中介', '售楼处', '楼盘', '二手房', '租房', '链家', '我爱我家', '中原地产',
    // 政务 / 公共事业
    '派出所', '政务中心', '税务局', '社保局', '邮政局', '邮局', '居委会',
    '街道办', '法院', '检察院',
    // 美容美发 / 养生
    '美容院', '美发', '理发', '美甲', '养生会所', '足疗', '按摩', '足浴',
    // 宠物
    '宠物医院', '宠物店', '宠物用品',
    // 珠宝 / 奢侈品（原 MARKET_BRAND_EXCLUDE 合并于此）
    '周大福', '周生生', '六福', '老凤祥', '周大生', '谢瑞麟', '潮宏基', '珠宝', '金店', '银楼', '名表',
    // 其他与超市商场无关的线下业态
    '花店', '殡葬', '婚纱摄影', '影楼', '打印店', '照相馆', '彩票', '网吧', '网咖',
    '台球', '棋牌', 'KTV', '电影院', '影城', '健身房',
  ].join('|'),
  'i',
)

/**
 * 子品类拆分召回：各分支独立检索，先保留基础配额，再允许富余分支补位。
 * 单个子品类检索失败不会拖垮其他分支。
 */
async function recallCandidateShops(
  form: FormState,
  centerLng: number,
  centerLat: number,
  city: string,
  radiusMeters: number,
): Promise<Shop[]> {
  const balanced = isLeisureAll(form.category)
  const branches = balanced ? leisureRecallBranches(form.category) : getRecallBranches(form.category)
  const fetchLimit = getRecallFetchLimit(balanced ? leisureSubcategories.length : branches.length)
  const groups = await Promise.all(
    branches.map(async (branch) => {
      try {
        const items = await searchNearby(branch.keyword, centerLng, centerLat, radiusMeters, fetchLimit, city, branch.tag)
        // 召回后双重过滤：
        // 1. 名称黑名单（如 DIY 过滤掉餐饮类串品类结果）
        // 2. 百度 POI 分类标签：DIY 品类过滤掉 tag 含餐饮类的 POI
        const filtered = items.filter((poi) => {
          if (isExcludedBySubcategory(poi.name, branch.subcategory)) return false
          if (branch.subcategory === 'DIY手工坊' && poi.tag) {
            // 百度 tag 格式如"餐饮服务;中餐厅"或"休闲娱乐;DIY手工坊"
            if (/餐饮|美食|餐厅|小吃|快餐|面馆|火锅|烧烤|奶茶|咖啡|面包|蛋糕|甜品|烘焙/.test(poi.tag)) return false
          }
          // 超市购物类 + 综合购物中心：百度 place 检索用宽 tag「购物」做半径召回时，会把
          // 开在商场里但与超市/商场见面无关的 POI 一并返回（眼镜店、银行网点、移动营业厅、
          // 旅行社等），这些店名称常带"购物中心/XX商场"地名而被宽词误命中。
          // 这里按 POI 自身分类 tag + 无关业态名称黑名单过滤。
          // branch.subcategory === '' 对应「综合型购物中心(mall)」一级品类（关键词"购物中心"）。
          const isShoppingRecall = branch.subcategory === '' || MARKET_SUBCATEGORIES.has(branch.subcategory)
          if (isShoppingRecall) {
            if (poi.tag && SHOPPING_TAG_EXCLUDE.test(poi.tag)) return false
            if (SHOPPING_NAME_EXCLUDE.test(poi.name)) return false
          }
          // 球类运动：过滤掉大学/学院/校区内的球馆，只保留对外开放的商业场馆。
          if (branch.subcategory === '球类运动' && /大学|学院|校区|校园/.test(poi.name)) return false
          // 零食店：品牌词召回里不要混入大型购物中心/商贸中心/商场/百货。
          if (branch.subcategory === '零食店' && /购物中心|商贸中心|购物广场|商场|百货/.test(poi.name)) return false
          // 零食店：兜底泛词召回会串到粥铺/小商品/奶站/便利店等非零食品类，一并过滤。
          if (branch.subcategory === '零食店' && /粥|小商品|奶站|便民|便利店|超市|生鲜|水果|药店|早餐|包子|馒头|熟食|卤味|烤鸭|炸鸡|汉堡|奶茶|咖啡/.test(poi.name)) return false
          return true
        })
        return { subcategory: branch.subcategory, items: filtered, rawCount: items.length, rawItems: items }
      } catch (error) {
        console.warn(`[computeRealResult] 子品类「${branch.subcategory || branch.keyword}」检索失败`, error)
        return { subcategory: branch.subcategory, items: [] as BaiduPoi[] }
      }
    }),
  )

  if (balanced) {
    const keyOf = (poi: BaiduPoi) => poi.uid || poiDedupKey(poi)
    const recalled = mergeLeisureRecall(groups, keyOf, classifyLeisurePoi)
    debugLeisureRecall(groups, recalled, keyOf, classifyLeisurePoi)
    return recalled.map(({ item, subcategory, matchedSubcategoryKeys }) => ({
      ...poiToShop(item, form.category!.primary, subcategory),
      category: subcategory || '休闲娱乐', matchedSubcategoryKeys, logicalSubcategoryKey: subcategory,
    }))
  }
  return mergeRecallGroups(groups, poiDedupKey).map(({ item, subcategory }) =>
    poiToShop(item, form.category?.primary || 'food', subcategory),
  )
}

/** 计算一家店到所有出发点的真实通勤。任一路线失败则返回 null（跳过这家店，不估算）。 */
async function calculateShopCommute(shop: Shop, form: FormState, city: string): Promise<ShopWithCommute | null> {
  const commutes: Array<{ pointId: string; pointName: string; mode: TravelMode; minutes: number; fare: number }> = []
  for (const point of form.points) {
    try {
      const route = await planRoute(point.lng, point.lat, shop.lng, shop.lat, point.mode, city)
      commutes.push({
        pointId: point.id,
        pointName: point.name,
        mode: point.mode as TravelMode,
        minutes: route.minutes,
        fare: route.fare,
      })
    } catch (e) {
      console.warn(`[compute] 路线计算失败，跳过「${shop.name}」：`, e instanceof Error ? e.message : e)
      return null
    }
  }
  const minutes = commutes.map((commute) => commute.minutes)
  const fairness = Math.max(...minutes) - Math.min(...minutes)
  const avg = minutes.reduce((sum, value) => sum + value, 0) / minutes.length
  return { ...shop, commutes, fairness, avg }
}

/**
 * 真实计算主入口。
 * @param onProgress 只回报管线阶段与路线计算完成进度（用于进度条 + 阶段文案），
 *                   不再向 UI 暴露「已找到 X / 20 家」这类候选数量反馈。
 */
export async function computeRealResult(
  form: FormState,
  onProgress?: (p: PipelineProgress) => void,
  radiusBonusKm = 0,
): Promise<MockResult> {
  if (!form.category || form.points.length < 2) {
    return { shops: [], recommendation: null, reason: 'no_shops' }
  }

  // 1) 中心点 = 最远两人连线中点；搜索半径 = 最远两人距离/2 + 缓冲（4~15km），可叠加用户主动扩大的半径
  const { centerLng, centerLat, radiusMeters } = findCenterAndRadius(form.points, radiusBonusKm)

  // 1.5) 根据中心点经纬度逆地理编码识别城市，传给路线规划和地点搜索 API。
  onProgress?.({ stage: 'recall', routed: 0, total: 0 })

  let city = ''
  try {
    const geo = await reverseGeocode(centerLng, centerLat)
    if (geo?.city) {
      city = geo.city.replace(/市$/, '')
    }
  } catch {
    // 城市识别失败，city 保持空字符串，后续 API 调用会报错并提示
  }
  if (!city) {
    console.warn('[computeRealResult] 未能自动识别城市，请确认定位或选择城市')
    return { shops: [], recommendation: null, reason: 'no_shops' }
  }

  // 2) 召回方式保持不变（子品类配额召回 + 同名同坐标去重）。
  const candidates = await recallCandidateShops(form, centerLng, centerLat, city, radiusMeters)
  if (candidates.length === 0) {
    return { shops: [], recommendation: null, reason: 'no_shops' }
  }

  // 3) 对全部召回 POI 做现有地理粗排；只取粗排 Top N（默认 30）进入真实路线计算。
  //    不设 reserve / challenger，也不按合格数量提前停止。
  const geographicallyRanked = rankByGeographicFit(candidates, form.points)
  const balanced = isLeisureAll(form.category)
  const routeCandidates = balanced ? leisureShortlist(geographicallyRanked)
    : geographicallyRanked.slice(0, SHOP_PIPELINE_CONFIG.routeComputeCount)
  if (balanced) debugLeisureStage('shortlist', routeCandidates)

  // 4) Top N 全部完成真实通勤计算。路线计算失败的店返回 null，直接过滤掉，不做估算。
  const routed = await computeAllRoutes(
    routeCandidates,
    (shop) => calculateShopCommute(shop, form, city),
    (done, total) => onProgress?.({ stage: 'routing', routed: done, total }),
  )
  const computed = routed.filter((s): s is ShopWithCommute => s !== null)

  // 5) 系统硬过滤：时间差（fairness）> 60 分钟淘汰。
  const hardFiltered = computed.filter(s => passesHardFairness(s) && (!balanced || withinLeisureCommuteLimit(s)))
  if (balanced) debugLeisureStage('qualified', hardFiltered)
  if (hardFiltered.length === 0) {
    return { shops: [], recommendation: null, reason: 'no_shops' }
  }

  // 6) 精排打分排序（平均通勤、最远一方、时间差、稳定原序）。
  const qualityRanked = rankEligibleShops(hardFiltered)

  onProgress?.({ stage: 'finishing', routed: routeCandidates.length, total: routeCandidates.length })

  // 7) 对剩余候选执行现有品牌/品类多样性软重排；不固定输出 20 家，剩多少展示多少。
  const isAllCategory =
    form.category.primary !== 'mall' &&
    (!form.category.secondary || form.category.secondary === '全部分类')
  const diversified = diversityRerank(qualityRanked, isAllCategory)
  const finalShops = balanced ? leisureTopTen(diversified) : diversified
  if (balanced) debugLeisureStage('final Top10', finalShops.slice(0, 10))

  const best = finalShops[0]
  const recommendation = best
    ? {
        shop: best,
        reason: `${best.name}平均通勤约 ${Math.round(best.avg)} 分钟，最远一方 ${maxCommuteOf(best)} 分钟，各方时间差 ${best.fairness} 分钟。`,
      }
    : null

  return { shops: finalShops, recommendation, reason: 'ok' }
}
