// ============================================================
// 百度地图 API 服务层（真实 API 版本）
// - 动态加载百度地图 JS API
// - 地点检索（24h 缓存）
// - 路线规划（24h 缓存 + 并发控制，QPS 保护）
// - 地理编码 / 逆地理编码 / 定位
// 所有回调式 API 统一封装为 Promise
// ============================================================

import type { TravelMode } from '../types'

/** 百度地图全局对象声明 */
declare global {
  interface Window {
    BMap: any
    BMAP_STATUS_SUCCESS: number
    __BAIDU_MAP_LOADING__?: Promise<void>
    __BAIDU_MAP_AK__?: string
  }
}

const CACHE_TTL = 24 * 60 * 60 * 1000 // 24 小时
const ROUTE_CONCURRENCY = 3 // 路线规划最大并发数（保护百度 QPS 配额）

/**
 * SCF 代理地址：路线规划走 Web 服务 API（经 Serverless 代理签名），
 * 不再依赖浏览器端 BMap.TransitRoute / DrivingRoute 等 JS API。
 */
const ROUTE_PROXY_URL = 'https://1490199018-h2kvplnzru.ap-beijing.tencentscf.com'

// ---------- 坐标转换：WGS84（浏览器定位）-> BD09（百度API） ----------
const GCJ_A = 6378245.0
const GCJ_EE = 0.00669342162296594323

function outOfChina(lng: number, lat: number): boolean {
  return lng < 72.004 || lng > 137.8347 || lat < 0.8293 || lat > 55.8271
}

function transformLat(lng: number, lat: number): number {
  let ret = -100.0 + 2.0 * lng + 3.0 * lat + 0.2 * lat * lat + 0.1 * lng * lat + 0.2 * Math.sqrt(Math.abs(lng))
  ret += (20.0 * Math.sin(6.0 * lng * Math.PI) + 20.0 * Math.sin(2.0 * lng * Math.PI)) * 2.0 / 3.0
  ret += (20.0 * Math.sin(lat * Math.PI) + 40.0 * Math.sin(lat / 3.0 * Math.PI)) * 2.0 / 3.0
  ret += (160.0 * Math.sin(lat / 12.0 * Math.PI) + 320 * Math.sin(lat * Math.PI / 30.0)) * 2.0 / 3.0
  return ret
}

function transformLng(lng: number, lat: number): number {
  let ret = 300.0 + lng + 2.0 * lat + 0.1 * lng * lng + 0.1 * lng * lat + 0.1 * Math.sqrt(Math.abs(lng))
  ret += (20.0 * Math.sin(6.0 * lng * Math.PI) + 20.0 * Math.sin(2.0 * lng * Math.PI)) * 2.0 / 3.0
  ret += (20.0 * Math.sin(lng * Math.PI) + 40.0 * Math.sin(lng / 3.0 * Math.PI)) * 2.0 / 3.0
  ret += (150.0 * Math.sin(lng / 12.0 * Math.PI) + 300.0 * Math.sin(lng / 30.0 * Math.PI)) * 2.0 / 3.0
  return ret
}

/** WGS84 -> GCJ02 */
function wgs84ToGcj02(lng: number, lat: number): { lng: number; lat: number } {
  if (outOfChina(lng, lat)) return { lng, lat }
  let dLat = transformLat(lng - 105.0, lat - 35.0)
  let dLng = transformLng(lng - 105.0, lat - 35.0)
  const radLat = (lat / 180.0) * Math.PI
  let magic = Math.sin(radLat)
  magic = 1 - GCJ_EE * magic * magic
  const sqrtMagic = Math.sqrt(magic)
  dLat = (dLat * 180.0) / (((GCJ_A * (1 - GCJ_EE)) / (magic * sqrtMagic)) * Math.PI)
  dLng = (dLng * 180.0) / ((GCJ_A / sqrtMagic) * Math.cos(radLat) * Math.PI)
  return { lng: lng + dLng, lat: lat + dLat }
}

/** GCJ02 -> BD09 */
function gcj02ToBd09(lng: number, lat: number): { lng: number; lat: number } {
  const z = Math.sqrt(lng * lng + lat * lat) + 0.00002 * Math.sin(lat * Math.PI)
  const theta = Math.atan2(lat, lng) + 0.000003 * Math.cos(lng * Math.PI)
  return { lng: z * Math.cos(theta) + 0.0065, lat: z * Math.sin(theta) + 0.006 }
}

/** WGS84（浏览器原生定位）-> BD09（百度API坐标） */
export function wgs84ToBd09(lng: number, lat: number): { lng: number; lat: number } {
  const gcj = wgs84ToGcj02(lng, lat)
  return gcj02ToBd09(gcj.lng, gcj.lat)
}

// ---------- 通用缓存工具 ----------
interface CacheEntry<T> {
  data: T
  expire: number
}
const placeCache = new Map<string, CacheEntry<any[]>>()
const routeCache = new Map<string, CacheEntry<{ minutes: number; fare: number }>>()
const geocodeCache = new Map<string, CacheEntry<{ address: string; city: string }>>()

function cacheGet<T>(cache: Map<string, CacheEntry<T>>, key: string): T | null {
  const entry = cache.get(key)
  if (!entry) return null
  if (Date.now() > entry.expire) {
    cache.delete(key)
    return null
  }
  return entry.data
}
function cacheSet<T>(cache: Map<string, CacheEntry<T>>, key: string, data: T) {
  cache.set(key, { data, expire: Date.now() + CACHE_TTL })
}

// ---------- 等待百度地图 JS API 就绪（由 index.html 的 script 标签加载） ----------
export function loadBaiduMap(): Promise<void> {
  if (window.BMap) return Promise.resolve()
  if (window.__BAIDU_MAP_LOADING__) return window.__BAIDU_MAP_LOADING__

  window.__BAIDU_MAP_LOADING__ = new Promise<void>((resolve, reject) => {
    // 轮询等待 BMap 就绪（入口文件的 document.write 会按需加载 PlaceSearch/DrivingRoute 等模块）
    let attempts = 0
    const timer = window.setInterval(() => {
      attempts++
      if (window.BMap) {
        window.clearInterval(timer)
        resolve()
      } else if (attempts > 100) {
        // 10 秒超时
        window.clearInterval(timer)
        reject(new Error('百度地图 API 加载超时，请检查网络或 AK 配置'))
      }
    }, 100)
  })

  return window.__BAIDU_MAP_LOADING__
}

// ---------- 地点检索（带 24h 缓存） ----------
export interface BaiduPoi {
  uid: string
  name: string
  address: string
  lng: number
  lat: number
  city: string
  area?: string
  intro?: string
  phone?: string
  detailUrl?: string
  /** 评分（LocalSearch 可能直接返回） */
  rating?: number
  /** 人均消费（LocalSearch 可能直接返回） */
  price?: number
  /** 营业时间（LocalSearch 可能直接返回） */
  shopHours?: string
  /** 标签 */
  tag?: string
}

/**
 * 周边地点检索——走 SCF 代理调用百度 Web 服务 API（place/v2/search）。
 *
 * 与旧版 BMap.LocalSearch 相比：
 * - 不依赖浏览器端 JS API
 * - 严格按经纬度+半径搜索，城市由调用方传入
 * - scope=2 直接返回评分、人均、营业时间
 *
 * @param keyword 关键词（如"咖啡"、"火锅"）
 * @param centerLng 中心点经度
 * @param centerLat 中心点纬度
 * @param radius 搜索半径（米），默认 8000
 * @param maxResults 最多返回多少条结果
 * @param city 城市名（如"北京"），必填
 */
export async function searchNearby(
  keyword: string,
  centerLng: number,
  centerLat: number,
  radius = 8000,
  maxResults = 30,
  city = '',
  tag = '',
): Promise<BaiduPoi[]> {
  const cacheKey = JSON.stringify({ keyword, centerLng, centerLat, radius, maxResults, city, tag })
  const cached = cacheGet(placeCache, cacheKey)
  if (cached) return cached

  if (!city) {
    console.warn('[searchNearby] 未传入城市，跳过搜索')
    return []
  }

  const allPois: BaiduPoi[] = []
  const PAGE_SIZE = 20

  for (let pageNum = 0; allPois.length < maxResults; pageNum++) {
    const url =
      `${ROUTE_PROXY_URL}?action=search` +
      `&keyword=${encodeURIComponent(keyword)}` +
      (tag ? `&tag=${encodeURIComponent(tag)}` : '') +
      `&lng=${centerLng}&lat=${centerLat}` +
      `&radius=${radius}&city=${encodeURIComponent(city)}` +
      `&page_size=${PAGE_SIZE}&page_num=${pageNum}`

    try {
      const resp = await fetch(url)
      if (!resp.ok) break
      const data = await resp.json()
      if (data.status !== 0 || !data.results || data.results.length === 0) break

      for (const item of data.results) {
        if (allPois.length >= maxResults) break
        const detail = item.detail_info || {}
        allPois.push({
          uid: item.uid || `${item.name}_${allPois.length}`,
          name: item.name,
          address: item.address || '',
          lng: item.location?.lng,
          lat: item.location?.lat,
          city: item.city || city,
          area: item.area || item.district || '',
          intro: detail.description || item.description || '',
          phone: item.telephone,
          detailUrl: detail.detail_url,
          rating: detail.overall_rating ? Number(detail.overall_rating) : undefined,
          price: detail.price ? Number(detail.price) : undefined,
          shopHours: detail.shop_hours || undefined,
          tag: detail.tag || detail.classified_poi_tag || undefined,
        })
      }

      // 一页不足 PAGE_SIZE，说明没有更多结果了
      if (data.results.length < PAGE_SIZE) break
    } catch (e) {
      console.warn('[searchNearby] 搜索请求失败', e)
      break
    }
  }

  const result = allPois.slice(0, maxResults)
  cacheSet(placeCache, cacheKey, result)
  return result
}

/**
 * 判断一个 POI 是不是「光秃秃的行政区划本体」（单独一个 省/市/区/县/旗）。
 * 这种点只定在行政区中心、没有具体地址，会导致通勤和跨城判定失真，直接从出发点候选里滤掉。
 * 注意：像「北京市政府」「朝阳区XX大厦」这种名字带区/市、但本身是具体地点的，不受影响。
 */
export function isBareAdminRegion(name: string): boolean {
  const n = (name || '').trim()
  if (!n || n.length > 12) return false
  // 区/县/旗/省/自治州/盟/地区：真实门店几乎不会以这些结尾，可直接命中
  if (/(省|自治区|自治州|地区|盟|区|县|旗)$/.test(n)) return true
  // 市 结尾要排除 超市/夜市/城市/都市/集市 等非行政区划词
  if (/^[\u4e00-\u9fa5]{2,6}市$/.test(n) && !/(超市|夜市|城市|都市|集市|市区|市长)$/.test(n)) {
    return true
  }
  return false
}

/**
 * 城市内地点检索（用于出发点地址搜索）
 */
export async function searchPlace(
  keyword: string,
  city = '北京',
  pageSize = 10,
): Promise<BaiduPoi[]> {
  await loadBaiduMap()

  const cacheKey = JSON.stringify({ keyword, city, pageSize })
  const cached = cacheGet(placeCache, cacheKey)
  if (cached) return cached

  return new Promise((resolve, reject) => {
    // LocalSearch 构造函数：(城市名, 选项)
    const local = new window.BMap.LocalSearch(city, {
      pageCapacity: pageSize,
      onSearchComplete: (results: any) => {
        if (local.getStatus() !== 0) {
          reject(new Error('地点搜索失败'))
          return
        }
        const pois: BaiduPoi[] = []
        const num = results.getCurrentNumPois()
        for (let i = 0; i < num; i++) {
          const poi = results.getPoi(i)
          if (poi && poi.point && !isBareAdminRegion(poi.title || '')) {
            pois.push({
              uid: poi.uid || `${poi.name}_${i}`,
              name: poi.title,
              address: poi.address || '',
              lng: poi.point.lng,
              lat: poi.point.lat,
              city: poi.city || '',
            })
          }
        }
        cacheSet(placeCache, cacheKey, pois)
        resolve(pois)
      },
    })
    local.search(keyword)
  })
}

// ---------- POI 详情查询（评分/人均/营业时间/图片/标签） ----------
export interface PoiDetailResult {
  uid: string
  name: string
  rating?: number
  price?: number
  hours?: string
  phone?: string
  tags?: string[]
  images?: string[]
  intro?: string
  address?: string
  city?: string
  area?: string
}

const poiDetailCache = new Map<string, CacheEntry<PoiDetailResult | null>>()

/**
 * 根据 UID 查询 POI 详情（带 24h 缓存）
 * 优先用 BMap.PoiDetail，不可用时降级返回 null
 */
export async function getPoiDetail(uid: string): Promise<PoiDetailResult | null> {
  if (!uid) return null
  await loadBaiduMap()

  const cached = cacheGet(poiDetailCache, uid)
  if (cached !== undefined) return cached

  // 方式1：BMap.PoiDetail（百度地图 JS API 提供的 POI 详情类）
  if (window.BMap.PoiDetail) {
    try {
      const result = await new Promise<PoiDetailResult | null>((resolve) => {
        const poiDetail = new window.BMap.PoiDetail()
        const timer = window.setTimeout(() => resolve(null), 8000) // 8秒超时
        poiDetail.getDetailsByUid(uid, (data: any) => {
          window.clearTimeout(timer)
          if (!data) {
            resolve(null)
            return
          }
          resolve({
            uid: data.uid || uid,
            name: data.name || data.title || '',
            rating: data.rating ?? data.overall_rating ?? undefined,
            price: data.price ?? data.avgPrice ?? undefined,
            hours: data.shopHours || data.business_hours || data.shop_hours || undefined,
            phone: data.phone || data.telephone || undefined,
            tags: data.tag ? String(data.tag).split(',').filter(Boolean) : undefined,
            images: data.imageUrls || data.photos || undefined,
            intro: data.intro || data.description || undefined,
            address: data.address || undefined,
            city: data.city || undefined,
            area: data.district || data.area || undefined,
          })
        })
      })
      cacheSet(poiDetailCache, uid, result)
      return result
    } catch {
      // 方式1失败，继续尝试方式2
    }
  }

  // 方式2：LocalSearch.poiDetailSearch（回调式详情检索）
  if (typeof window.BMap.LocalSearch === 'function') {
    try {
      const result = await new Promise<PoiDetailResult | null>((resolve) => {
        const local = new window.BMap.LocalSearch('北京', {
          onGetPoiDetailResult: (data: any) => {
            if (!data) {
              resolve(null)
              return
            }
            resolve({
              uid: data.uid || uid,
              name: data.name || data.title || '',
              rating: data.rating ?? data.overall_rating ?? undefined,
              price: data.price ?? data.avgPrice ?? undefined,
              hours: data.shopHours || data.business_hours || data.shop_hours || undefined,
              phone: data.phone || data.telephone || undefined,
              tags: data.tag ? String(data.tag).split(',').filter(Boolean) : undefined,
              images: data.imageUrls || data.photos || undefined,
              intro: data.intro || data.description || undefined,
              address: data.address || undefined,
              city: data.city || undefined,
              area: data.district || data.area || undefined,
            })
          },
        })
        const timer = window.setTimeout(() => resolve(null), 8000)
        try {
          local.poiDetailSearch(uid)
        } catch {
          window.clearTimeout(timer)
          resolve(null)
        }
      })
      cacheSet(poiDetailCache, uid, result)
      return result
    } catch {
      // 方式2也失败，继续尝试方式3
    }
  }

  // 方式3：百度 Place API（Web服务）JSONP，scope=2 返回深度信息（评分/人均/营业时间/图片）
  const ak = window.__BAIDU_MAP_AK__
  if (ak) {
    try {
      const result = await new Promise<PoiDetailResult | null>((resolve) => {
        const callbackName = `__baidu_poi_detail_${Date.now()}_${Math.random().toString(36).slice(2)}`
        const script = document.createElement('script')
        const timer = window.setTimeout(() => {
          cleanup()
          resolve(null)
        }, 8000)

        function cleanup() {
          window.clearTimeout(timer)
          delete (window as any)[callbackName]
          if (script.parentNode) script.parentNode.removeChild(script)
        }

        ;(window as any)[callbackName] = (data: any) => {
          cleanup()
          if (!data || data.status !== 0 || !data.result) {
            resolve(null)
            return
          }
          const r = data.result
          const detailInfo = r.detail_info || {}
          resolve({
            uid: r.uid || uid,
            name: r.name || '',
            rating: detailInfo.overall_rating ?? r.rating ?? undefined,
            price: detailInfo.price ?? r.price ?? undefined,
            hours: detailInfo.shop_hours ?? r.shop_hours ?? undefined,
            phone: r.telephone ?? detailInfo.telephone ?? undefined,
            tags: r.detail_info?.classified_poi_tag ? String(r.detail_info.classified_poi_tag).split(',').filter(Boolean) : undefined,
            images: detailInfo.photos?.map((p: any) => p.url) || undefined,
            intro: r.detail_info?.di_review ?? r.intro ?? undefined,
            address: r.address ?? undefined,
            city: r.city ?? undefined,
            area: r.district ?? r.area ?? undefined,
          })
        }

        script.src = `https://api.map.baidu.com/place/v2/detail?uid=${encodeURIComponent(uid)}&ak=${ak}&output=json&scope=2&callback=${callbackName}`
        script.onerror = () => {
          cleanup()
          resolve(null)
        }
        document.head.appendChild(script)
      })
      cacheSet(poiDetailCache, uid, result)
      return result
    } catch {
      // 方式3也失败
    }
  }

  cacheSet(poiDetailCache, uid, null)
  return null
}

// ---------- 路线规划（带 24h 缓存 + 并发控制） ----------
const routeQueue: Array<() => void> = []
let routeActive = 0

function acquireRouteSlot(): Promise<void> {
  if (routeActive < ROUTE_CONCURRENCY) {
    routeActive++
    return Promise.resolve()
  }
  return new Promise((resolve) => {
    routeQueue.push(resolve)
  })
}
function releaseRouteSlot() {
  routeActive--
  const next = routeQueue.shift()
  if (next) {
    routeActive++
    next()
  }
}

/** 出行方式 -> 百度路线规划服务构造器 */
function getRouteClass(mode: TravelMode): any {
  switch (mode) {
    case 'drive':
    case 'taxi':
      return window.BMap.DrivingRoute
    case 'transit':
      return window.BMap.TransitRoute
    case 'walk':
      return window.BMap.WalkingRoute
    case 'bike':
      return window.BMap.RidingRoute || window.BMap.WalkingRoute // 骑行 API 不可用时降级步行
    default:
      return window.BMap.DrivingRoute
  }
}

/**
 * 路线规划（单程）——走 SCF 代理调用百度 Web 服务 API。
 *
 * 失败时直接 throw，不做直线距离估算兜底。由调用方决定如何处理。
 *
 * @returns { minutes: 分钟数, fare: 费用（元） }
 */
export async function planRoute(
  fromLng: number,
  fromLat: number,
  toLng: number,
  toLat: number,
  mode: TravelMode,
  city = '北京',
): Promise<{ minutes: number; fare: number }> {
  const cacheKey = JSON.stringify({ fromLng, fromLat, toLng, toLat, mode, city })
  const cached = cacheGet(routeCache, cacheKey)
  if (cached) return cached

  await acquireRouteSlot()

  try {
    // 出行方式映射到 Web 服务 API 的 mode
    const apiMode =
      mode === 'transit' ? 'transit'
      : mode === 'drive' || mode === 'taxi' ? 'driving'
      : mode === 'walk' ? 'walking'
      : 'riding' // bike

    const url =
      `${ROUTE_PROXY_URL}?mode=${apiMode}` +
      `&origin_lng=${fromLng}&origin_lat=${fromLat}` +
      `&dest_lng=${toLng}&dest_lat=${toLat}` +
      `&city=${encodeURIComponent(city)}`

    const controller = new AbortController()
    const timer = window.setTimeout(() => controller.abort(), 45000)

    const resp = await fetch(url, { signal: controller.signal })
    window.clearTimeout(timer)

    if (!resp.ok) {
      throw new Error(`路线规划请求失败（HTTP ${resp.status}）`)
    }

    const data = await resp.json()

    if (data.status !== 0) {
      const errMsg = data.message || `百度API错误码 ${data.status}`
      throw new Error(errMsg)
    }
    if (!data.result || !data.result.routes || data.result.routes.length === 0) {
      throw new Error('未找到可用路线')
    }

    const route = data.result.routes[0]
    const durationSec = route.duration || 0
    const distanceM = route.distance || 0

    let fare = 0
    if (mode === 'transit' && typeof route.price === 'number') {
      fare = route.price
    } else {
      fare = calcFare(mode, distanceM / 1000)
    }

    const result = {
      minutes: Math.max(1, Math.round(durationSec / 60)),
      fare,
    }
    releaseRouteSlot()
    cacheSet(routeCache, cacheKey, result)
    return result
  } catch (e) {
    releaseRouteSlot()
    throw e
  }
}

/** 费用计算（百度路线规划不直接返费用，按规则计算） */
function calcFare(mode: TravelMode, km: number): number {
  if (mode === 'transit') return Math.max(3, Math.round(3 + Math.max(0, km - 6) / 2))
  if (mode === 'taxi') return Math.round(13 + Math.max(0, km - 3) * 2.3)
  return 0 // 驾车/骑行/步行不计费
}

// ---------- 地理编码（地址 -> 经纬度） ----------
const forwardGeocodeCache = new Map<string, CacheEntry<{ lng: number; lat: number }>>()
export async function geocode(address: string, city = '北京'): Promise<{ lng: number; lat: number } | null> {
  await loadBaiduMap()

  const cacheKey = JSON.stringify({ address, city })
  const cached = cacheGet(forwardGeocodeCache, cacheKey)
  if (cached) return cached

  return new Promise((resolve) => {
    const geocoder = new window.BMap.Geocoder()
    geocoder.getPoint(address, (point: any) => {
      if (point) {
        const result = { lng: point.lng, lat: point.lat }
        cacheSet(forwardGeocodeCache, cacheKey, result)
        resolve(result)
      } else {
        resolve(null)
      }
    }, city)
  })
}

// ---------- 逆地理编码（经纬度 -> 地址） ----------
/** 逆地理编码——走 SCF 代理调用百度 Web 服务 API，不依赖 BMap。 */
export async function reverseGeocode(lng: number, lat: number): Promise<{ address: string; city: string } | null> {
  const cacheKey = JSON.stringify({ lng, lat })
  const cached = cacheGet(geocodeCache, cacheKey)
  if (cached) return cached

  try {
    const url = `${ROUTE_PROXY_URL}?action=reverse_geocode&lng=${lng}&lat=${lat}`
    const resp = await fetch(url)
    if (!resp.ok) return null
    const data = await resp.json()
    if (data.status !== 0 || !data.result) return null
    const ac = data.result.address_component || data.result.addressComponent || {}
    // 直辖市（北京/上海/天津/重庆）address_component.city 为空，城市名在 province 里；
    // 非直辖市正常用 city。统一去掉「省/市」后缀，便于跨城比较。
    const rawCity = ac.city || ac.province || ''
    const normalizedCity = rawCity.replace(/(省|市|壮族自治区|回族自治区|维吾尔自治区|特别行政区)$/g, '').trim()
    const result = {
      address: data.result.formatted_address || data.result.address || '',
      city: normalizedCity,
    }
    cacheSet(geocodeCache, cacheKey, result)
    return result
  } catch {
    return null
  }
}

// ---------- 定位（当前位置） ----------
// 重要：定位必须健壮，任何失败都不能导致页面崩溃
// 优先级：浏览器原生定位 > 百度地图定位 > 返回null（由调用方降级到模拟位置）
export async function getCurrentLocation(): Promise<{ lng: number; lat: number; address: string } | null> {
  // 总超时 10 秒，无论哪种定位方式都不能无限挂起
  const totalTimeout = new Promise<null>((resolve) =>
    setTimeout(() => {
      console.warn('[getCurrentLocation] 总超时，返回 null')
      resolve(null)
    }, 10000),
  )

  const locationPromise = (async () => {
    // 方式1：优先用浏览器原生 geolocation（不依赖百度API，最可靠）
    if (navigator.geolocation) {
      try {
        const pos = await new Promise<GeolocationPosition | null>((resolve) => {
          navigator.geolocation.getCurrentPosition(
            (p) => resolve(p),
            () => resolve(null), // 用户拒绝或超时，降级
            { timeout: 6000, maximumAge: 300000, enableHighAccuracy: false },
          )
        })
        if (pos && pos.coords) {
          // 浏览器原生定位返回 WGS84，转成百度 BD09 坐标
          const bd09 = wgs84ToBd09(pos.coords.longitude, pos.coords.latitude)
          let address = '当前位置'
          // 走代理逆地理编码获取地址（不依赖 BMap）
          try {
            const addr = await reverseGeocode(bd09.lng, bd09.lat)
            if (addr?.address) address = addr.address
          } catch {
            /* 逆地理编码失败，用默认地址 */
          }
          return {
            lng: bd09.lng,
            lat: bd09.lat,
            address,
          }
        }
      } catch {
        /* 浏览器定位失败，继续尝试百度定位 */
      }
    }

    // 方式2：百度地图定位（需要百度API加载成功）
    try {
      if (!window.BMap || !window.BMap.Geolocation) {
        return null
      }
      const result = await new Promise<{ lng: number; lat: number; address: string } | null>((resolve) => {
        const geolocation = new window.BMap.Geolocation()
        // 百度定位加 6 秒超时
        const timer = window.setTimeout(() => {
          console.warn('[getCurrentLocation] 百度定位超时')
          resolve(null)
        }, 6000)
        geolocation.getCurrentPosition((r: any) => {
          window.clearTimeout(timer)
          if (geolocation.getStatus() === 0 && r?.point) {
            resolve({
              lng: r.point.lng,
              lat: r.point.lat,
              address: r.address || '当前位置',
            })
          } else {
            resolve(null)
          }
        })
      })
      return result
    } catch {
      return null
    }
  })()

  // 竞速：定位结果 vs 总超时
  return Promise.race([locationPromise, totalTimeout])
}

// ---------- AI 生成店铺推荐文案（走 SCF 代理调用豆包，不消耗百度额度） ----------
const aiIntroCacheKey = (shop: { uid?: string; name: string; address: string; lng: number; lat: number }) =>
  `ai_intro_v4_${shop.uid || `${shop.name}_${shop.address || `${shop.lng.toFixed(5)}_${shop.lat.toFixed(5)}`}`}`

/** Old saved shops sometimes put the complete street address in intro. */
function aiIntroDescription(intro: string, address: string): string {
  const value = intro.trim()
  if (!value || value === address.trim()) return ''
  if (/^(?:北京市|上海市|天津市|重庆市|[^\s，。]{2,12}(?:省|市|区|县))/.test(value) &&
      /(?:路|街|道|巷|号|楼|层|大厦|广场|小区)/.test(value) && !/[。！？\n]/.test(value)) return ''
  return value
}

/**
 * 请求 AI 生成店铺推荐文案（推荐理由/招牌必点/周边逛吃/避坑提醒）
 * 前端 localStorage 缓存 7 天，同一店铺不重复请求
 */
export async function getAiShopIntro(shop: {
  uid?: string
  name: string
  address: string
  category: string
  rating: number
  perCapita: number
  tags?: string[]
  hours?: string
  intro?: string
  lng: number
  lat: number
  /** 碰面背景：人数/平均通勤/最远/时间差（分钟）/城市 */
  peopleCount?: number
  avgMinutes?: number
  maxMinutes?: number
  fairnessMinutes?: number
  city?: string
}): Promise<string | null> {
  const cacheKey = aiIntroCacheKey(shop)
  try {
    const cached = localStorage.getItem(cacheKey)
    if (cached) {
      const entry = JSON.parse(cached)
      if (Date.now() < entry.expire) return entry.text
    }
  } catch {
    /* localStorage 不可用时忽略 */
  }

  try {
    const params = new URLSearchParams({
      action: 'ai_intro',
      name: shop.name,
      address: shop.address || '',
      category: shop.category || '',
      rating: String(shop.rating || ''),
      per_capita: String(shop.perCapita || ''),
      tags: (shop.tags || []).join(','),
      hours: shop.hours || '',
      intro: aiIntroDescription(shop.intro || '', shop.address || ''),
      people: shop.peopleCount != null ? String(shop.peopleCount) : '',
      avg_minutes: shop.avgMinutes != null ? String(shop.avgMinutes) : '',
      max_minutes: shop.maxMinutes != null ? String(shop.maxMinutes) : '',
      fairness_minutes: shop.fairnessMinutes != null ? String(shop.fairnessMinutes) : '',
      city: shop.city || '',
    })
    const url = `${ROUTE_PROXY_URL}?${params.toString()}`
    const controller = new AbortController()
    const timer = window.setTimeout(() => controller.abort(), 45000)
    const resp = await fetch(url, { signal: controller.signal })
    window.clearTimeout(timer)
    if (!resp.ok) return null
    const data = await resp.json()
    const text = data?.text
    if (!text) return null

    // 缓存 7 天
    try {
      localStorage.setItem(cacheKey, JSON.stringify({
        text,
        expire: Date.now() + 7 * 24 * 60 * 60 * 1000,
      }))
    } catch {
      /* 存储满了忽略 */
    }
    return text
  } catch {
    return null
  }
}
