// ============================================================
// 真实 API / Mock 共用的店铺筛选管线：
// - 从 UI 品类配置生成子品类召回分支
// - 品类配额合并与 POI 去重
// - 对全部召回 POI 做低成本地理粗排
// - 只取粗排 Top N 进入真实路线计算（不设 reserve / challenger，不按合格数提前停止）
// - 系统硬过滤（时间差 > 60 分钟淘汰）→ 加权精排 → 品牌/品类多样性软重排
// - 不固定输出数量，剩多少展示多少
// ============================================================

import type { CategoryValue, Shop, ShopWithCommute, TravelPoint } from '../types'
import { SHOP_PIPELINE_CONFIG } from '../config'
import { CATEGORY_TREE } from '../mock/constants'

export interface RecallBranch {
  subcategory: string
  keyword: string
  tag: string
}

export interface RecallGroup<T> {
  subcategory: string
  items: T[]
}

export interface RecalledCandidate<T> {
  item: T
  subcategory: string
  recallIndex: number
}

export interface GeographicMetrics {
  averageDistanceKm: number
  maxDistanceKm: number
  distanceSpreadKm: number
}

/** UI 二级品类 -> 百度地点检索 query（与二级品类名强相关）。 */
const SUBCATEGORY_SEARCH_KEYWORDS: Record<string, string> = {
  地方菜: '地方菜',
  火锅: '火锅',
  烧烤烤肉: '烧烤烤肉',
  自助餐: '自助餐',
  东南亚菜: '东南亚菜',
  日韩料理: '日韩料理',
  西餐: '西餐',
  海鲜河鲜: '海鲜河鲜',
  快餐小吃: '快餐小吃',
  咖啡馆: '咖啡馆',
  奶茶店: '奶茶店',
  冰激凌店: '冰激凌店',
  茶馆: '茶馆',
  烘焙面包店: '烘焙面包店',
  '推理/桌游': '桌游',
  酒吧清吧: '酒吧清吧',
  'DIY手工坊': 'DIY',
  健身房: '健身房',
  电影: '电影院',
  球类运动: '球类运动',
  洗浴按摩: '洗浴按摩',
  武术搏击: '武术搏击',
  KTV: 'KTV',
  零食店: '零食店',
  生鲜店: '生鲜店',
  便利店: '便利店',
  大型超市: '大型超市',
}

/** UI 二级品类 -> 百度 POI 分类 tag（大类偏好，辅助 query 检索）。 */
const SUBCATEGORY_TAG: Record<string, string> = {
  地方菜: '美食',
  火锅: '美食',
  烧烤烤肉: '美食',
  自助餐: '美食',
  东南亚菜: '美食',
  日韩料理: '美食',
  西餐: '美食',
  海鲜河鲜: '美食',
  快餐小吃: '美食',
  咖啡馆: '美食',
  奶茶店: '美食',
  冰激凌店: '美食',
  茶馆: '美食',
  烘焙面包店: '美食',
  '推理/桌游': '休闲娱乐',
  酒吧清吧: '休闲娱乐',
  'DIY手工坊': '休闲娱乐',
  健身房: '运动健身',
  电影: '休闲娱乐',
  球类运动: '运动健身',
  洗浴按摩: '休闲娱乐',
  武术搏击: '运动健身',
  KTV: '休闲娱乐',
  零食店: '购物',
  生鲜店: '购物',
  便利店: '购物',
  大型超市: '购物',
}

/** 子品类排除词表：召回后过滤掉名字里含这些词的 POI，防止关键词过宽串到其他品类。 */
const SUBCATEGORY_EXCLUDE: Record<string, string[]> = {
  'DIY手工坊': [
    // 餐饮类
    '面', '饭', '汉堡', '奶茶', '咖啡', '面包', '蛋糕', '甜品', '烘焙', '小吃',
    '快餐', '餐厅', '饭店', '面馆', '米粉', '粥', '烧烤', '火锅', '烤肉',
    '炸鸡', '披萨', '意面', '牛排', '水饺', '饺子', '包子', '鲜包', '馄饨',
    '点心', '糕点', '堡', '串', '米线', '沙县', '麻辣烫', '冒菜', '烤鱼',
    '小龙虾', '串', '卤味', '鸭脖', '甜品', '糖水', '冰激',
    // 儿童/亲子/乐园类
    '儿童', '亲子', '乐园', '游乐场', '玩具', '母婴', '童装',
  ],
  '茶馆': [
    '食堂', '餐厅', '饭店', '酒楼', '餐馆', '菜馆', '小吃', '快餐', '面馆',
    '火锅', '烧烤', '烤肉', '奶茶', '咖啡', '汉堡', '披萨', '炸鸡', '串串',
    '麻辣烫', '冒菜', '烤鱼', '小龙虾', '卤味', '鸭脖', '甜品', '蛋糕',
    '面包', '烘焙', '早餐', '便当', '盒饭', '大排档', '农家乐', '私房菜',
    '家常菜', '川菜', '粤菜', '湘菜', '鲁菜', '东北菜', '西北菜', '日料',
    '韩餐', '西餐', '牛排', '意面', '寿司', '包子', '饺子', '馄饨', '米粉',
    '米线', '粥', '烤鸭', '炒菜', '面', '饭', '堡',
  ],
}

/** 判断一个 POI 名称是否命中子品类排除词。 */
export function isExcludedBySubcategory(name: string, subcategory: string): boolean {
  const excludes = SUBCATEGORY_EXCLUDE[subcategory]
  if (!excludes || excludes.length === 0) return false
  const lower = name.toLowerCase()
  return excludes.some((word) => lower.includes(word.toLowerCase()))
}

/**
 * 「地方菜」是 App 自造的归类名，百度上几乎没有餐馆用「地方菜」做店名/标签。
 * 拆成真实存在的菜系分头召回，再交给现有去重/轮转合并管线。
 */
const LOCAL_CUISINE_KEYWORDS = [
  '川菜', '北京菜', '西北菜', '新疆菜', '东北菜',
  '湘菜', '粤菜', '云贵菜', '江浙菜',
]

/**
 * 二级品类 -> 多关键词召回表。
 * 这些品类单用一个泛词（如「零食店」「大型超市」「球类运动」）搜不到真实门店，
 * 改成「品牌词 + 具体业态词」并行召回，再由现有去重/轮转合并。
 */
const SUBCATEGORY_EXTRA_KEYWORDS: Record<string, string[]> = {
  零食店: ['赵一鸣', '好想来', '好特卖', '零食很忙', '良品铺子', '来伊份', '零食折扣店', '零食店', '零食'],
  生鲜店: ['盒马', '七鲜', '小象超市', '钱大妈', '生鲜超市', '生鲜店'],
  大型超市: ['沃尔玛', '山姆', '物美', '永辉超市', '大润发', '家乐福', '开市客', '华联', '大型超市', '超市'],
  球类运动: ['羽毛球馆', '篮球馆', '乒乓球馆', '网球馆', '台球厅', '足球场'],
  '推理/桌游': ['桌游', '桌游吧', '剧本杀', '密室逃脱'],
}

/**
 * 直接读取现有 CATEGORY_TREE 生成真实召回分支。
 * 「全部分类」拆成 UI 中已有的各二级品类，不再拼成一个组合关键词。
 */
export function getRecallBranches(category: CategoryValue | null): RecallBranch[] {
  if (!category) return []
  if (category.primary === 'mall') {
    return [{ subcategory: '', keyword: '购物中心', tag: '购物' }]
  }

  const node = CATEGORY_TREE.find((item) => item.key === category.primary)
  const isAll = !category.secondary || category.secondary === '全部分类'
  const subcategories = isAll
    ? (node?.children || []).filter((item) => item !== '全部分类')
    : [category.secondary]

  // 对旧缓存里的未知品类值保持可用：没有树节点时仍按当前二级名称检索。
  if (subcategories.length === 0 && category.secondary) {
    subcategories.push(category.secondary)
  }

  const branches: RecallBranch[] = subcategories.map((subcategory) => ({
    subcategory,
    keyword: SUBCATEGORY_SEARCH_KEYWORDS[subcategory] || subcategory,
    tag: SUBCATEGORY_TAG[subcategory] || '',
  }))

  // 「地方菜」及其它需多关键词召回的品类，拆成多路并行；下游按同名同坐标去重，
  // 仍归为各自的二级品类，不影响 UI 展示。
  const expanded: RecallBranch[] = []
  for (const b of branches) {
    if (b.subcategory === '地方菜') {
      for (const kw of LOCAL_CUISINE_KEYWORDS) {
        expanded.push({ subcategory: '地方菜', keyword: kw, tag: '美食' })
      }
    } else if (SUBCATEGORY_EXTRA_KEYWORDS[b.subcategory]) {
      for (const kw of SUBCATEGORY_EXTRA_KEYWORDS[b.subcategory]) {
        expanded.push({ subcategory: b.subcategory, keyword: kw, tag: b.tag || SUBCATEGORY_TAG[b.subcategory] || '' })
      }
    } else {
      expanded.push(b)
    }
  }
  return expanded
}

/** 子品类数量 -> 单类基础配额与候选池目标数。 */
export function getCandidateQuota(categoryCount: number): { perCategory: number; target: number } {
  if (categoryCount <= 0) return { perCategory: 0, target: 0 }
  const perCategory =
    categoryCount === 1 ? 30
      : categoryCount === 2 ? 15
        : categoryCount === 3 ? 10
          : categoryCount === 4 ? 8
            : Math.max(3, Math.ceil(32 / categoryCount))
  const target = Math.min(
    SHOP_PIPELINE_CONFIG.candidateMax,
    Math.max(SHOP_PIPELINE_CONFIG.candidateMin, perCategory * categoryCount),
  )
  return { perCategory, target }
}

/**
 * 每个子品类实际向百度请求的数量。基础配额之外保留少量溢出结果，
 * 供其他子品类结果不足时补位，但不会扩大最终候选池目标。
 */
export function getRecallFetchLimit(categoryCount: number): number {
  const { perCategory, target } = getCandidateQuota(categoryCount)
  if (categoryCount <= 2) return target
  return Math.min(20, Math.max(perCategory + 6, perCategory * 2))
}

/**
 * 先按子品类配额轮转取数，再用各类溢出结果轮转补位。
 * 去重规则由调用方传入，因此真实 POI 可继续沿用「同名同坐标」口径。
 */
export function mergeRecallGroups<T>(
  groups: RecallGroup<T>[],
  keyOf: (item: T) => string,
): RecalledCandidate<T>[] {
  const { perCategory, target } = getCandidateQuota(groups.length)
  if (target === 0) return []

  const cursors = groups.map(() => 0)
  const counts = groups.map(() => 0)
  const seen = new Set<string>()
  const selected: RecalledCandidate<T>[] = []

  // 溢出补位阶段单个子品类的上限：配额的 1.5 倍，防止结果天然多的品类（如健身房）挤占其他品类
  const overflowCap = Math.ceil(perCategory * 1.5)

  const takeNextUnique = (groupIndex: number): boolean => {
    const group = groups[groupIndex]
    while (cursors[groupIndex] < group.items.length) {
      const item = group.items[cursors[groupIndex]++]
      const key = keyOf(item)
      if (seen.has(key)) continue
      seen.add(key)
      selected.push({ item, subcategory: group.subcategory, recallIndex: selected.length })
      counts[groupIndex]++
      return true
    }
    return false
  }

  // 配额阶段采用轮转，避免一个子品类天然占据候选顺序前部。
  for (let round = 0; round < perCategory && selected.length < target; round++) {
    for (let gi = 0; gi < groups.length && selected.length < target; gi++) {
      takeNextUnique(gi)
    }
  }

  // 某些子品类不足时，其他类别的溢出结果继续轮转补位。
  // 但每个子品类在溢出阶段受 overflowCap 限制，避免一家独大。
  let madeProgress = true
  while (selected.length < target && madeProgress) {
    madeProgress = false
    for (let gi = 0; gi < groups.length && selected.length < target; gi++) {
      if (counts[gi] >= overflowCap) continue
      if (takeNextUnique(gi)) madeProgress = true
    }
  }

  return selected
}

/** 哈弗辛直线距离（公里），只用于不消耗路线 API 的候选粗排。 */
export function haversineKm(a: Pick<TravelPoint, 'lng' | 'lat'>, b: Pick<Shop, 'lng' | 'lat'>): number {
  const radiusKm = 6371
  const dLat = ((b.lat - a.lat) * Math.PI) / 180
  const dLng = ((b.lng - a.lng) * Math.PI) / 180
  const lat1 = (a.lat * Math.PI) / 180
  const lat2 = (b.lat * Math.PI) / 180
  const value =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2
  return radiusKm * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value))
}

export function getGeographicMetrics(shop: Shop, points: TravelPoint[]): GeographicMetrics {
  const distances = points.map((point) => haversineKm(point, shop))
  if (distances.length === 0) {
    return { averageDistanceKm: Infinity, maxDistanceKm: Infinity, distanceSpreadKm: Infinity }
  }
  const maxDistanceKm = Math.max(...distances)
  const minDistanceKm = Math.min(...distances)
  return {
    averageDistanceKm: distances.reduce((sum, distance) => sum + distance, 0) / distances.length,
    maxDistanceKm,
    distanceSpreadKm: maxDistanceKm - minDistanceKm,
  }
}

/**
 * 地理粗排：用直线距离的三个指标加权打分，和精排方向一致但权重不同。
 *   score = 2.0 × 平均距离 + 1.0 × 最远距离 + 0.5 × 距离差
 * 分数越低排越前。平均距离主导，最远距离惩罚"最惨的人"，距离差微调分散度。
 */
export function rankByGeographicFit(shops: Shop[], points: TravelPoint[]): Shop[] {
  return shops
    .map((shop, index) => ({ shop, index, metrics: getGeographicMetrics(shop, points) }))
    .sort((a, b) => {
      const scoreA = 2.0 * a.metrics.averageDistanceKm + 1.0 * a.metrics.maxDistanceKm + 0.5 * a.metrics.distanceSpreadKm
      const scoreB = 2.0 * b.metrics.averageDistanceKm + 1.0 * b.metrics.maxDistanceKm + 0.5 * b.metrics.distanceSpreadKm
      return scoreA - scoreB || a.index - b.index
    })
    .map(({ shop }) => shop)
}

/**
 * 管线阶段，供加载页展示「进度条 + 阶段性文案」。
 * 不再向 UI 暴露「已找到 X / 20 家」这类候选数量反馈。
 */
export type PipelineStage = 'recall' | 'routing' | 'finishing'

export interface PipelineProgress {
  stage: PipelineStage
  /** 已完成真实通勤计算的店铺数 */
  routed: number
  /** 进入真实通勤计算的店铺总数（粗排 Top N） */
  total: number
}

export function maxCommuteOf(shop: ShopWithCommute): number {
  return Math.max(...shop.commutes.map((commute) => commute.minutes))
}

/**
 * 系统硬过滤：任一方时间差（fairness）超过 hardFairnessMinutes 直接淘汰。
 * 这是固定系统规则，不随用户在表单里设置的时间差变化；用户自己的时间差由列表前端筛选承担。
 */
export function passesHardFairness(shop: ShopWithCommute): boolean {
  return shop.fairness <= SHOP_PIPELINE_CONFIG.hardFairnessMinutes
}

/**
 * 加权综合评分排序：
 *   score = wAvg × avg + wMax × maxCommute + wFair × fairness
 * 分数越低排越前；评分相同时按原召回顺序保持稳定。
 *
 * 权重集中在 SHOP_PIPELINE_CONFIG.rankingWeights，默认：
 *   avg=1.0, maxCommute=0.2, fairness=3.0
 * 时间差每多 1 分钟 ≈ 平均通勤多 3 分钟，保证平均相近时公平的店排前面。
 */
export function rankEligibleShops(shops: ShopWithCommute[]): ShopWithCommute[] {
  const { avg: wAvg, maxCommute: wMax, fairness: wFair } =
    SHOP_PIPELINE_CONFIG.rankingWeights

  const scoreOf = (shop: ShopWithCommute): number =>
    wAvg * shop.avg + wMax * maxCommuteOf(shop) + wFair * shop.fairness

  return shops
    .map((shop, index) => ({ shop, index, score: scoreOf(shop) }))
    .sort((a, b) => a.score - b.score || a.index - b.index)
    .map(({ shop }) => shop)
}

/** 从 POI 名称中提取用于软去重排的品牌键，不作为硬过滤依据。 */
export function inferBrandKey(name: string): string {
  const base = name
    .normalize('NFKC')
    .split(/[（(【\[]/, 1)[0]
    .replace(/(?:旗舰店|概念店|社区店|分店|总店|门店|店)$/u, '')
    .replace(/(?:臻选|旗舰|概念)$/u, '')
    .replace(/(?:coffee|cafe|咖啡馆|咖啡|茶饮|奶茶店|奶茶|餐厅)$/iu, '')
    .replace(/[\s·•_\-—]+/g, '')
    .toLowerCase()
  return base || name.normalize('NFKC').replace(/\s+/g, '').toLowerCase()
}

/**
 * 质量排序完成后的软重排（作用于「系统硬过滤之后」的全部剩余候选）：
 * 1) 同品牌优先不超过 3 家；
 * 2) 「全部分类」时，优先让单一子品类不超过剩余结果的 35%；
 * 3) 被延后的候选按原精排顺序整体排在后面，不丢弃、不固定输出数量。
 */
export function diversityRerank(
  sorted: ShopWithCommute[],
  diversifySubcategories: boolean,
): ShopWithCommute[] {
  // 不再只看前 20 名：对硬过滤后的全部剩余候选做多样性偏好。
  const qualityPool = sorted
  const availableSubcategories = new Set(qualityPool.map((shop) => shop.sub).filter(Boolean))
  const shouldDiversifySubcategories = diversifySubcategories && availableSubcategories.size > 1
  const preferredSubcategoryLimit = Math.max(
    1,
    Math.ceil(qualityPool.length * SHOP_PIPELINE_CONFIG.preferredSubcategoryShare),
  )
  const brandCounts = new Map<string, number>()
  const subcategoryCounts = new Map<string, number>()
  const preferred: ShopWithCommute[] = []
  const deferred: ShopWithCommute[] = []

  for (const shop of qualityPool) {
    const brand = inferBrandKey(shop.name)
    const brandOk = (brandCounts.get(brand) || 0) < SHOP_PIPELINE_CONFIG.preferredBrandLimit
    const subcategoryOk =
      !shouldDiversifySubcategories ||
      !shop.sub ||
      (subcategoryCounts.get(shop.sub) || 0) < preferredSubcategoryLimit

    if (brandOk && subcategoryOk) {
      preferred.push(shop)
      brandCounts.set(brand, (brandCounts.get(brand) || 0) + 1)
      if (shop.sub) subcategoryCounts.set(shop.sub, (subcategoryCounts.get(shop.sub) || 0) + 1)
    } else {
      deferred.push(shop)
    }
  }

  // 软约束：不放宽硬过滤，也不丢弃任何候选；剩多少就展示多少。
  return [...preferred, ...deferred]
}

/**
 * 对给定候选「全部」执行真实通勤计算：
 * - 不设置 reserve / challenger；
 * - 不根据已合格数量提前停止；
 * - 并发保护由 baiduMap 内部的「最大 3 路并发」承担，这里直接并行调度全部候选。
 *
 * onProgress 只回报完成数/总数，用于进度条；不回报合格数。
 */
export async function computeAllRoutes<T, R>(
  candidates: T[],
  computeItem: (candidate: T, index: number) => Promise<R>,
  onProgress?: (done: number, total: number) => void,
): Promise<R[]> {
  onProgress?.(0, candidates.length)
  let done = 0
  const results = await Promise.all(
    candidates.map(async (candidate, index) => {
      const result = await computeItem(candidate, index)
      done += 1
      onProgress?.(done, candidates.length)
      return result
    }),
  )
  return results
}
