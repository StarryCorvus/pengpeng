// 展示格式化工具

import type { TravelMode, TravelPoint } from '../types'

/**
 * 出发点显示名称（旧版，仅在需要「我/TA」文案时使用）：
 * - 第 1 个（index=0）→ 我
 * - 第 2 个及以后 → 碰友1、碰友2...
 */
export function pointLabel(index: number): string {
  return index === 0 ? '我' : `碰友${index}`
}

/**
 * 碰友昵称：优先用用户自定义的 nickname，否则按位置给默认名。
 * - 第 1 个点（自己）默认「我」
 * - 其余点默认「碰友1」「碰友2」…
 */
export function pointNickname(point: TravelPoint | undefined, index: number): string {
  if (point?.nickname && point.nickname.trim()) return point.nickname.trim()
  if (index === 0) return '我'
  // 默认名按创建序号，删除中间朋友后剩余朋友不重排
  return `碰友${point?.friendSeq ?? index}`
}

/** 分钟 -> "约 32 分钟" */
export function fmtMinutes(min: number): string {
  return `约 ${Math.max(1, Math.round(min))} 分钟`
}

/** 分钟 -> "约32分钟"（紧凑） */
export function fmtMinutesShort(min: number): string {
  return `约${Math.max(1, Math.round(min))}分钟`
}

/** 评分保留 1 位小数，0 显示「暂无」 */
export function fmtRating(r: number): string {
  if (!r || r <= 0) return '暂无'
  return r.toFixed(1)
}

/** 人均消费：0 显示「暂无」，其余显示 ¥N */
export function fmtPrice(p: number): string {
  if (!p || p <= 0) return '暂无'
  return `¥${p}`
}

/** 路费展示：0 元显示为「免费」，其余显示 ¥N */
export function fmtFare(fare: number): string {
  return fare > 0 ? `¥${fare}` : '免费'
}

/** 通勤信息（带去重计数） */
export interface CommuteWithCount {
  pointId: string
  pointName: string
  mode: TravelMode
  minutes: number
  fare: number
  /** 相同出发点+出行方式的合并人数（1=无重复） */
  count: number
}

/**
 * 通勤信息去重：按「出发点名称 + 出行方式」合并重复项。
 * 例如两个出发点都是「国贸」+「公共交通」，合并为一条并标注 count=2。
 */
export function dedupeCommutes(
  commutes: { pointId: string; pointName: string; mode: TravelMode; minutes: number; fare: number }[],
): CommuteWithCount[] {
  const map = new Map<string, CommuteWithCount>()
  for (const c of commutes) {
    const key = `${c.pointName}__${c.mode}`
    const existing = map.get(key)
    if (existing) {
      existing.count += 1
    } else {
      map.set(key, { ...c, count: 1 })
    }
  }
  return Array.from(map.values())
}
