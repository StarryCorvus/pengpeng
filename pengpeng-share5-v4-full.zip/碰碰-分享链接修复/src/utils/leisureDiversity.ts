import type { CategoryValue, Shop, ShopWithCommute } from '../types'
import { CATEGORY_TREE } from '../mock/constants'
import { SHOP_PIPELINE_CONFIG } from '../config'
import { getCandidateQuota, getRecallBranches, maxCommuteOf, type RecallGroup } from './resultPipeline'

// Keys and their deterministic order come from the existing category tree.
const leisure = CATEGORY_TREE.find(node => node.key === 'fun')!
export const leisureSubcategories = leisure.children.slice(1)
export function isLeisureAll(category: CategoryValue | null): boolean {
  return category?.primary === leisure.key && (!category.secondary || category.secondary === leisure.children[0])
}

export function leisureRecallBranches(category: CategoryValue | null) {
  // Broad API tags can return unrelated businesses even with a precise query.
  return getRecallBranches(category).map(branch => ({ ...branch, tag: '' }))
}

const namePatterns: Record<string, RegExp> = {
  '推理/桌游': /桌游|剧本杀|密室|推理/,
  '酒吧清吧': /酒吧|清吧|酒馆|\bbar\b/i,
  'DIY手工坊': /DIY|手工|手作|陶艺|画室|绘画|油画/i,
  '健身房': /健身|fitness|普拉提|瑜伽/i,
  '电影': /电影院|影城|影院|影咖/,
  '球类运动': /羽毛球|篮球|乒乓球|网球|台球|足球|球馆|球类/,
  '洗浴按摩': /洗浴|按摩|足疗|足道|SPA|采耳|汗蒸|温泉/i,
  '武术搏击': /搏击|拳击|泰拳|散打|武术|跆拳道|柔道|空手道/,
  'KTV': /KTV|卡拉OK/i,
}
/** A query hit is provenance, not proof of business type. Unknowns receive no reserved category seat. */
export function classifyLeisurePoi(poi: { name: string; tag?: string }): string {
  // Strip broad parent tags such as 运动健身 before interpreting the actual subtype.
  const specificTag = (poi.tag || '').split(/[;,，；]/).filter(tag => !['运动健身','休闲娱乐','美食'].includes(tag)).join(' ')
  const tagKeys = leisureSubcategories.filter(key => namePatterns[key]?.test(specificTag))
  const nameKeys = leisureSubcategories.filter(key => namePatterns[key]?.test(poi.name))
  if (tagKeys.length === 1) return tagKeys[0]
  if (nameKeys.length === 1) return nameKeys[0]
  return ''
}

export interface LeisureCandidate<T> {
  item: T
  subcategory: string
  matchedSubcategoryKeys: string[]
}

/** Merge keywords into logical categories before quotas; retain every matched category after dedup. */
export function mergeLeisureRecall<T>(groups: RecallGroup<T>[], keyOf: (item: T) => string, classify?: (item: T) => string): LeisureCandidate<T>[] {
  const byId = new Map<string, { item: T; matches: Set<string> }>()
  for (const group of groups) for (const item of group.items) {
    const id = keyOf(item)
    if (!byId.has(id)) byId.set(id, { item, matches: new Set() })
    if (leisureSubcategories.includes(group.subcategory)) byId.get(id)!.matches.add(group.subcategory)
  }
  const buckets = leisureSubcategories.map(key => [...byId.keys()].filter(id => {
    const entry = byId.get(id)!
    return classify ? classify(entry.item) === key : entry.matches.has(key)
  }))
  const cursors = buckets.map(() => 0)
  const chosen = new Set<string>()
  const limit = getCandidateQuota(leisureSubcategories.length).target
  let progress = true
  while (progress && chosen.size < limit) {
    progress = false
    for (let i = 0; i < buckets.length && chosen.size < limit; i++) {
      while (cursors[i] < buckets[i].length && chosen.has(buckets[i][cursors[i]])) cursors[i]++
      if (cursors[i] < buckets[i].length) { chosen.add(buckets[i][cursors[i]++]); progress = true }
    }
  }
  // Unclassified broad matches only fill space after the logical categories.
  for (const id of byId.keys()) { if (chosen.size >= limit) break; chosen.add(id) }
  return [...chosen].map(id => {
    const entry = byId.get(id)!
    const matches = leisureSubcategories.filter(key => entry.matches.has(key))
    return { item: entry.item, subcategory: classify ? classify(entry.item) : matches[0] || '', matchedSubcategoryKeys: matches }
  })
}

function keysOf(shop: Shop): string[] {
  if (shop.logicalSubcategoryKey !== undefined) return leisureSubcategories.includes(shop.logicalSubcategoryKey) ? [shop.logicalSubcategoryKey] : []
  return (shop.matchedSubcategoryKeys || [shop.sub]).filter(key => leisureSubcategories.includes(key))
}
function displayKey(shop: Shop): string {
  return keysOf(shop)[0] || '未归类'
}

/** Input is already sorted by the existing geographic score. Seed two per logical bucket, then global fill. */
export function leisureShortlist<T extends Shop>(ranked: T[], limit = SHOP_PIPELINE_CONFIG.routeComputeCount): T[] {
  const selected = new Set<T>()
  for (let round = 0; round < 2 && selected.size < limit; round++) {
    for (const key of leisureSubcategories) {
      if (selected.size >= limit) break
      const next = ranked.find(shop => !selected.has(shop) && keysOf(shop).includes(key))
      if (next) selected.add(next)
    }
  }
  for (const shop of ranked) { if (selected.size >= limit) break; selected.add(shop) }
  // Preserve coarse-rank order for downstream tie breaks and the existing Mock seed.
  return ranked.filter(shop => selected.has(shop))
}

/** Soft cap for the first ten only. Top1 stays, nothing is dropped and deferred order stays stable. */
export function leisureTopTen<T extends ShopWithCommute>(ranked: T[]): T[] {
  const head: T[] = [], counts = new Map<string, number>()
  for (const shop of ranked) {
    if (head.length === 10) break
    const key = displayKey(shop)
    if (key === '未归类' && head.length > 0) continue
    if (key !== '未归类' && (counts.get(key) || 0) >= 2) continue
    head.push(shop)
    counts.set(key, (counts.get(key) || 0) + 1)
  }
  const selected = new Set(head)
  for (const shop of ranked) {
    if (head.length === 10) break
    if (!selected.has(shop)) { head.push(shop); selected.add(shop) }
  }
  return [...head, ...ranked.filter(shop => !selected.has(shop))]
}

/** This branch must never promote a venue outside the already configured 100-minute limit. */
export function withinLeisureCommuteLimit(shop: ShopWithCommute): boolean {
  return maxCommuteOf(shop) < SHOP_PIPELINE_CONFIG.maxCommuteMinutes
}

export function leisureDistribution(shops: Shop[]): Record<string, number> {
  const counts: Record<string, number> = Object.fromEntries(leisureSubcategories.map(key => [key, 0]))
  for (const shop of shops) { const key = displayKey(shop); counts[key] = (counts[key] || 0) + 1 }
  return counts
}

export function debugLeisureRecall<T>(groups: Array<RecallGroup<T> & { rawCount?: number; rawItems?: T[] }>, candidates: LeisureCandidate<T>[], keyOf: (item: T) => string, classify?: (item: T) => string): void {
  if (process.env.NODE_ENV === 'production') return
  console.table([...leisureSubcategories, ...(classify ? [''] : [])].map(key => ({
    logicalSubcategoryKey: key || '未归类',
    raw: classify ? groups.flatMap(g => g.rawItems || g.items).filter(item => classify(item) === key).length
      : groups.filter(g => g.subcategory === key).reduce((n, g) => n + (g.rawCount ?? g.items.length), 0),
    deduped: new Set(groups.flatMap(g => classify ? g.items.filter(item => classify(item) === key) : g.subcategory === key ? g.items : []).map(keyOf)).size,
    retained: candidates.filter(c => classify ? c.subcategory === key : c.matchedSubcategoryKeys.includes(key)).length,
  })))
}
export function debugLeisureStage(stage: string, shops: Shop[]): void {
  if (process.env.NODE_ENV === 'production') return
  console.info(`[leisure-all] ${stage}`, leisureDistribution(shops))
  if (stage === 'final Top10') console.table((shops as ShopWithCommute[]).slice(0, 10).map((s, i) => ({
    rank: i + 1, name: s.name, logicalSubcategoryKey: displayKey(s), avg: s.avg, fairness: s.fairness,
  })))
}
