// ============================================================
// 百度地图导航工具：
// - 优先调起百度地图 App（URL Scheme）
// - 未安装则兜底跳百度地图 H5 导航页
// - 支持传入起点坐标（我的位置）+ 对应交通方式
// - 百度地图 direction API 仅支持 transit/driving/walking/riding，不支持 taxi
//   打车时用驾车兜底，并提示用户在页面内切换打车模式
// ============================================================

import type { TravelMode } from '../types'

/** 出行方式 → 百度地图 mode 参数（百度地图仅支持这4种，打车用驾车兜底） */
const MODE_MAP: Record<TravelMode, string> = {
  drive: 'driving',
  transit: 'transit',
  walk: 'walking',
  bike: 'riding',
  taxi: 'driving', // 百度地图不支持 taxi mode，用驾车兜底
}

/** 起点信息 */
export interface NavOrigin {
  name: string
  lng: number
  lat: number
}

/**
 * 导航到指定店铺
 * @param shop 店铺信息（name / lng / lat）
 * @param origin 起点信息（我的位置的名称和经纬度）
 * @param mode 出行方式（默认驾车）
 * @param region 城市名（默认北京，用于 H5 兜底页）
 */
export function navigateToShop(
  shop: { name: string; lng: number; lat: number },
  origin: NavOrigin | null,
  mode: TravelMode = 'drive',
  region = '北京',
): void {
  const bdMode = MODE_MAP[mode] || 'driving'
  const destName = encodeURIComponent(shop.name)
  const destLatLng = `${shop.lat},${shop.lng}`

  // 构造起点参数（百度地图格式：name:起点名|latlng:纬度,经度）
  let originParam = ''
  if (origin && origin.lat && origin.lng) {
    const originName = encodeURIComponent(origin.name)
    originParam = `origin=name:${originName}|latlng:${origin.lat},${origin.lng}&`
  }

  // 1. 尝试调起百度地图 App
  //    baidumap://map/direction?origin=...&destination=name:xxx|latlng:lat,lng&mode=driving&src=webapp.pengpeng
  const appUrl = `baidumap://map/direction?${originParam}destination=name:${destName}|latlng:${destLatLng}&mode=${bdMode}&src=webapp.pengpeng`

  // 2. 兜底：百度地图 H5 导航页
  //    https://api.map.baidu.com/direction?origin=...&destination=latlng:lat,lng|name:xxx&mode=driving&region=北京&output=html
  const webUrl = `https://api.map.baidu.com/direction?${originParam}destination=latlng:${destLatLng}|name:${destName}&mode=${bdMode}&region=${encodeURIComponent(region)}&output=html`

  // 先尝试调 App
  const startTime = Date.now()
  window.location.href = appUrl

  // 2 秒后如果页面还在前台，说明没装 App，跳 H5 兜底
  setTimeout(() => {
    if (Date.now() - startTime < 2200 && document.visibilityState === 'visible') {
      window.open(webUrl, '_blank')
    }
  }, 2000)
}
