import type { ShopWithCommute, TravelMode, TravelPoint } from '../types'
import { dedupeCommutes, pointNickname } from './format'
import { decompressFromEncodedURIComponent } from 'lz-string'

export type SharedProposal = {
  version: 1
  shop: {
    name: string; city: string; area: string; address: string; lat: number; lng: number
    rating: number; perCapita: number; primary: string; sub: string; category: string
    intro: string; hours: string; phone: string; tags: string[]
  }
  commutes: { name: string; mode: TravelMode; minutes: number; fare: number; count: number }[]
  avgMinutes: number
  timeDiffMinutes: number
  tip: string | null
  createdAt: number
}

export function createSharedProposal(shop: ShopWithCommute, points: TravelPoint[], tip: string | null): SharedProposal {
  return {
    version: 1,
    shop: {
      name: shop.name, city: shop.city, area: shop.area, address: shop.address, lat: shop.lat, lng: shop.lng,
      rating: shop.rating, perCapita: shop.perCapita, primary: shop.primary, sub: shop.sub,
      category: shop.category, intro: shop.intro, hours: shop.hours, phone: shop.phone || '',
      tags: (shop.tags || []).slice(0, 4),
    },
    commutes: dedupeCommutes(shop.commutes).map((commute) => {
      const index = points.findIndex((point) => point.id === commute.pointId)
      return {
        name: pointNickname(points[index], index), mode: commute.mode,
        minutes: commute.minutes, fare: commute.fare, count: commute.count,
      }
    }),
    avgMinutes: shop.avg, timeDiffMinutes: shop.fairness,
    tip, createdAt: Date.now(),
  }
}

const modes = new Set<TravelMode>(['transit', 'drive', 'taxi', 'bike', 'walk'])
const text = (value: unknown, max: number) => typeof value === 'string' ? value.slice(0, max) : ''
const finite = (value: unknown, min: number, max: number) =>
  typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max

const modeCodes: TravelMode[] = ['transit', 'drive', 'taxi', 'bike', 'walk']

function utf8ToBase64Url(value: string): string {
  const bytes = new TextEncoder().encode(value)
  let binary = ''
  for (const byte of bytes) binary += String.fromCharCode(byte)
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
}

function base64UrlToJson(payload: string): unknown {
  if (!/^[\w-]{1,150000}$/.test(payload)) return null
  const normalized = payload.replace(/-/g, '+').replace(/_/g, '/')
  const padded = normalized + '='.repeat((4 - normalized.length % 4) % 4)
  const binary = atob(padded)
  return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(
    Uint8Array.from(binary, (char) => char.charCodeAt(0)),
  ))
}

/**
 * v4 is the current public share format.
 * Keep the URL compact: only fields required by the receiver snapshot are serialized.
 * AI tip remains available to the sender/export UI but is intentionally NOT embedded in the URL.
 */
export function encodeSharedProposal(proposal: SharedProposal): string {
  const s = proposal.shop
  const compact = [4,
    [s.name, s.city, s.area, s.address, s.lng, s.lat, s.rating, s.perCapita, s.category],
    proposal.commutes.map(c => [c.name, modeCodes.indexOf(c.mode), c.minutes, c.fare, c.count]),
    proposal.avgMinutes, proposal.timeDiffMinutes, proposal.createdAt,
  ]
  return `v4.${utf8ToBase64Url(JSON.stringify(compact))}`
}

function decodePayload(payload: string): unknown {
  if (payload.startsWith('v4.')) {
    if (!/^v4\.[\w-]{1,150000}$/.test(payload)) return null
    const p = base64UrlToJson(payload.slice(3))
    if (!Array.isArray(p) || p.length !== 6 || p[0] !== 4 ||
      !Array.isArray(p[1]) || p[1].length !== 9 || !Array.isArray(p[2])) return null
    const s = p[1]
    if (p[2].some((c: unknown) => !Array.isArray(c) || c.length !== 5 ||
      !Number.isInteger(c[1]) || c[1] < 0 || c[1] >= modeCodes.length)) return null
    return {
      version: 1,
      shop: {
        name: s[0], city: s[1], area: s[2], address: s[3], lng: s[4], lat: s[5],
        rating: s[6], perCapita: s[7], primary: '', sub: '', category: s[8],
        intro: '', hours: '', phone: '', tags: [],
      },
      commutes: p[2].map((c: any[]) => ({ name: c[0], mode: modeCodes[c[1]], minutes: c[2], fare: c[3], count: c[4] })),
      avgMinutes: p[3], timeDiffMinutes: p[4], tip: null, createdAt: p[5],
    }
  }

  // Intermediate v3: tuple snapshot encoded as Base64URL. Keep readable for links already sent.
  if (payload.startsWith('v3.')) {
    if (!/^v3\.[\w-]{1,150000}$/.test(payload)) return null
    const p = base64UrlToJson(payload.slice(3))
    if (!Array.isArray(p) || p.length !== 7 || p[0] !== 3 ||
      !Array.isArray(p[1]) || p[1].length !== 15 || !Array.isArray(p[2])) return null
    const s = p[1]
    if (p[2].some((c: unknown) => !Array.isArray(c) || c.length !== 5 ||
      !Number.isInteger(c[1]) || c[1] < 0 || c[1] >= modeCodes.length)) return null
    return {
      version: 1,
      shop: { name: s[0], city: s[1], area: s[2], address: s[3], lng: s[4], lat: s[5],
        rating: s[6], perCapita: s[7], primary: s[8], sub: s[9], category: s[10],
        intro: s[11], hours: s[12], phone: s[13], tags: s[14] },
      commutes: p[2].map((c: any[]) => ({ name: c[0], mode: modeCodes[c[1]], minutes: c[2], fare: c[3], count: c[4] })),
      avgMinutes: p[3], timeDiffMinutes: p[4], tip: p[5], createdAt: p[6],
    }
  }

  // v2: lz-string URI-safe compressed tuple. Keep readable for links already sent.
  if (payload.startsWith('v2.')) {
    if (!/^v2\.[A-Za-z0-9+\-$]{1,150000}$/.test(payload)) return null
    const json = decompressFromEncodedURIComponent(payload.slice(3))
    if (!json || json.length > 500000) return null
    const p = JSON.parse(json)
    if (!Array.isArray(p) || p.length !== 7 || p[0] !== 2 ||
      !Array.isArray(p[1]) || p[1].length !== 15 || !Array.isArray(p[2])) return null
    const s = p[1]
    if (p[2].some((c: unknown) => !Array.isArray(c) || c.length !== 5 ||
      !Number.isInteger(c[1]) || c[1] < 0 || c[1] >= modeCodes.length)) return null
    return {
      version: 1,
      shop: { name: s[0], city: s[1], area: s[2], address: s[3], lng: s[4], lat: s[5],
        rating: s[6], perCapita: s[7], primary: s[8], sub: s[9], category: s[10],
        intro: s[11], hours: s[12], phone: s[13], tags: s[14] },
      commutes: p[2].map((c: any[]) => ({ name: c[0], mode: modeCodes[c[1]], minutes: c[2], fare: c[3], count: c[4] })),
      avgMinutes: p[3], timeDiffMinutes: p[4], tip: p[5], createdAt: p[6],
    }
  }

  // Existing unprefixed v1 URLs remain readable.
  return base64UrlToJson(payload)
}

export function decodeSharedProposal(payload: string): SharedProposal | null {
  try {
    const data = decodePayload(payload)
    if (!data || typeof data !== 'object') return null
    const proposal = data as SharedProposal
    const shop = proposal.shop
    if (proposal.version !== 1 || !shop || !Array.isArray(proposal.commutes) || proposal.commutes.length < 1 || proposal.commutes.length > 6) return null
    if (!text(shop.name, 200) || !finite(shop.lat, -90, 90) || !finite(shop.lng, -180, 180) ||
      !finite(proposal.avgMinutes, 0, 10000) || !finite(proposal.timeDiffMinutes, 0, 10000) ||
      !finite(proposal.createdAt, 1, Number.MAX_SAFE_INTEGER)) return null
    if (proposal.commutes.some((c) => !c || !text(c.name, 100) || !modes.has(c.mode) || !finite(c.minutes, 0, 10000) || !finite(c.fare, 0, 100000) || !finite(c.count, 1, 6))) return null
    return {
      version: 1,
      shop: {
        name: text(shop.name, 200), city: text(shop.city, 100), area: text(shop.area, 200), address: text(shop.address, 400),
        lat: shop.lat, lng: shop.lng,
        rating: finite(shop.rating, 0, 5) ? shop.rating : 0,
        perCapita: finite(shop.perCapita, 0, 100000) ? shop.perCapita : 0,
        primary: text(shop.primary, 50), sub: text(shop.sub, 100), category: text(shop.category, 100),
        intro: text(shop.intro, 1000), hours: text(shop.hours, 200), phone: text(shop.phone, 100),
        tags: Array.isArray(shop.tags) ? shop.tags.slice(0, 4).map((tag) => text(tag, 60)) : [],
      },
      commutes: proposal.commutes.map((c) => ({
        name: text(c.name, 100), mode: c.mode, minutes: c.minutes, fare: c.fare, count: c.count,
      })),
      avgMinutes: proposal.avgMinutes, timeDiffMinutes: proposal.timeDiffMinutes,
      tip: typeof proposal.tip === 'string' ? proposal.tip : null,
      createdAt: proposal.createdAt,
    }
  } catch { return null }
}

export const PUBLIC_SHARE_BASE_URL = 'https://starrycorvus.github.io/share.html?v=20261007-share5'

export function proposalShareText(name: string): string {
  return `我在碰碰上找到一个能轻松碰面的地方：${name}\n看看这份会面提案 👇`
}

export function sharedProposalUrl(proposal: SharedProposal): string {
  const url = new URL(PUBLIC_SHARE_BASE_URL)
  url.hash = `#/share/${encodeSharedProposal(proposal)}`
  return url.href
}
