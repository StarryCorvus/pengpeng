// ============================================================
// 本地存储工具：表单自动记忆上次填写内容
// ============================================================

import type { FormState } from '../types'
import { DEFAULT_TIME_DIFF, TIME_DIFF_MAX, TIME_DIFF_MIN } from '../mock/constants'

const KEY = 'mim-form-state-v1'

/**
 * 读取上次填写的表单（解析失败返回 null）。
 * 兼容旧版本本地数据：
 * - 无 timeDiff / timeDiff 为 null（旧「不限」档）-> 补当前默认值 20
 * - 旧版 budget 字段随结构删除被忽略
 */
export function loadFormState(): FormState | null {
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return null
    const data = JSON.parse(raw) as FormState
    if (!data || !Array.isArray(data.points) || data.points.length === 0) return null
    // 校验每个点的经纬度是否有效（防止无效坐标导致地图崩溃白屏）
    const validPoints = data.points.filter((p) => {
      return (
        p &&
        typeof p.lng === 'number' &&
        typeof p.lat === 'number' &&
        Number.isFinite(p.lng) &&
        Number.isFinite(p.lat) &&
        p.lng >= -180 &&
        p.lng <= 180 &&
        p.lat >= -90 &&
        p.lat <= 90
      )
    })
    if (validPoints.length === 0) return null
    data.points = validPoints
    const td = data.timeDiff
    data.timeDiff =
      typeof td === 'number' && Number.isFinite(td)
        ? Math.min(TIME_DIFF_MAX, Math.max(TIME_DIFF_MIN, Math.round(td)))
        : DEFAULT_TIME_DIFF
    return data
  } catch {
    return null
  }
}

/** 保存表单（静默失败，原型阶段不阻塞） */
export function saveFormState(state: FormState): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(state))
  } catch {
    /* ignore */
  }
}

/** 清空记忆 */
export function clearFormState(): void {
  try {
    localStorage.removeItem(KEY)
  } catch {
    /* ignore */
  }
}

// ============================================================
// 常用位置（最近选择过的地点，最多 5 条，自动去重）
// ============================================================

const RECENT_KEY = 'mim-recent-places-v1'
const RECENT_MAX = 5

export interface RecentPlace {
  name: string
  address: string
  lng: number
  lat: number
}

/** 读取最近选择的地点列表（按时间倒序） */
export function loadRecentPlaces(): RecentPlace[] {
  try {
    const raw = localStorage.getItem(RECENT_KEY)
    if (!raw) return []
    const arr = JSON.parse(raw)
    if (!Array.isArray(arr)) return []
    const seen = new Set<string>()
    return arr.filter((p) => {
      if (!p || typeof p.name !== 'string' || typeof p.lng !== 'number' || typeof p.lat !== 'number') return false
      const key = `${p.name}|${p.lng}|${p.lat}`
      if (seen.has(key)) return false
      seen.add(key)
      return true
    })
  } catch {
    return []
  }
}

/** 仅删除目标历史地点，沿用现有去重标识：名称 + 经度 + 纬度。 */
export function removeRecentPlace(place: RecentPlace): RecentPlace[] {
  try {
    const next = loadRecentPlaces().filter((p) =>
      !(p.name === place.name && p.lng === place.lng && p.lat === place.lat))
    localStorage.setItem(RECENT_KEY, JSON.stringify(next))
  } catch {
    /* 与现有历史读写一致：存储不可用时保留实际可读取的状态。 */
  }
  return loadRecentPlaces()
}

/** 保存一个最近选择的地点（去重，移到最前，超过上限截断） */
export function saveRecentPlace(place: RecentPlace): void {
  try {
    const list = loadRecentPlaces()
    // 去重：同名同坐标的移除旧条目
    const filtered = list.filter((p) => !(p.name === place.name && p.lng === place.lng && p.lat === place.lat))
    const next = [place, ...filtered].slice(0, RECENT_MAX)
    localStorage.setItem(RECENT_KEY, JSON.stringify(next))
  } catch {
    /* ignore */
  }
}

// ============================================================
// 店铺收藏（我的页面展示）
// ============================================================

const FAV_KEY = 'mim-fav-shops-v1'

/** 收藏的店铺（精简信息，足够展示卡片） */
export interface FavShop {
  id: string
  name: string
  primary: string
  sub: string
  category: string
  area: string
  rating: number
  perCapita: number
  lng: number
  lat: number
  /** 收藏时间戳 */
  favAt: number
}

/** 读取收藏店铺列表（按收藏时间倒序） */
export function loadFavShops(): FavShop[] {
  try {
    const raw = localStorage.getItem(FAV_KEY)
    if (!raw) return []
    const arr = JSON.parse(raw)
    if (!Array.isArray(arr)) return []
    return arr
      .filter((s) => s && typeof s.id === 'string' && typeof s.name === 'string')
      .sort((a, b) => (b.favAt || 0) - (a.favAt || 0))
  } catch {
    return []
  }
}

/** 判断某店铺是否已收藏 */
export function isFavShop(id: string): boolean {
  return loadFavShops().some((s) => s.id === id)
}

/** 切换收藏状态（收藏/取消），返回最新收藏状态 */
export function toggleFavShop(shop: Omit<FavShop, 'favAt'>): boolean {
  try {
    const list = loadFavShops()
    const exists = list.some((s) => s.id === shop.id)
    let next: FavShop[]
    if (exists) {
      next = list.filter((s) => s.id !== shop.id)
    } else {
      next = [{ ...shop, favAt: Date.now() }, ...list]
    }
    localStorage.setItem(FAV_KEY, JSON.stringify(next))
    return !exists
  } catch {
    return false
  }
}

// ============================================================
// 用户行为计数（我的页面数据统计）
// ============================================================

const COUNT_KEY = 'mim-user-counts-v1'

export interface UserCounts {
  /** 发起会面次数（点击「开始寻找」） */
  meetingsStarted: number
  /** 搜索地点次数（在地址搜索中选择了地点） */
  searches: number
}

/** 读取用户行为计数 */
export function loadUserCounts(): UserCounts {
  try {
    const raw = localStorage.getItem(COUNT_KEY)
    if (!raw) return { meetingsStarted: 0, searches: 0 }
    const data = JSON.parse(raw)
    return {
      meetingsStarted: typeof data.meetingsStarted === 'number' ? data.meetingsStarted : 0,
      searches: typeof data.searches === 'number' ? data.searches : 0,
    }
  } catch {
    return { meetingsStarted: 0, searches: 0 }
  }
}

/** 增加某项计数，返回最新值 */
export function incrementCount(key: keyof UserCounts): number {
  try {
    const counts = loadUserCounts()
    counts[key] = (counts[key] || 0) + 1
    localStorage.setItem(COUNT_KEY, JSON.stringify(counts))
    return counts[key]
  } catch {
    return 0
  }
}

// ============================================================
// 用户资料（昵称 / 头像，持久化到 localStorage）
// ============================================================

const PROFILE_KEY = 'mim-user-profile-v1'

export interface UserProfile {
  nickname: string
  /** 预设头像索引（-1 表示使用自定义上传头像） */
  avatarIndex: number
  /** 自定义上传头像（base64 data URL），avatarIndex=-1 时生效 */
  customAvatar: string | null
}

const DEFAULT_PROFILE: UserProfile = {
  nickname: '碰碰用户',
  avatarIndex: 0,
  customAvatar: null,
}

/** 读取用户资料（不存在返回默认值） */
export function loadUserProfile(): UserProfile {
  try {
    const raw = localStorage.getItem(PROFILE_KEY)
    if (!raw) return { ...DEFAULT_PROFILE }
    const data = JSON.parse(raw)
    return {
      nickname: typeof data.nickname === 'string' && data.nickname ? data.nickname : DEFAULT_PROFILE.nickname,
      avatarIndex: typeof data.avatarIndex === 'number' ? data.avatarIndex : 0,
      customAvatar: typeof data.customAvatar === 'string' ? data.customAvatar : null,
    }
  } catch {
    return { ...DEFAULT_PROFILE }
  }
}

/** 保存用户资料 */
export function saveUserProfile(profile: UserProfile): void {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile))
  } catch {
    /* ignore */
  }
}

// ============================================================
// 碰碰日记（记录每次碰碰：和谁、时间、地点、干了什么）
// ============================================================

const DIARY_KEY = 'mim-diary-entries-v1'

export interface DiaryEntry {
  id: string
  /** 碰友（和谁） */
  who: string
  /** 时间（ISO 字符串或用户输入文本） */
  time: string
  /** 地点 */
  place: string
  /** 札记（干了什么） */
  what: string
  /** 创建时间戳 */
  createdAt: number
  /** 最后更新时间戳 */
  updatedAt: number
  /** 便签在画布上的 X 位置（px，可拖拽） */
  x?: number
  /** 便签在画布上的 Y 位置（px，可拖拽） */
  y?: number
}

/** 读取所有日记条目（按创建时间倒序） */
export function loadDiaryEntries(): DiaryEntry[] {
  try {
    const raw = localStorage.getItem(DIARY_KEY)
    if (!raw) return []
    const data = JSON.parse(raw)
    if (!Array.isArray(data)) return []
    return data
      .filter((d) => d && typeof d.id === 'string')
      .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
  } catch {
    return []
  }
}

/** 保存日记条目列表 */
function saveDiaryEntries(entries: DiaryEntry[]): void {
  try {
    localStorage.setItem(DIARY_KEY, JSON.stringify(entries))
  } catch {
    /* ignore */
  }
}

/** 新增一条日记 */
export function addDiaryEntry(entry: Omit<DiaryEntry, 'id' | 'createdAt' | 'updatedAt'>): DiaryEntry {
  const now = Date.now()
  const newEntry: DiaryEntry = {
    ...entry,
    id: 'd_' + now.toString(36) + Math.random().toString(36).slice(2, 6),
    createdAt: now,
    updatedAt: now,
  }
  const entries = loadDiaryEntries()
  entries.unshift(newEntry)
  saveDiaryEntries(entries)
  return newEntry
}

/** 更新一条日记 */
export function updateDiaryEntry(id: string, patch: Partial<Omit<DiaryEntry, 'id' | 'createdAt'>>): DiaryEntry | null {
  const entries = loadDiaryEntries()
  const idx = entries.findIndex((e) => e.id === id)
  if (idx === -1) return null
  entries[idx] = { ...entries[idx], ...patch, updatedAt: Date.now() }
  saveDiaryEntries(entries)
  return entries[idx]
}

/** 删除一条日记 */
export function deleteDiaryEntry(id: string): void {
  const entries = loadDiaryEntries().filter((e) => e.id !== id)
  saveDiaryEntries(entries)
}
