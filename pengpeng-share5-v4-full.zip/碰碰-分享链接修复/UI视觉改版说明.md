# 碰碰 UI 视觉改版｜0920 阶段交付

本轮唯一基准为上传的 `碰碰-完整工程-0920-AI推荐v3(1).zip`。这是可继续开发、可构建、可直接打开 HTML 的阶段版，不代表完整真实 API / 真机验收已经结束。

## 打开与继续开发

- `碰碰-UI改版-Mock.html`：直接双击体验主流程；地点、通勤、推荐为原工程 Mock 数据。原 Mock 店铺照片仍使用外部图片 URL，图片失败时列表和详情回退为品类图标；不调用百度计算或 AI 服务。
- `碰碰-UI改版-真实API.html`：直接打开的真实模式构建，保留原百度和代理配置。需要原服务可达及有效的浏览器地图配置；本轮未完成真实 API 联网验收。
- 源码开发：`npm ci`，`npm run dev`。
- 普通构建：`npm run build`；原测试：`npm test`。
- 同时生成两种单文件：`node scripts/build-ui-deliverables.mjs`。
- 双模式脚本暂时按原开关构建 Mock，并在 finally 恢复 `src/config.ts`；随后构建真实模式。最终源码配置与上传版本一致。不要同时运行多个构建命令。

## 已完成

1. 暖纸色、深棕文字、纸张卡片、主按钮、焦点与 reduced-motion 样式。纸纹为微弱静态 SVG，不引入运行时滤镜动画。
2. 原 Logo 分层开屏、碰撞回弹、少量纸屑，结束后显示未重绘的原 Logo；开屏可即时跳过。
3. 同一 FormPage 中的 intro / people / category 展示步骤。保留原 FormState / onChange / onStart；App 路由完全未改。
4. People 独立检查 2–6 人和有效地点坐标。复用原 StartPointList、AddressSearch、定位、昵称与交通方式。
5. 原一级分类数据映射到单色 SVG 图标；支持点击和横向滑动，二级菜单仍使用 CATEGORY_TREE children。下一步文案集中为常量。
6. 结果标题、地图边缘 23px 淡化与轻微模糊、列表卡、AI 推荐区、预览/详情/分享基础视觉。地图本体不加滤镜，边缘层不拦截 pointer。
7. 店名可换行。图片加载失败时列表/详情使用品类图标占位，原店铺数据不变。
8. “我的”、收藏、日记、通用弹层和底部导航基础统一；日记便签改为低饱和纸色，原拖拽和存储代码不变。
9. 无新增项目依赖；React 18 / TypeScript / Webpack / 普通 CSS 结构保留。

## 修改过的既有文件

| 文件 | 变动范围 |
| --- | --- |
| src/main.tsx | 最后引入 brand.css |
| src/styles/global.css | 根变量定义改为纸张/棕色 token；原组件规则保留 |
| src/pages/FormPage.tsx | 展示步骤、People 校验、同一表单数据绑定、步骤滚动复位；原 validateForm 函数保留 |
| src/pages/ResultPage.tsx | 新展示标题和 PaperMapFrame 边缘组件；计算、筛选和回调不改 |
| src/pages/ProfilePage.tsx | 仅默认头像背景颜色 |
| src/pages/DiaryPage.tsx | 仅 NOTE_COLORS 色板 |
| src/components/result/ShopImage.tsx | 无照片时从 emoji 渐变改为 SVG 品类占位 |
| src/components/result/ShopCard.tsx | 图片改用失败可回退的 ShopPhoto；原数据字段保留 |
| src/components/result/ShopDetailModal.tsx | 仅照片 JSX 替换为 ShopPhoto；详情/AI 请求代码不改 |

新增 `src/styles/brand.css`、`src/components/brand/*`、双模式构建脚本、原 Logo 资产与交付说明。逐文件差异见 `验收记录/改动.patch`，完整源文件校验见 `验收记录/基准校验.json`。

## 验证结果与边界

- 修改前 build、原 A–F 管线测试通过。
- 修改后真实/Mock 两种构建通过，TypeScript 无错误；原 A–F 管线测试通过。
- Chromium 的 Mock 浏览器检查通过：开屏隐藏导航、人数校验、地址搜索选择、独立交通方式、品类选择、返回保留、Tab 保留、进入结果、地图/列表、详情、收藏、分享卡预览、日记新增和便签拖拽。
- 320px 宽屏检查通过：无页面横向溢出、6 人上限与删除；reduced-motion 下完整 Logo 可见。
- 本轮浏览器测试未出现未捕获页面异常。Mock 只观察到原店铺图片外部请求，没有百度或 AI API 请求。
- 未验证：真实百度网络请求/评分/AI 返回、真实地图拖拽帧率、iOS/Android 键盘与定位、实际导航应用唤起、系统分享和图片保存、日记所有编辑/删除/重载场景。保留原逻辑不等于这些项目已通过实测。

截图使用测试环境的中文系统字体替代显示，仅用于 QA，没有给工程添加网络字体。

## 尚未完成与下一轮继续点

1. 正式 People / Category 角色插画和最终品类 CTA 由产品方确认；目前使用原 Logo 上半部和集中管理的临时文案。
2. PaperMapFrame 已做边缘渐隐和轻微渐变模糊，尚未加入更精细的不规则纸纤维边，也尚未验证真实地图低端手机性能。
3. 旧地图 Marker、原碰友标记颜色和部分历史 emoji 保留。旧 CSS 中部分硬编码颜色尚未全部收拢；本轮以覆盖样式降低回归风险，未删除旧规则。
4. 收藏页/详情/分享/通用空状态属于基础统一，尚非所有细节的最终品牌稿。卡片图片容错目前覆盖结果列表和店铺详情；其他旧照片入口保持原行为。
5. Carousel 点击和回写已经验证；惯性触摸滑动的最终居中选择仍需真机验证。
6. 下一轮优先：使用真实服务走完主流程 → 真机键盘/地图/分享验收 → 换正式插画 → 逐个清理遗留视觉细节。

## 参考阅读记录

仅借鉴思路，没有安装参考 UI 库或复制它们的组件代码。

- [Sketchbook UI](https://github.com/SarthakRawat-1/sketchbook-ui)：局部手绘边线、纸面与清晰组件。
- [Scribble UI](https://github.com/MitchForest/scribble-ui)：局部有机描边；不迁移框架。
- [Drawably](https://github.com/Danilaa1/drawably/blob/main/README.md)：固定形状和克制动效；地址、数字、列表保持稳定。
- [Scrawl UI](https://github.com/AvighnaBasak/scrawl-ui/blob/main/README.md)：纸张/小票容器语汇。
- [Leaflet tilelayer mask](https://github.com/frogcat/leaflet-tilelayer-mask)、[Sunlit](https://github.com/jackyzha0/sunlit)、[TornPaper](https://github.com/happy358/TornPaper)：地图外缘处理参考，不引入 Leaflet，不给地图本体加滤镜。
- coffee-and-fun/website 的仓库及 README 两次访问均失败；该项仅依据用户提供的视觉说明，未声称读到源码。
