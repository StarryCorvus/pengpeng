const path = require('path')

module.exports = {
  mode: 'development',
  target: 'node',
  entry: {
    'pipeline-test': path.resolve(__dirname, 'tests/resultPipeline.test.ts'),
    'continuation-test': path.resolve(__dirname, 'tests/continuation.test.ts'),
  },
  output: {
    path: path.resolve(__dirname, '.test-dist'),
    filename: '[name].cjs',
    clean: true,
  },
  resolve: { extensions: ['.ts', '.js'] },
  module: {
    rules: [
      {
        test: /\.ts$/,
        exclude: /node_modules/,
        use: { loader: 'ts-loader', options: { transpileOnly: true } },
      },
    ],
  },
  devtool: false,
}
