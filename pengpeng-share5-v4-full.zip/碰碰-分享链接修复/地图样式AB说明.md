# 地图样式 A/B 说明（阶段三）

本轮地图展示完全沿用阶段二。`PaperMapFrame.tsx`、`BaiduMap.tsx`、`MockMap.tsx`、`mapVisualStyle.ts`、`ResultPage.tsx` 与阶段二逐字节一致。

默认 warmPaper，结果页左下角“原地图／暖纸”按钮可切换。真实模式通过官方 setMapStyleV2 设置地图元素颜色，保留不支持或异常时 default 降级；不使用 CSS sepia 或整图滤镜。Mock 模式沿用对应示意配色。

本轮 Mock 地图 A/B、拖拽、缩放、marker 及深色偏好下展示均通过浏览器回归；官方 style adapter 的 apply/reset/unsupported/exception 测试通过。

真实 SDK 当前因 net::ERR_CERT_AUTHORITY_INVALID 无法加载，未取得真实地图 A/B 对照图，也未验证真机地图流畅度。截图中带 mock 的文件都只是 Mock。下一轮直接在可访问百度 SDK 的环境验收，不需要重做地图代码。
