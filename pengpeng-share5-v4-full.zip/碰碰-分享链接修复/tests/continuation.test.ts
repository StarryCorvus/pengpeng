import assert from 'node:assert/strict'
import { encodeSharedProposal, decodeSharedProposal, sharedProposalUrl, proposalShareText, type SharedProposal } from '../src/utils/sharedProposal'
import { compressToEncodedURIComponent } from 'lz-string'
import { isLeisureAll, leisureShortlist, leisureTopTen, mergeLeisureRecall, leisureDistribution, leisureSubcategories, withinLeisureCommuteLimit, classifyLeisurePoi, leisureRecallBranches } from '../src/utils/leisureDiversity'
import { getRecallBranches, rankEligibleShops, diversityRerank, passesHardFairness } from '../src/utils/resultPipeline'
import { computeMockResult } from '../src/mock/compute'
import type { ShopWithCommute, FormState } from '../src/types'

const tip = `⭐ 渔歌·四季蒸汽海鲜（上地南路店）适合想一起吃海鲜、慢慢聊天的碰友。
蒸汽烹饪的节奏比较从容，可以边等边聊。若有不吃贝类或海鲜过敏的朋友，建议先打电话确认其他菜品。
🚶 这份提案里大家的通勤比较接近，不过具体到店时间仍取决于出发时的路况和候车情况。
⚠️ 目前公开信息不能确认当天的海鲜供应、包间和等位情况；热门时段建议先问店家。人均与营业时间也可能变化，请以门店当天信息为准。
约好时间再出发吧，琳琳 & 小周 👋 “一起碰个面！”`

function proposal(people: number): SharedProposal {
  return { version: 1, shop: {
    name: '渔歌·四季蒸汽海鲜（上地南路店）', city: '北京市', area: '海淀区', address: '北京市海淀区上地南路测试地址 8 号',
    lng: 116.31, lat: 40.032, rating: 4.7, perCapita: 128, primary: 'food', sub: '海鲜河鲜', category: '海鲜河鲜',
    intro: '以蒸汽海鲜为主的餐厅', hours: '11:00–22:00', phone: '010-12345678', tags: ['海鲜', '聚会'],
  }, commutes: Array.from({ length: people }, (_, i) => ({ name: ['琳琳', '小周🐈', '朋友 & A', '小张', '阿福', '小王'][i],
    mode: (['transit','drive','taxi','bike','walk','transit'] as const)[i], minutes: 25 + i, fare: i * 3, count: 1 })),
  avgMinutes: 27.5, timeDiffMinutes: 5, tip, createdAt: 1790676000000 }
}
const oldEncode = (p: unknown) => Buffer.from(JSON.stringify(p), 'utf8').toString('base64url')
const fullTuple = (p: SharedProposal, version: 2 | 3) => [version,
  [p.shop.name,p.shop.city,p.shop.area,p.shop.address,p.shop.lng,p.shop.lat,p.shop.rating,p.shop.perCapita,
    p.shop.primary,p.shop.sub,p.shop.category,p.shop.intro,p.shop.hours,p.shop.phone,p.shop.tags],
  p.commutes.map(c=>[c.name,['transit','drive','taxi','bike','walk'].indexOf(c.mode),c.minutes,c.fare,c.count]),
  p.avgMinutes,p.timeDiffMinutes,p.tip,p.createdAt]

const shareLengths = [2,4,6].map(people => {
  const p = proposal(people), encoded = encodeSharedProposal(p)
  const decoded = decodeSharedProposal(encoded)!
  assert.equal(decoded.shop.name, p.shop.name)
  assert.equal(decoded.shop.category, p.shop.category)
  assert.deepEqual(decoded.commutes, p.commutes)
  assert.equal(decoded.avgMinutes, p.avgMinutes)
  assert.equal(decoded.timeDiffMinutes, p.timeDiffMinutes)
  assert.equal(decoded.tip, null, 'v4 must not put AI tip into the URL')
  assert.deepEqual(decodeSharedProposal(oldEncode(p)), p)
  assert.deepEqual(decodeSharedProposal('v3.'+oldEncode(fullTuple(p,3))), p)
  assert.deepEqual(decodeSharedProposal('v2.'+compressToEncodedURIComponent(JSON.stringify(fullTuple(p,2)))), p)
  const base = 'https://starrycorvus.github.io/share.html?v=20261007-share5#/share/'
  const oldLength = base.length + oldEncode(p).length, newLength = base.length + encoded.length
  assert(newLength / oldLength < .75, 'Expected compact v4 share URL')
  return { people, oldLength, newLength, ratio: +(newLength / oldLength).toFixed(3) }
})
const long = { ...proposal(6), tip: tip.repeat(12) + '结尾不能丢🐈‍⬛' }
const noTip = { ...long, tip: null }
assert.equal(encodeSharedProposal(long), encodeSharedProposal(noTip), 'AI tip must not affect v4 URL length')
assert.equal(decodeSharedProposal(encodeSharedProposal(long))?.tip, null)
const dirty = { ...proposal(2), FormState: { secret: 'PRIVATE_ORIGIN_DO_NOT_SHARE' }, images: ['PRIVATE_IMAGE'] }
assert(!Buffer.from(encodeSharedProposal(dirty).slice(3).replace(/-/g,'+').replace(/_/g,'/'), 'base64').toString('utf8').includes('PRIVATE_'))
for (const bad of ['v4.', 'v4.broken', 'v2.', 'v2.broken', 'v9.payload', '%%%', oldEncode({version:1})]) assert.equal(decodeSharedProposal(bad), null)
const legacy = proposal(2); delete (legacy.shop as any).city
assert.equal(decodeSharedProposal(oldEncode(legacy))?.shop.city, '')
assert(sharedProposalUrl(proposal(2)).startsWith('https://starrycorvus.github.io/share.html?v=20261007-share5#/share/v4.'))
assert(!sharedProposalUrl(proposal(2)).includes('content://'))
assert.equal(proposalShareText('某店'), '我在碰碰上找到一个能轻松碰面的地方：某店\n看看这份会面提案 👇')

function shop(sub: string, n: number, time = 20 + n / 10): ShopWithCommute {
  return { id: `${sub}-${n}`, uid: `${sub}-${n}`, name: `${sub}测试${n}`, primary: 'fun', sub, category: sub,
    city:'北京市', area:'测试区', address:'', lng:116.4, lat:39.9, rating:4.5, perCapita:80, hours:'', intro:'', images:[],
    matchedSubcategoryKeys:[sub], avg:time, fairness:0,
    commutes:[{pointId:'p1',pointName:'我',mode:'transit',minutes:time,fare:4},{pointId:'p2',pointName:'碰友',mode:'transit',minutes:time,fare:4}] }
}
assert(isLeisureAll({ primary:'fun',secondary:'全部分类' }))
assert(!isLeisureAll({ primary:'fun',secondary:'电影' }))
assert(!isLeisureAll({ primary:'food',secondary:'全部分类' }))
assert.equal(classifyLeisurePoi({name:'华夏良子·足道SPA',tag:'休闲娱乐;洗浴按摩'}),'洗浴按摩')
assert.equal(classifyLeisurePoi({name:'唱吧麦颂KTV',tag:'休闲娱乐;ktv'}),'KTV')
assert.equal(classifyLeisurePoi({name:'郡王府游泳馆',tag:'运动健身;体育场馆'}),'')
assert.equal(classifyLeisurePoi({name:'英徒搏击',tag:'运动健身;体育场馆'}),'武术搏击')
assert(leisureRecallBranches({primary:'fun',secondary:'全部分类'}).every(b=>b.tag===''))
const gym = Array.from({length:40},(_,i)=>shop('健身房',i))
const others = leisureSubcategories.filter(s=>s!=='健身房').flatMap(s=>Array.from({length:3},(_,i)=>shop(s,i,30+i)))
const ranked = [...gym,...others]
const shortlist = leisureShortlist(ranked)
assert.equal(shortlist.length,30)
for(const key of leisureSubcategories) assert(shortlist.filter(s=>s.sub===key).length>=2, key+' needs reserved seats')
assert.equal(new Set(shortlist.map(s=>s.id)).size,30)
assert.deepEqual(leisureShortlist(gym),gym.slice(0,30))
const fullQuality = rankEligibleShops(shortlist)
const final = leisureTopTen(diversityRerank(fullQuality,true))
assert.equal(final[0].id,fullQuality[0].id)
assert.deepEqual(new Set(final.map(s=>s.id)),new Set(shortlist.map(s=>s.id)))
assert(Object.values(leisureDistribution(final.slice(0,10))).every(n=>n<=2))
assert.deepEqual(leisureTopTen(gym),gym)
assert.deepEqual(leisureTopTen(diversityRerank(fullQuality,true)),final)
assert(!withinLeisureCommuteLimit(shop('电影',0,100)))
assert(withinLeisureCommuteLimit(shop('电影',0,99)))
const shared = shop('健身房',90)
const merged = mergeLeisureRecall([
  {subcategory:'健身房',items:[shared,...gym]},
  {subcategory:'武术搏击',items:[shared]},
  {subcategory:'健身房',items:[shared,...gym]},
], s=>s.uid!)
assert.equal(merged.filter(s=>s.item.uid===shared.uid).length,1)
assert.deepEqual(new Set(merged.find(s=>s.item.uid===shared.uid)!.matchedSubcategoryKeys),new Set(['健身房','武术搏击']))
assert.equal(merged.length,41,'No hard category cap when no alternatives exist')

async function run() {
 const form:FormState = { points:[
  {id:'p1',name:'望京',address:'',lng:116.4814,lat:39.9961,mode:'transit',source:'search'},
  {id:'p2',name:'国贸',address:'',lng:116.459,lat:39.9095,mode:'transit',source:'search'},
 ],category:{primary:'fun',secondary:'全部分类'},timeDiff:20 }
 const mock = await computeMockResult(form)
 assert(mock.shops.length>0)
 assert(mock.shops.every(s=>passesHardFairness(s)&&withinLeisureCommuteLimit(s)))
 const movie = await computeMockResult({...form,category:{primary:'fun',secondary:'电影'}})
 assert(movie.shops.every(s=>s.sub==='电影'))
 console.log('CONTINUATION_REPORT='+JSON.stringify({shareLengths,recallQueries:leisureRecallBranches(form.category),
  synthetic:{recall:leisureDistribution(ranked),shortlist:leisureDistribution(shortlist),top10:leisureDistribution(final.slice(0,10))},
  mock:{qualified:leisureDistribution(mock.shops),top10:leisureDistribution(mock.shops.slice(0,10))}}))
 console.log('分享 v1/v2、中文完整性、隐私字段、shortlist、Top1、软上限、补位、确定性、100分钟与具体子品类验收通过')
}
run().catch(error=>{console.error(error);process.exitCode=1})
