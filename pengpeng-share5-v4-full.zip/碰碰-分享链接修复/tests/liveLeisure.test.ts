// Optional live smoke test. Uses real SCF requests; never runs as part of npm test.
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { writeFileSync } from 'node:fs'
import { computeRealResult } from '../src/services/compute'
import { getRecallBranches } from '../src/utils/resultPipeline'
import { leisureRecallBranches } from '../src/utils/leisureDiversity'
import type { FormState } from '../src/types'
const exec = promisify(execFile)
;(globalThis as any).window = globalThis
// curl uses the execution environment's network proxy. Responses remain live and unmodified.
;(globalThis as any).fetch = async (url: string, options?: { signal?: AbortSignal }) => {
  const { stdout } = await exec('curl', ['-sS','--max-time','45','-w','\n%{http_code}',url], {
    maxBuffer: 10 * 1024 * 1024, signal: options?.signal,
  })
  const split = stdout.lastIndexOf('\n')
  return new Response(stdout.slice(0,split),{ status: Number(stdout.slice(split+1)) })
}
const tables: unknown[] = [], stages: Record<string, unknown> = {}
const info = console.info
console.table = (data: unknown) => { tables.push(data) }
console.info = (...args: unknown[]) => { if (typeof args[0] === 'string' && args[0].startsWith('[leisure-all]')) stages[args[0]] = args[1]; else info(...args) }
const form: FormState = { points: [
  {id:'test-a',name:'测试起点A·望京SOHO',address:'望京SOHO',lng:116.4814,lat:39.9961,mode:'transit',source:'search'},
  {id:'test-b',name:'测试起点B·国贸',address:'国贸',lng:116.459,lat:39.9095,mode:'transit',source:'search'},
], category: {primary:'fun',secondary:'全部分类'}, timeDiff:20 }
const started = Date.now()
computeRealResult(form, progress => console.log('LIVE_PROGRESS',JSON.stringify(progress))).then(result => {
  const report = { at:new Date().toISOString(), seconds:(Date.now()-started)/1000, form,
    queries:leisureRecallBranches(form.category), stages, tables, result }
  writeFileSync('live-leisure-report.json',JSON.stringify(report,null,2))
  if (result.reason !== 'ok') throw new Error('No live qualified results; inspect live-leisure-report.json')
  console.log('LIVE_RESULT',JSON.stringify({reason:result.reason,count:result.shops.length,seconds:report.seconds}))
}).catch(error=>{console.error(error);process.exitCode=1})
