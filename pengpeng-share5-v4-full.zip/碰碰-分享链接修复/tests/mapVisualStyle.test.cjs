// Presentation adapter contract: no SDK / failed style / reset must never break the map.
const assert=require('node:assert/strict')
const fs=require('node:fs')
const path=require('node:path')
const ts=require('typescript')
const source=fs.readFileSync(path.join(__dirname,'../src/components/brand/mapVisualStyle.ts'),'utf8')
const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText
const mod={exports:{}};new Function('module','exports',js)(mod,mod.exports)
const {applyMapVisualStyle,WARM_PAPER_MAP_STYLE}=mod.exports
assert.equal(applyMapVisualStyle({},'warmPaper'),'default')
const calls=[];const map={setMapStyleV2:o=>calls.push(o)}
assert.equal(applyMapVisualStyle(map,'warmPaper'),'warmPaper')
assert.equal(calls[0].styleJson,WARM_PAPER_MAP_STYLE)
assert.equal(applyMapVisualStyle(map,'default'),'default')
assert.deepEqual(calls[1].styleJson,[])
let fallback=0
assert.equal(applyMapVisualStyle({setMapStyleV2(){throw new Error('unsupported')},setMapStyle(o){assert.equal(o.style,'normal');fallback++}},'warmPaper'),'default')
assert.equal(fallback,1)
assert.equal(applyMapVisualStyle({setMapStyleV2(){throw new Error('offline')},setMapStyle(){throw new Error('offline')}},'warmPaper'),'default')
assert(WARM_PAPER_MAP_STYLE.every(r=>!Object.keys(r.stylers).some(k=>['visibility','weight','zoom'].includes(k))))
console.log('Map style contracts passed: unsupported, apply, reset, exception fallback, labels/geometry preserved.')
