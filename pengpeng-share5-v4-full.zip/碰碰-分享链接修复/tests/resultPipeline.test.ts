import type { ShopWithCommute } from '../src/types'
import { computeMockResult } from '../src/mock/compute'
import {
  computeAllRoutes,
  diversityRerank,
  getRecallBranches,
  inferBrandKey,
  mergeRecallGroups,
  passesHardFairness,
  rankEligibleShops,
} from '../src/utils/resultPipeline'

function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message)
}

function makeShop(
  id: string,
  name: string,
  sub: string,
  commuteTimes: number[],
): ShopWithCommute {
  const fairness = Math.max(...commuteTimes) - Math.min(...commuteTimes)
  const avg = commuteTimes.reduce((sum, value) => sum + value, 0) / commuteTimes.length
  return {
    id,
    name,
    primary: 'drink',
    sub,
    category: sub,
    area: '测试区域',
    lng: 116.4,
    lat: 39.9,
    rating: 4.5,
    perCapita: 40,
    hours: '10:00-22:00',
    intro: '',
    images: [],
    commutes: commuteTimes.map((minutes, index) => ({
      pointId: `p${index}`,
      pointName: `出发点${index + 1}`,
      mode: 'transit',
      minutes,
      fare: 3,
    })),
    fairness,
    avg,
  }
}

async function run() {
  // 场景 A：奶茶咖啡「全部分类」按当前 UI 二级品类拆分为 5 个召回分支。
  const drinkBranches = getRecallBranches({ primary: 'drink', secondary: '全部分类' })
  assert(
    drinkBranches.map((branch) => branch.subcategory).join('|') ===
      '咖啡馆|奶茶店|冰激凌店|茶馆|烘焙面包店',
    '奶茶咖啡全部分类没有按当前 UI 子品类拆分',
  )

  const quotaGroups = drinkBranches.map((branch, groupIndex) => ({
    subcategory: branch.subcategory,
    items: Array.from({ length: 10 }, (_, itemIndex) => ({ id: `${groupIndex}-${itemIndex}` })),
  }))
  const recalled = mergeRecallGroups(quotaGroups, (item) => item.id)
  // 5 个分支、每类 10 条，去重后全部进入候选池（目标 50）。
  assert(recalled.length === 50, `五子品类候选池应为 50 家，实际 ${recalled.length}`)
  for (const branch of drinkBranches) {
    assert(
      recalled.filter((item) => item.subcategory === branch.subcategory).length === 10,
      `${branch.subcategory}没有获得候选`,
    )
  }

  // Mock 端到端：时间差 > 60 的店必须被系统硬过滤掉。
  const mockResult = await computeMockResult({
    points: [
      { id: 'a', name: '甲', address: '', lng: 116.415, lat: 39.915, mode: 'transit', source: 'search' },
      { id: 'b', name: '乙', address: '', lng: 116.425, lat: 39.925, mode: 'transit', source: 'search' },
    ],
    category: { primary: 'drink', secondary: '全部分类' },
    timeDiff: 10,
  })
  assert(mockResult.shops.length > 0, 'Mock 场景 A 没有返回结果')
  for (const shop of mockResult.shops) {
    assert(shop.fairness <= 60, `Mock 结果残留时间差 > 60 的店：${shop.name}(${shop.fairness})`)
  }

  // 系统硬过滤：fairness <= 60 通过，> 60 淘汰。
  assert(passesHardFairness(makeShop('ok', '时间差50', '咖啡馆', [20, 70])), '时间差 50 应通过硬过滤')
  assert(!passesHardFairness(makeShop('bad', '时间差61', '咖啡馆', [20, 81])), '时间差 61 应被硬过滤淘汰')
  assert(passesHardFairness(makeShop('eq', '时间差60', '咖啡馆', [30, 90])), '时间差 60 是临界值，应通过')

  // 场景 B：两家都满足时，25/35 必须排在 80/80 前。
  const slowFair = makeShop('slow', '慢但完全相同', '咖啡馆', [80, 80])
  const fastAcceptable = makeShop('fast', '快且差值可接受', '奶茶店', [25, 35])
  const ranked = rankEligibleShops([slowFair, fastAcceptable])
  assert(ranked[0].id === 'fast', '最终排序仍然错误地把时间差放在平均通勤之前')

  // 场景 F：平均通勤相近时，时间差小的必须排在前面（加权排序核心验收）。
  const closeAvgUnfair = makeShop('unfair', '平均略短但差大', '咖啡馆', [20, 40])
  const closeAvgFair = makeShop('fair', '平均略长但差小', '奶茶店', [32, 36])
  const rankedFair = rankEligibleShops([closeAvgUnfair, closeAvgFair])
  assert(rankedFair[0].id === 'fair', '平均相近时时间差小的没有排到前面')

  // 极端差距仍由平均通勤主导：[25,35] 快但差10分钟，仍排在 [80,80] 前。
  const extremeFast = makeShop('fast-ext', '快但差大', '咖啡馆', [25, 35])
  const extremeSlow = makeShop('slow-ext', '慢但完全公平', '奶茶店', [80, 80])
  const rankedExtreme = rankEligibleShops([extremeSlow, extremeFast])
  assert(rankedExtreme[0].id === 'fast-ext', '平均差距过大时不应被公平性反超')

  // 场景 C：Top N 全部完成通勤计算，不根据合格数量提前停止。
  const allCandidates = Array.from({ length: 30 }, (_, index) => index)
  let progressSeen = 0
  const allComputed = await computeAllRoutes(
    allCandidates,
    async (index) => index,
    (done) => { progressSeen = done },
  )
  assert(allComputed.length === 30, 'Top 30 没有全部完成通勤计算（提前停止了）')
  assert(progressSeen === 30, '路线计算进度没有走到 30')

  // 场景 D：Top 30 全部计算完，不根据合格数量提前截断。
  const partial = await computeAllRoutes(
    Array.from({ length: 30 }, (_, index) => index),
    async (index) => index,
  )
  assert(partial.length === 30, '不应提前截断候选')

  // 场景 E：多样性软重排不丢弃任何候选；同品牌前 3 家进前排，其余排到后面。
  assert(inferBrandKey('星巴克臻选（太古里店）') === inferBrandKey('星巴克咖啡（国贸店）'), '品牌归一化失败')
  const repeatedBrand = Array.from({ length: 8 }, (_, index) =>
    makeShop(`starbucks-${index}`, `星巴克（第${index + 1}店）`, '咖啡馆', [20 + index, 22 + index]),
  )
  const alternatives = Array.from({ length: 20 }, (_, index) =>
    makeShop(`other-${index}`, `独立品牌${index}`, index % 2 ? '奶茶店' : '茶馆', [40 + index, 42 + index]),
  )
  const brandReranked = diversityRerank([...repeatedBrand, ...alternatives], false)
  assert(brandReranked.length === 28, '多样性软重排不应丢弃任何候选（剩多少展示多少）')
  const brandOf = (s: ShopWithCommute) => inferBrandKey(s.name)
  const head3 = brandReranked.slice(0, 3).every((s) => brandOf(s) === '星巴克')
  assert(head3, '前排没有优先保留 3 家同品牌')
  const tail5 = brandReranked.slice(-5).every((s) => brandOf(s) === '星巴克')
  assert(tail5, '超出品牌配额的同品牌应被延后到末尾而非丢弃')
  const totalStarbucks = brandReranked.filter((s) => brandOf(s) === '星巴克').length
  assert(totalStarbucks === 8, '同品牌不应被硬丢弃')

  // 「全部分类」时做子品类多样性：单品类不应占据前排全部。
  const coffee = Array.from({ length: 20 }, (_, index) =>
    makeShop(`coffee-${index}`, `咖啡品牌${index}`, '咖啡馆', [20 + index, 22 + index]),
  )
  const tea = Array.from({ length: 8 }, (_, index) =>
    makeShop(`tea-${index}`, `茶饮品牌${index}`, '奶茶店', [45 + index, 47 + index]),
  )
  const categoryReranked = diversityRerank([...coffee, ...tea], true)
  assert(categoryReranked.length === 28, '子品类重排不应丢弃候选')
  // 前 18 位里咖啡不超过 10（其余位置被茶饮提前），验证子品类多样性生效。
  const coffeeInHead = categoryReranked.slice(0, 18).filter((s) => s.sub === '咖啡馆').length
  assert(coffeeInHead <= 10, '全部分类的前排仍被单一子品类占据')

  console.log('店铺筛选管线验收通过：A/B/C/D/E/F 全部场景通过。')
}

run().catch((error) => {
  console.error(error)
  throw error
})
