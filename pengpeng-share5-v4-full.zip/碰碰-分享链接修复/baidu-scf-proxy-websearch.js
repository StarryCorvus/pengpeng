// ============================================================
// 碰碰 SCF 代理（联网搜索版）—— 与原版 baidu-scf-proxy.js 并存，互不覆盖
// 差异：店铺 AI 文案改走火山方舟 Responses API (/api/v3/responses)，
//       并开启豆包联网搜索（tools: web_search），可实时检索该店铺的
//       评价/菜单/排队/营业等公开信息；其余百度路线/POI/逆地理能力不变。
//
// 【部署前必须满足】（缺一会返回 400/鉴权错误，前端会自动降级为无 AI 文案）：
//   1) 在火山方舟控制台「服务组件库」开通「联网内容插件」（联网搜索组件）；
//   2) 所用推理接入点(ARK_ENDPOINT_ID)对应模型需支持 web_search 工具；
//   3) ARK_API_KEY 具备该模型 + 联网搜索的调用权限。
// 环境变量：BAIDU_AK / BAIDU_SK / ARK_API_KEY / ARK_ENDPOINT_ID（与原版相同）
// ============================================================
const crypto = require('crypto')
const https = require('https')
const AK = process.env.BAIDU_AK
const SK = process.env.BAIDU_SK
const ARK_API_KEY = process.env.ARK_API_KEY
const ARK_ENDPOINT_ID = process.env.ARK_ENDPOINT_ID
const ROUTES = {
  transit: '/direction/v2/transit',
  driving: '/direction/v2/driving',
  walking: '/direction/v2/walking',
  riding: '/direction/v2/riding',
}
function sign(path, params, sk) {
  const sorted = Object.keys(params)
    .sort()
    .map((k) => `${k}=${params[k]}`)
    .join('&')
  const raw = path + '?' + sorted + sk
  return crypto.createHash('md5').update(raw, 'utf8').digest('hex')
}
function baiduRequest(path, params) {
  return new Promise((resolve, reject) => {
    const allParams = { ...params, ak: AK, output: 'json' }
    allParams.sn = sign(path, allParams, SK)
    const qs = new URLSearchParams(allParams).toString()
    const options = {
      hostname: 'api.map.baidu.com',
      path: path + '?' + qs,
      method: 'GET',
    }
    const req = https.request(options, (res) => {
      let data = ''
      res.on('data', (chunk) => (data += chunk))
      res.on('end', () => {
        try { resolve(JSON.parse(data)) }
        catch (e) { reject(e) }
      })
    })
    req.on('error', reject)
    req.end()
  })
}
async function handleRoute(q) {
  const mode = q.mode || 'transit'
  const path = ROUTES[mode]
  if (!path) throw new Error('invalid mode')
  if (!q.city) throw new Error('city 参数必填')
  const params = {
    origin: `${q.origin_lat},${q.origin_lng}`,
    destination: `${q.dest_lat},${q.dest_lng}`,
    region: q.city,
    coord_type: 'bd09ll',
  }
  if (mode === 'transit') {
    params.tactics = 8
  } else if (mode === 'driving') {
    params.tactics = 0
  }
  return await baiduRequest(path, params)
}
async function handleSearch(q) {
  const path = '/place/v2/search'
  const pageSize = Math.min(20, parseInt(q.page_size) || 10)
  const pageNum = parseInt(q.page_num) || 0
  if (!q.city) throw new Error('city 参数必填')
  return await baiduRequest(path, {
    query: q.keyword || '',
    region: q.city,
    location: `${q.lat},${q.lng}`,
    radius: parseInt(q.radius) || 8000,
    page_size: pageSize,
    page_num: pageNum,
    scope: 2,
    tag: q.tag || '',
  })
}
async function handleReverseGeocode(q) {
  const path = '/reverse_geocoding/v3'
  return await baiduRequest(path, {
    location: `${q.lat},${q.lng}`,
    coordtype: 'bd09ll',
  })
}

// ---------- AI 生成店铺推荐文案（方舟 Responses API + 豆包联网搜索） ----------

/**
 * 调用方舟 Responses API（非流式），开启 web_search 联网检索。
 * @param {string} instructions 系统提示词
 * @param {string} userContent  用户提问
 * @returns {Promise<any>} 原始 response 对象
 */
function callArkResponses(instructions, userContent) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      model: ARK_ENDPOINT_ID,
      instructions,
      input: [{ role: 'user', content: [{ type: 'input_text', text: userContent }] }],
      max_output_tokens: 1500,
      // 联网内容插件：默认全网 search_engine 检索（可加 sources:["douyin","toutiao","moji"]）
      // max_keyword：单轮最多关键词数；limit：单次搜索返回条数；max_tool_calls：最多搜索轮次
      tools: [{ type: 'web_search', max_keyword: 2, limit: 6 }],
      max_tool_calls: 2,
    })
    const options = {
      hostname: 'ark.cn-beijing.volces.com',
      path: '/api/v3/responses',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ARK_API_KEY}`,
      },
    }
    const req = https.request(options, (res) => {
      let data = ''
      res.on('data', (chunk) => (data += chunk))
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data)
          if (res.statusCode < 200 || res.statusCode >= 300) {
            reject(new Error(`ark http ${res.statusCode}: ${JSON.stringify(parsed).slice(0, 300)}`))
            return
          }
          resolve(parsed)
        } catch (e) {
          reject(e)
        }
      })
    })
    req.on('error', reject)
    req.write(body)
    req.end()
  })
}

/**
 * 从 Responses API 返回体里抽出最终文案。
 * 优先用顶层 output_text，否则遍历 output 里 type=message 的 output_text/text 拼接。
 */
function extractAssistantText(resp) {
  if (resp && typeof resp.output_text === 'string' && resp.output_text.trim()) {
    return resp.output_text.trim()
  }
  const out = (resp && Array.isArray(resp.output)) ? resp.output : []
  const parts = []
  const grab = (content) => {
    if (typeof content === 'string') { parts.push(content); return }
    if (!Array.isArray(content)) return
    for (const c of content) {
      if (c && (c.type === 'output_text' || c.type === 'text' || c.type === 'input_text') && typeof c.text === 'string') {
        parts.push(c.text)
      }
    }
  }
  for (const item of out) {
    if (item && item.type === 'message') grab(item.content)
  }
  let text = parts.join('\n').trim()
  // 兜底：上面没拿到时，递归捞 output 里任意字符串 text
  if (!text) {
    const scan = (node) => {
      if (!node) return
      if (typeof node === 'string') return
      if (Array.isArray(node)) { node.forEach(scan); return }
      if (typeof node === 'object') {
        for (const k of Object.keys(node)) scan(node[k])
      }
    }
    out.forEach((item) => {
      if (item && typeof item.text === 'string' && item.text.trim()) parts.push(item.text)
      else scan(item)
    })
    text = parts.join('\n').trim()
  }
  return text
}

async function handleAiIntro(q) {
  if (!ARK_API_KEY || !ARK_ENDPOINT_ID) {
    throw new Error('AI 接口未配置（ARK_API_KEY / ARK_ENDPOINT_ID）')
  }
  const name = q.name || ''
  const address = q.address || ''
  const category = q.category || ''
  const rating = q.rating || ''
  const perCapita = q.per_capita || ''
  const tags = q.tags || ''
  const hours = q.hours || ''
  const intro = q.intro || ''
  const people = q.people || ''
  const avgMinutes = q.avg_minutes || ''
  const maxMinutes = q.max_minutes || ''
  const fairnessMinutes = q.fairness_minutes || ''
  const city = q.city || ''
  // 周边 POI：暂未在服务端抓取，留空；后续接入周边检索后回填
  const nearby = ''

  const systemPrompt = `你是「碰碰」的本地生活推荐助手，帮约好碰面的人写一句朋友式小推荐。可联网查这家店的公开信息（大众点评、小红书、官方账号等）和它周边可逛可玩的地方。
只基于【百度地图数据】+【联网公开信息】写，不要编造店名、地址、电话、未查证的价格。
按下面结构输出，每条一两句、带 emoji，贴合这家店的品类（美食餐厅/奶茶咖啡/休闲娱乐/综合购物中心/超市购物），不要默认是吃饭：
1. ⭐ 这家店最值得体验的（按品类写：餐饮写招牌必点；奶茶咖啡写招牌饮品、出片角落；休闲娱乐写玩法体验；购物中心写好不好逛；超市购物写顺手买点啥）
2. 🚶 周边顺路可逛可玩（联网搜附近步行/骑车可达的商圈、公园、小店，挑 1-2 个说为什么顺道）
3. ⚠️ 避坑（只写确实查到的：排队、停车、嘈杂、性价比、人多时段）
4. 👥 适合谁/什么氛围（聚餐/约会/聊事/放空）
某条确实没有可写的就整条省略，绝不写"信息有限""暂无""未知"这类占位话。不要单独写"好的/这家我帮你摸清啦"这类开头寒暄，直接从第一条⭐开始写。总字数 80-100，口语像朋友推荐，不要列来源链接，直接给结论。`

  const userPrompt = `【百度地图基础数据】
店铺：${name} / ${address} / ${category} / 评分${rating || '未知'} / 人均${perCapita ? perCapita + '元' : '未知'} / 标签${tags || '未知'} / 营业${hours || '未知'}
网友评价摘要：${intro || '信息有限'}
碰面背景：${people ? people + '人' : '人数未知'}，${city ? '在' + city : ''}，想做${category || '未知'}。

请联网做两件事：① 查「${name}」（${city ? city + '，' : ''}${address}）这家店本身的招牌和近期评价；② 查它周边步行/骑车可达还有什么可逛可玩。然后生成碰碰小tip：`

  const resp = await callArkResponses(systemPrompt, userPrompt)
  const text = extractAssistantText(resp)
  const FIXED_OPENING = '碰碰帮你找到了这家店信息，可供你挑选参考哦～'
  return { text: FIXED_OPENING + '\n' + text }
}

exports.main = async (event) => {
  const q = event.queryString || {}
  const action = q.action || 'route'
  try {
    let result
    if (action === 'search') {
      result = await handleSearch(q)
    } else if (action === 'reverse_geocode') {
      result = await handleReverseGeocode(q)
    } else if (action === 'ai_intro') {
      result = await handleAiIntro(q)
    } else {
      result = await handleRoute(q)
    }
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify(result),
    }
  } catch (e) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: e.message }),
    }
  }
}
