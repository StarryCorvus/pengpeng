// ============================================================
// Webpack 配置（纯 JS 构建管线，无原生二进制依赖）：
// 开发：webpack serve --mode development
// 构建：webpack --mode production（产物在 dist/，可直接双击 index.html 打开）
// ============================================================

const path = require('path')
const webpack = require('webpack')
const HtmlWebpackPlugin = require('html-webpack-plugin')

// 百度地图浏览器端 AK（从环境变量读取，默认用开发 key）
const BAIDU_MAP_AK = process.env.BAIDU_MAP_AK || 'n4epLnUaFw1u1D5Jdcg8a86keKvJKWOk'

module.exports = (env, argv) => {
  const isProd = argv.mode === 'production'
  return {
    context: __dirname,
    entry: path.resolve(__dirname, 'src/main.tsx'),
    output: {
      path: path.resolve(__dirname, 'dist'),
      filename: isProd ? 'assets/[name].[contenthash:8].js' : 'assets/[name].js',
      // 生产构建用相对路径（dist/index.html 可直接双击打开）；开发服务器需要根路径
      publicPath: isProd ? './' : '/',
      clean: true,
    },
    resolve: {
      extensions: ['.tsx', '.ts', '.js'],
    },
    module: {
      rules: [
        { test: /\.(png|svg|webp|woff2)$/i, type: "asset/inline" },
        {
          test: /\.tsx?$/,
          exclude: /node_modules/,
          use: {
            loader: 'ts-loader',
            options: { transpileOnly: true },
          },
        },
        {
          test: /\.css$/,
          use: ['style-loader', 'css-loader'],
        },
      ],
    },
    plugins: [
      new webpack.DefinePlugin({
        'process.env.BAIDU_MAP_AK': JSON.stringify(BAIDU_MAP_AK),
      }),
      new HtmlWebpackPlugin({
        template: path.resolve(__dirname, 'index.html'),
        inject: 'body',
        templateParameters: {
          BAIDU_MAP_AK: BAIDU_MAP_AK,
        },
      }),
      new HtmlWebpackPlugin({
        filename: 'share.html',
        template: path.resolve(__dirname, 'share.html'),
        inject: false,
      }),
    ],
    devServer: {
      host: '0.0.0.0',
      port: 5173,
      hot: false,
      historyApiFallback: true,
      client: { overlay: true },
    },
    performance: { hints: false },
    devtool: isProd ? false : 'eval-source-map',
  }
}
