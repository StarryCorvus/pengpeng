# 碰碰｜最新增量说明（share5 / v4）

本工程包在 `碰碰-微信分享链接修复-完整工程.zip` 的基础上，回写了 2026-10-07 已部署到 GitHub Pages 的最新分享链路。

## 当前分享链路

- 新分享地址固定指向轻量接收页：`https://starrycorvus.github.io/share.html?v=20261007-share5#/share/v4...`
- `v4` 只携带分享页必需字段：店铺名称、城市/区域/地址/坐标、评分/人均/品类、通勤数据、平均通勤、时间差、生成时间。
- AI 小 tip **不再写入新分享 URL**，避免中文长文本经 Base64URL 后显著拉长链接。
- 发送者自己的详情页与保存长图仍可显示原 AI tip；只是接收者通过新 v4 链接看到的轻量页暂不包含这段 tip。

## 轻量接收页

- 新增独立 `share.html`，不启动完整 React 主应用，也不加载百度地图 SDK。
- 分享页采用与碰碰主站一致的纸张视觉变量：纸张底色、卡片底色、细边框、纸张圆角与轻阴影；无额外渐变。
- `share.html` 继续兼容：
  - `v4` 当前短链接；
  - `v3` 中间 Base64URL 元组链接；
  - `v2` lz-string 压缩链接；
  - 最早无前缀 `eyJ...` v1 链接。
- 根站如果收到历史 `/#/share/...`，会在主应用/百度 SDK 启动前重定向到 `share.html?v=20261007-share5`。
- 分享页加入 no-cache 元信息，降低手机/微信 WebView 长时间保留旧 UI 的概率。

## 构建

`webpack.config.cjs` 已将 `share.html` 纳入 `dist/` 构建产物。执行：

```sh
npm ci
npm run build
```

将生成：

- `dist/index.html`
- `dist/share.html`
- `dist/assets/main.*.js`

完整单文件 Real 仍可通过 `scripts/build-standalone.mjs` 生成；公开部署时 `index.html` 与 `share.html` 需要同时存在。

## 未改动

本次回写只同步已经在线验证的分享链路增量，不调整候选召回、通勤计算、挑战者机制、Top20、多样性排序、评分/人均逻辑、地图结果逻辑等业务部分。
