const crypto = require('crypto')
const https = require('https')
const AK = process.env.BAIDU_AK
const SK = process.env.BAIDU_SK
const ARK_API_KEY = process.env.ARK_API_KEY
const ARK_ENDPOINT_ID = process.env.ARK_ENDPOINT_ID
const ROUTES = {
  transit: '/direction/v2/transit',
  driving: '/direction/v2/driving',
  walking: '/direction/v2/walking',
  riding: '/direction/v2/riding',
}
function sign(path, params, sk) {
  const sorted = Object.keys(params)
    .sort()
    .map((k) => `${k}=${params[k]}`)
    .join('&')
  const raw = path + '?' + sorted + sk
  return crypto.createHash('md5').update(raw, 'utf8').digest('hex')
}
function baiduRequest(path, params) {
  return new Promise((resolve, reject) => {
    const allParams = { ...params, ak: AK, output: 'json' }
    allParams.sn = sign(path, allParams, SK)
    const qs = new URLSearchParams(allParams).toString()
    const options = {
      hostname: 'api.map.baidu.com',
      path: path + '?' + qs,
      method: 'GET',
    }
    const req = https.request(options, (res) => {
      let data = ''
      res.on('data', (chunk) => (data += chunk))
      res.on('end', () => {
        try { resolve(JSON.parse(data)) }
        catch (e) { reject(e) }
      })
    })
    req.on('error', reject)
    req.end()
  })
}
async function handleRoute(q) {
  const mode = q.mode || 'transit'
  const path = ROUTES[mode]
  if (!path) throw new Error('invalid mode')
  if (!q.city) throw new Error('city 参数必填')
  const params = {
    origin: `${q.origin_lat},${q.origin_lng}`,
    destination: `${q.dest_lat},${q.dest_lng}`,
    region: q.city,
    coord_type: 'bd09ll',
  }
  if (mode === 'transit') {
    params.tactics = 8
  } else if (mode === 'driving') {
    params.tactics = 0
  }
  return await baiduRequest(path, params)
}
async function handleSearch(q) {
  const path = '/place/v2/search'
  const pageSize = Math.min(20, parseInt(q.page_size) || 10)
  const pageNum = parseInt(q.page_num) || 0
  if (!q.city) throw new Error('city 参数必填')
  return await baiduRequest(path, {
    query: q.keyword || '',
    region: q.city,
    location: `${q.lat},${q.lng}`,
    radius: parseInt(q.radius) || 8000,
    page_size: pageSize,
    page_num: pageNum,
    scope: 2,
    tag: q.tag || '',
  })
}
async function handleReverseGeocode(q) {
  const path = '/reverse_geocoding/v3'
  return await baiduRequest(path, {
    location: `${q.lat},${q.lng}`,
    coordtype: 'bd09ll',
  })
}

/**
 * AI 生成店铺推荐文案（火山引擎方舟 / 豆包）
 * 不调用额外百度API，仅基于传入的店铺信息 + 豆包知识库生成
 */
function callArkChat(messages, maxTokens) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      model: ARK_ENDPOINT_ID,
      messages,
      max_tokens: maxTokens || 300,
      temperature: 0.7,
    })
    const options = {
      hostname: 'ark.cn-beijing.volces.com',
      path: '/api/v3/chat/completions',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${ARK_API_KEY}`,
      },
    }
    const req = https.request(options, (res) => {
      let data = ''
      res.on('data', (chunk) => (data += chunk))
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data)
          resolve(parsed)
        } catch (e) {
          reject(e)
        }
      })
    })
    req.on('error', reject)
    req.write(body)
    req.end()
  })
}

async function handleAiIntro(q) {
  if (!ARK_API_KEY || !ARK_ENDPOINT_ID) {
    throw new Error('AI 接口未配置（ARK_API_KEY / ARK_ENDPOINT_ID）')
  }
  const name = q.name || ''
  const address = q.address || ''
  const category = q.category || ''
  const rating = q.rating || ''
  const perCapita = q.per_capita || ''
  const tags = q.tags || ''
  const hours = q.hours || ''
  const intro = q.intro || ''
  // 碰面背景（前端传入；未传则留空，模型按"信息有限"处理）
  const people = q.people || ''
  const avgMinutes = q.avg_minutes || ''
  const maxMinutes = q.max_minutes || ''
  const fairnessMinutes = q.fairness_minutes || ''
  const city = q.city || ''
  // 周边 POI：暂未在服务端抓取，留空；后续接入周边检索后回填
  const nearby = ''

  const systemPrompt = `你是「碰碰」的本地生活推荐助手。请只依据下面【系统已查证的真实数据】写，不要编造店名、地址、电话、价格。
按下面结构输出，每条一两句、带 emoji：
1. 🎯 为什么适合这次碰面（结合人数/通勤/时间差，比如等位、桌位、是否好集合）
2. 🍜 招牌/必体验（只从标签和点评里提炼，不硬编）
3. 🚶 周边顺路可逛（只从周边数据里挑 1-2 个；没有就写"信息有限"）
4. ⚠️ 避坑（从点评/周边判断：排队、停车、嘈杂、性价比、人多时段；没有就写"暂无明显雷点"）
5. 👥 适合谁/什么氛围（聚餐/约会/聊事）
数据不足的维度宁可写"信息有限"，也不要编。总字数 100-150，口语、像朋友推荐。`

  const userPrompt = `【系统已查证的真实数据】
店铺：${name} / ${address} / ${category} / 评分${rating || '未知'} / 人均${perCapita ? perCapita + '元' : '未知'} / 标签${tags || '未知'} / 营业${hours || '未知'}
网友评价摘要：${intro || '信息有限'}
周边：${nearby || '信息有限'}
本次碰面背景：${people ? people + '人' : '人数未知'}，平均通勤约${avgMinutes || '?'}分钟，最远${maxMinutes || '?'}分钟，时间差${fairnessMinutes || '?'}分钟${city ? '，在' + city : ''}，想做${category || '未知'}。

请生成碰碰小tip：`

  const resp = await callArkChat([
    { role: 'system', content: systemPrompt },
    { role: 'user', content: userPrompt },
  ], 500)

  const content = resp?.choices?.[0]?.message?.content || ''
  return { text: content.trim() }
}
exports.main = async (event) => {
  const q = event.queryString || {}
  const action = q.action || 'route'
  try {
    let result
    if (action === 'search') {
      result = await handleSearch(q)
    } else if (action === 'reverse_geocode') {
      result = await handleReverseGeocode(q)
    } else if (action === 'ai_intro') {
      result = await handleAiIntro(q)
    } else {
      result = await handleRoute(q)
    }
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify(result),
    }
  } catch (e) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: e.message }),
    }
  }
}
