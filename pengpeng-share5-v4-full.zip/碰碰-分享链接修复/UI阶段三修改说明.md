# 碰碰 UI 阶段三修改说明

当前交付完成 Phase A–F 的实现，并完成 Phase G 的本地构建、现有测试及 Mock 浏览器回归。真实百度 SDK 与实体手机验收仍未完成，未将其标记为通过。

## 基准与运行

唯一代码基准：`碰碰-完整工程-0920-UI视觉改版-阶段二.zip`。保持 React 18 / TypeScript / Webpack / 普通 CSS。没有添加应用依赖。

```sh
npm ci
npm run build
npm test
node tests/mapVisualStyle.test.cjs
node scripts/build-ui-deliverables.mjs
```

最后一条分别构建 Mock 和 Real，生成 `碰碰-UI阶段三-Mock.html`、`碰碰-UI阶段三-真实API.html`，并恢复原 src/config.ts。Mock 可双击打开；真实地图与接口仍需要原工程的网络、API 与服务配置。本轮未修改 SDK、API 地址或密钥配置。

## 已完成

| Phase | 结果 |
|---|---|
| A 基线 | 从阶段二 ZIP 解压；基线 build 和 A–F tests 通过；保留差异记录 |
| B Splash | 直接接入透明 peng＋两侧碰撞线；去掉旧 SVG 字标遮罩；按原图坐标组合；p/g 笔画完整；原猫狗动画 keyframes 保留；CTA 恢复“碰个面吧”；上下长波浪；slogan 保留 |
| C 插画 | raw 原样保存；两张 2048px 正式主题画仅去顶部透明留白；接入 people/category 映射；不再显示 Logo 角色占位；没有重绘 |
| D 标题/文案 | 390px 下 People 约71.76px、Category约59.67px；使用 clamp，短屏适当下调；标题下无波浪、无 underline；People CTA 改文案且仍进入 Category |
| E 材质 | People/Diary 用静态背景轮廓呈现轻纸边，内容及点击区域不裁切；保留已有日记胶带；Category 使用独立粗笔框，主线3.4px＋1.05px补线，固定路径，无运行时随机 |
| F light-only | head 中 color-scheme only light 和米色 theme-color；CSS 锁定 root/body/控件；不临时增加 dark tokens；不触碰地图内部渲染 |
| G 回归 | 双构建、现有 tests、Mock 浏览器交互、多尺寸、深色偏好、Chrome Auto Dark Mode 验收；真实与真机限制见下文 |

阶段二已认可的纸纹理、地图纸边、warmPaper/default、CTA 基本笔触与 Flow 顺序保留。没有更改搜索、召回、通勤、排序、AI 推荐或存储实现。

## 验证与证据

- `npm run build`、Real/Mock standalone：通过。
- 原有 `npm test`：A/B/C/D/E/F 全部通过；地图展示 adapter 的异常降级/复原 tests 通过。
- Mock Chromium：无 pageerror；增删碰友与最多6人、昵称、地址搜索、交通方式、箭头边界、真实触摸事件横滑、次品类回写、返回/Tab保持、地图拖拽/缩放/marker、切换主题、列表/详情、收藏、分享预览、日记新增/编辑/删除与拖拽通过。
- 390×844、320×568、360×640、1440×1000：标题不溢出、插画未被隐藏、可滚动；390×390 模拟键盘压缩后 CTA 可达。实体键盘行为尚未测试。
- 浏览器模拟 Android UA、深色偏好：computed brand colors 保持浅色；额外使用 Chrome Auto Dark Mode override 检查。截图注明模拟环境，不等同实体 Android/WebView。
- 原始猫狗与新上传版 hash 一致。6 份 display PNG 对应区域 RGBA 字节一致；两张主题画保留原始全宽与底边。
- 关键截图包含最终 Splash、动画 1300ms 碰撞后帧、People/Category 各尺寸、Diary、深色偏好与自动深色测试、地图 A/B、结果列表、Profile。

截图使用 QA 环境的 Noto Sans SC 保证中文可显示，未将该字体或浏览器验收依赖加入产品。外部店铺照片请求在 Mock 回归时主动阻断，采用产品原有图片 fallback。

## 未完成与下一步

1. **真实百度 SDK 验收**：Real HTML 的 React 页面可加载，但当前环境请求 api.map.baidu.com 返回 `net::ERR_CERT_AUTHORITY_INVALID`，因此无法验证真实地图配色、POI 标记、真实搜索/路线、真实 AI 请求。本轮没有绕过证书，也没有用 Mock 冒充真实结果。地图所有源码与阶段二保持一致。
2. **实体手机验收**：Android Chrome、系统 WebView、iOS、第三方浏览器强制改色、定位授权与实体键盘仍需在设备上检查；目前只有 Chromium 模拟和暗色 override 的证据。
3. **Category 最终 CTA 文案**：按指令保留集中常量“～”，等待用户确认，不擅自写新文案。
4. **分享导出和外部导航**：验证了分享预览，未验证真实设备的分享目标及外部地图唤起。

下一轮从 **Phase G 的真实环境/实体手机验收** 接续，优先打开真实API HTML。若发现特定浏览器改色或小高度问题，限于 `index.html`、`src/styles/brand.css` 修正；素材更换入口见《视觉资产替换说明》。不要重新做地图或业务管线。

## 检查点

Checkpoint 1 已先行交付完整可运行工程与 Mock HTML；后续2/3/4记录正式插画、标题材质、light-only，每步 build 通过。最终包包含当前完整源码与最新双版本 HTML；历史检查点不作为继续开发基准。最新继续开发基准为本阶段三最终 ZIP。

## 实际参考

本轮重新访问了 [Rough.js](https://github.com/rough-stuff/rough)、[Rough Notation](https://github.com/rough-stuff/rough-notation)、[Sketchbook UI](https://github.com/SarthakRawat-1/sketchbook-ui)、[Scribble UI](https://github.com/MitchForest/scribble-ui)、[scrawl-ui](https://github.com/AvighnaBasak/scrawl-ui)、[TornPaper](https://github.com/happy358/TornPaper)、[drawably](https://github.com/danielwh2/drawably)、[Motion](https://github.com/motiondivision/motion)、[canvas-confetti](https://github.com/catdad/canvas-confetti) 的项目页/README。采用局部静态视觉层与正常 DOM 分离的办法，没有移植组件栈或安装这些库。Coffee & Fun 仓库本轮访问失败，未声称核验其实现。

light-only 依据 [MDN color-scheme](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/color-scheme) 中 only light 的说明，并以浏览器行为实测。
