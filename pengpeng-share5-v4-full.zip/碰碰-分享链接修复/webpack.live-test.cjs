const path = require('path')
const base = require('./webpack.test.cjs')
module.exports = { ...base, entry: path.resolve(__dirname,'tests/liveLeisure.test.ts'),
  output: { path:path.resolve(__dirname,'.live-test-dist'),filename:'live-test.cjs',clean:true } }
