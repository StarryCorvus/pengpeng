# 碰碰 UI 阶段二修改说明

## 交付范围

本轮从 `碰碰-完整工程-0920-UI视觉改版-阶段交付.zip` 解压建立工作副本。上传的 `碰碰-UI改版-真实API(1).html` 与该 ZIP 内真实模式 HTML 字节一致。没有从早期 AI 推荐版或其他旧工程恢复文件。

Phase 1–7 的展示层实现已完成，Phase 8 的本地构建、现有测试和 Mock 浏览器回归已通过。真实百度 SDK 在测试环境遇到证书错误，因此本轮仍作为可运行的阶段版交付，不能声称真实暖色底图、真实通勤或 AI 已完成联网验收。

## 运行

- 双击 `碰碰-UI阶段二-Mock.html` 体验界面。数据沿用原 Mock；原工程的店铺照片会尝试外部图片请求，失败时沿用既有图标回退。
- `碰碰-UI阶段二-真实API.html` 保留当前真实业务配置，需要可访问原百度及代理服务的环境。
- 源码开发：`npm ci`，`npm run dev`。
- 构建：`npm run build`。
- 生成两种 HTML：`node scripts/build-ui-deliverables.mjs`。
- 原测试：`npm test`。
- 新增展示配置回退检查：`node tests/mapVisualStyle.test.cjs`。
- 未增加 npm 依赖。PNG 裁切脚本需要 Python/Pillow，但裁切结果已经包含在工程中，正常构建不需要 Python。

## 按 Phase 完成的内容

| Phase | 已实现 | 主要文件 |
| --- | --- | --- |
| 1 资产与 Splash | 原始 RGBA 保留，alpha bbox 加 12px 边距裁切；两只角色始终独立入场/碰撞/回弹/停稳；删除完整 Logo 保险帧和角色白底混合方案 | assets/brand/raw、display；BrandSplash、BrandIllustration |
| 2 品牌线条 | 固定双描 SVG 边框，CTA、标题下划线、品类选中圈；粗箭头 | RoughBorder.tsx、brand.css |
| 3 Carousel | 实际可点的左右箭头、边界禁用、触摸横滑、键盘左右切换、图标图片替换接口 | CategoryCarousel.tsx、categoryVisualMap.tsx |
| 4 纸面 | 静态可平铺 SVG 细纹，纸面背景有材质；不对地图和照片叠纸纹 | material/paper-grain.svg、brand.css |
| 5 地图纸边 | 四边不同固定 SVG 轮廓；去除 blur 主体；边缘层不拦截指针；无地图全局滤镜 | PaperMapFrame.tsx、material/edge-*.svg |
| 6 暖色地图 | 官方 setMapStyleV2 色彩配置、原地图/暖纸切换、能力检查与同步异常回退；Mock 提供配色示意 | mapVisualStyle.ts、BaiduMap.tsx、ResultPage.tsx |
| 7 People | 强化人名，弱化交通方式 select 的视觉盒子，碰友卡改为纸条层级 | brand.css |
| 8 回归 | 两种构建、原测试、展示回退契约测试、Mock 浏览器检查及多尺寸截图 | 阶段二验收记录 |

未定装饰性文案统一改为 `～` / `～～～` / `⋯`，集中到 `src/config/brandVisual.ts`。确认过的 slogan、“谁要碰碰”“想干什么？”“碰友集结完毕”保留。品类下一步暂用 `～`，但按钮保留“查找推荐地点”可访问名称。功能说明、校验提示和原业务文案不盲目替换成符号。

## 本轮修改的既有文件

| 文件 | 改动 |
| --- | --- |
| webpack.config.cjs | 增加 PNG/SVG/WebP 的 asset/inline，保证独立 HTML 含素材 |
| scripts/build-ui-deliverables.mjs | 输出名改为 UI阶段二；模式构建与 finally 恢复机制不变 |
| src/pages/FormPage.tsx | 装饰文案引用、rough 装饰、按钮可访问名称；原步骤/校验/状态绑定保留 |
| src/pages/ResultPage.tsx | 纯展示配色 state、配色开关、地图展示 props；结果计算与筛选代码不改 |
| src/styles/brand.css | 透明角色布局、双描线、箭头、纸纹、撕纸边、People 细化与 Mock 配色 |
| src/components/brand/BrandSplash.tsx | 透明角色和独立 wordmark，保留原动画节奏 |
| src/components/brand/BrandIllustration.tsx | 透明猫狗组合、src/leftSrc/rightSrc 插槽 |
| src/components/brand/CategoryCarousel.tsx | 展示性交互；CATEGORY_TREE 和 FormState 语义不变 |
| src/components/brand/categoryVisualMap.tsx | 可选 imageSrc/iconComponent/alt/accent；图片优先 |
| src/components/brand/PaperMapFrame.tsx | 以固定轮廓取代模糊层 |
| src/components/brand/brandAssets.ts | 集中角色、字标和主题插画入口 |
| src/components/result/MockMap.tsx | 仅扩展可选展示 props 类型；原拖拽/缩放/Marker 代码不改 |
| src/components/result/BaiduMap.tsx | 添加独立地图配色 effect 和 props；Marker 墨色/推荐 sage 颜色；不改位置计算、数量、事件或数据 |

新增配置、纯展示组件、素材和回退测试。逐文件哈希及准确行范围在 `阶段二验收记录/基准校验.json`、`阶段二验收记录/改动行范围.md`，代码差异见同目录 patch。

## 测试证据

- 修改前：build 通过；原 A–F 筛选管线场景通过。
- 修改后：TypeScript + Webpack 的 Mock/Real 两种构建通过；原 A–F 场景通过。
- 展示适配器：缺少 setMapStyleV2、应用暖色、清空样式、同步异常回退和全部回退异常均不向业务层抛错；样式没有隐藏地图元素或改道路宽度。
- Mock Chromium：透明角色稳定显示、开屏隐藏导航、2～6 人限制、添加/删除、昵称、地址搜索选择、交通方式、箭头边界、实际触摸横滑、品类回写、返回/Tab 保留、地图拖动/缩放、Marker 预览、列表/详情、收藏、分享预览、日记新增/拖拽通过。无未捕获页面异常。
- 390×844、320×568 和 1440×1000 桌面 phone frame 检查通过；320px 无页面横向溢出；减少动态效果时角色及字标直接可见。
- 真实 HTML 能渲染，但百度 SDK 请求报 `ERR_CERT_AUTHORITY_INVALID`；SDK 未加载。该结果是环境阻塞，不是已通过真实 API 验收。
- 截图为实际浏览器渲染。测试环境缺中文字体时仅在测试页面注入 Noto Sans SC；工程继续用系统字体，没有引入网络字体依赖。

## 未完成 / 下一步

1. **优先继续 Phase 6/8**：在能正常加载百度 SDK 的环境，验证 `src/components/brand/mapVisualStyle.ts` 的真实道路/POI 配色、default 清空样式、拖拽缩放和不同缩放级别。不能只依据 Mock 图片决定暖色方案。
2. 真机验证键盘、safe-area、定位权限、重新定位、双指缩放、地图性能和系统分享/导航/保存图片。模拟视口不等于 iOS/Android 真机。
3. 地图主题接口能捕捉“不支持”和同步异常；无法保证 SDK 异步网络/底图渲染错误都能自动被识别，保留手动原地图切换。
4. 正式 People/Category 插画、类别图标、字标独立透明原稿和最终 CTA 文案待用户提供/确认；现在都是可替换入口。
5. 粗糙描线为固定 SVG 双线近似，不是复刻 Logo 的像素毛边；后续如需更接近手绘原稿，可替换 RoughBorder 路径而不改按钮逻辑。
6. 照片、长列表和日记等沿用现有功能；不声称已重新覆盖所有服务端错误和所有存储场景。

## 保存节点

本轮已保留可构建的 Checkpoint-B（覆盖 Phase 1–3）、Checkpoint-C（Phase 4–5）、Checkpoint-D（Phase 6）、最终 Checkpoint-E（Phase 7–8）。首次素材阶段与品牌线条/轮播阶段合并形成 B 快照。最终工程包含这些阶段源代码快照，避免后续中断丢失。
