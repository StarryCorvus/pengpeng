# 碰碰｜UI视觉改版阶段三

基于阶段二完整工程继续精修。先读《UI阶段三修改说明.md》。

## 运行

```sh
npm ci
npm run dev
```

## 构建与验收

```sh
npm run build
npm test
node tests/mapVisualStyle.test.cjs
node scripts/build-ui-deliverables.mjs
```

运行最后一条即可生成 Real/Mock 两个单文件 HTML，之后原 config.ts 会恢复。双击 Mock HTML 可直接操作。真实 API 需要网络及原服务配置。

## 本轮交付

Splash 透明字标与碰撞线、正式主题插画、大标题、纸条与粗笔框、浅色主题锁定。业务逻辑保护与测试范围详见说明。真实百度 SDK 在当前 QA 环境因证书错误未完成验收；实体手机行为待验收。历史阶段说明仅供追溯，当前阶段三说明优先。

## 2026-10-07 分享链路增量

当前工程已同步 GitHub Pages 的 `share5 / v4` 轻量分享方案。详细见《最新增量说明-share5-v4.md》。公开部署时除主 `index.html` 外，请一并部署 `share.html`。
